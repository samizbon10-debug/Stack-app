import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/user_model.dart';

// Auth State
class AuthState {
  final User? firebaseUser;
  final UserModel? userModel;
  final bool isLoading;
  final String? error;
  final bool isAuthenticated;
  final bool isBiometricEnabled;

  AuthState({
    this.firebaseUser,
    this.userModel,
    this.isLoading = false,
    this.error,
    this.isAuthenticated = false,
    this.isBiometricEnabled = false,
  });

  AuthState copyWith({
    User? firebaseUser,
    UserModel? userModel,
    bool? isLoading,
    String? error,
    bool? isAuthenticated,
    bool? isBiometricEnabled,
  }) {
    return AuthState(
      firebaseUser: firebaseUser ?? this.firebaseUser,
      userModel: userModel ?? this.userModel,
      isLoading: isLoading ?? this.isLoading,
      error: error,
      isAuthenticated: isAuthenticated ?? this.isAuthenticated,
      isBiometricEnabled: isBiometricEnabled ?? this.isBiometricEnabled,
    );
  }
}

// Auth Notifier
class AuthNotifier extends StateNotifier<AuthState> {
  final FirebaseAuth _auth;
  final GoogleSignIn _googleSignIn;
  final FirebaseFirestore _firestore;

  AuthNotifier({
    required FirebaseAuth auth,
    required GoogleSignIn googleSignIn,
    required FirebaseFirestore firestore,
  })  : _auth = auth,
        _googleSignIn = googleSignIn,
        _firestore = firestore,
        super(AuthState()) {
    _init();
  }

  void _init() {
    _auth.authStateChanges().listen((user) async {
      if (user != null) {
        state = state.copyWith(
          firebaseUser: user,
          isLoading: true,
        );
        await _fetchUserData(user.uid);
      } else {
        state = AuthState();
      }
    });
  }

  Future<void> _fetchUserData(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists) {
        final userModel = UserModel.fromFirestore(doc);
        state = state.copyWith(
          userModel: userModel,
          isAuthenticated: true,
          isLoading: false,
          isBiometricEnabled: userModel.settings.biometricEnabled,
        );
      } else {
        // Create user document if it doesn't exist
        final newUser = UserModel(
          userId: uid,
          email: _auth.currentUser?.email ?? '',
          displayName: _auth.currentUser?.displayName ?? 'Dentist',
          photoUrl: _auth.currentUser?.photoURL,
          createdAt: DateTime.now(),
          lastLoginAt: DateTime.now(),
          settings: UserSettings(),
        );
        await _firestore.collection('users').doc(uid).set(newUser.toMap());
        state = state.copyWith(
          userModel: newUser,
          isAuthenticated: true,
          isLoading: false,
        );
      }
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: 'Failed to fetch user data: $e',
      );
    }
  }

  Future<bool> signInWithGoogle() async {
    try {
      state = state.copyWith(isLoading: true, error: null);

      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        state = state.copyWith(isLoading: false);
        return false;
      }

      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Sign in to Firebase with the Google credential
      await _auth.signInWithCredential(credential);
      
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: 'Google sign in failed: $e',
      );
      return false;
    }
  }

  Future<void> signOut() async {
    try {
      state = state.copyWith(isLoading: true);
      await _googleSignIn.signOut();
      await _auth.signOut();
      state = AuthState();
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: 'Sign out failed: $e',
      );
    }
  }

  Future<void> updateUserModel(UserModel userModel) async {
    try {
      await _firestore
          .collection('users')
          .doc(userModel.userId)
          .update(userModel.toMap());
      state = state.copyWith(userModel: userModel);
    } catch (e) {
      state = state.copyWith(error: 'Failed to update user: $e');
    }
  }

  Future<void> updateLastLogin() async {
    if (state.userModel != null) {
      final updatedModel = state.userModel!.copyWith(
        lastLoginAt: DateTime.now(),
      );
      await updateUserModel(updatedModel);
    }
  }

  void setBiometricEnabled(bool enabled) {
    if (state.userModel != null) {
      final updatedSettings = state.userModel!.settings.copyWith(
        biometricEnabled: enabled,
      );
      final updatedModel = state.userModel!.copyWith(settings: updatedSettings);
      updateUserModel(updatedModel);
      state = state.copyWith(
        userModel: updatedModel,
        isBiometricEnabled: enabled,
      );
    }
  }

  void clearError() {
    state = state.copyWith(error: null);
  }
}

// Providers
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(
    auth: FirebaseAuth.instance,
    googleSignIn: GoogleSignIn(
      scopes: [
        'email',
        'https://www.googleapis.com/auth/drive.appdata',
        'https://www.googleapis.com/auth/drive.file',
      ],
    ),
    firestore: FirebaseFirestore.instance,
  );
});

// Convenience providers
final authUserProvider = Provider<User?>((ref) {
  return ref.watch(authProvider).firebaseUser;
});

final userModelProvider = Provider<UserModel?>((ref) {
  return ref.watch(authProvider).userModel;
});

final isAuthenticatedProvider = Provider<bool>((ref) {
  return ref.watch(authProvider).isAuthenticated;
});

final isLoadingProvider = Provider<bool>((ref) {
  return ref.watch(authProvider).isLoading;
});
