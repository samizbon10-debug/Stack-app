import 'package:cloud_firestore/cloud_firestore.dart';

/// User Settings Model
class UserSettings {
  final bool biometricEnabled;
  final bool autoBackup;
  final bool notificationsEnabled;
  final String theme;

  const UserSettings({
    this.biometricEnabled = false,
    this.autoBackup = true,
    this.notificationsEnabled = true,
    this.theme = 'light',
  });

  factory UserSettings.fromJson(Map<String, dynamic> json) {
    return UserSettings(
      biometricEnabled: json['biometricEnabled'] ?? false,
      autoBackup: json['autoBackup'] ?? true,
      notificationsEnabled: json['notificationsEnabled'] ?? true,
      theme: json['theme'] ?? 'light',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'biometricEnabled': biometricEnabled,
      'autoBackup': autoBackup,
      'notificationsEnabled': notificationsEnabled,
      'theme': theme,
    };
  }

  UserSettings copyWith({
    bool? biometricEnabled,
    bool? autoBackup,
    bool? notificationsEnabled,
    String? theme,
  }) {
    return UserSettings(
      biometricEnabled: biometricEnabled ?? this.biometricEnabled,
      autoBackup: autoBackup ?? this.autoBackup,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      theme: theme ?? this.theme,
    );
  }
}

/// User Model
class UserModel {
  final String userId;
  final String email;
  final String displayName;
  final String? photoUrl;
  final bool googleDriveConnected;
  final String? driveFolderId;
  final DateTime createdAt;
  final DateTime lastLoginAt;
  final UserSettings settings;

  const UserModel({
    required this.userId,
    required this.email,
    required this.displayName,
    this.photoUrl,
    this.googleDriveConnected = false,
    this.driveFolderId,
    required this.createdAt,
    required this.lastLoginAt,
    this.settings = const UserSettings(),
  });

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      userId: doc.id,
      email: data['email'] ?? '',
      displayName: data['displayName'] ?? '',
      photoUrl: data['photoUrl'],
      googleDriveConnected: data['googleDriveConnected'] ?? false,
      driveFolderId: data['driveFolderId'],
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      lastLoginAt:
          (data['lastLoginAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      settings: data['settings'] != null
          ? UserSettings.fromJson(data['settings'])
          : const UserSettings(),
    );
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      userId: json['userId'] ?? '',
      email: json['email'] ?? '',
      displayName: json['displayName'] ?? '',
      photoUrl: json['photoUrl'],
      googleDriveConnected: json['googleDriveConnected'] ?? false,
      driveFolderId: json['driveFolderId'],
      createdAt: json['createdAt'] is Timestamp
          ? (json['createdAt'] as Timestamp).toDate()
          : DateTime.parse(json['createdAt']),
      lastLoginAt: json['lastLoginAt'] is Timestamp
          ? (json['lastLoginAt'] as Timestamp).toDate()
          : DateTime.parse(json['lastLoginAt']),
      settings: json['settings'] != null
          ? UserSettings.fromJson(json['settings'])
          : const UserSettings(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'googleDriveConnected': googleDriveConnected,
      'driveFolderId': driveFolderId,
      'createdAt': Timestamp.fromDate(createdAt),
      'lastLoginAt': Timestamp.fromDate(lastLoginAt),
      'settings': settings.toJson(),
    };
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'googleDriveConnected': googleDriveConnected,
      'driveFolderId': driveFolderId,
      'createdAt': createdAt.toIso8601String(),
      'lastLoginAt': lastLoginAt.toIso8601String(),
      'settings': settings.toJson(),
    };
  }

  UserModel copyWith({
    String? userId,
    String? email,
    String? displayName,
    String? photoUrl,
    bool? googleDriveConnected,
    String? driveFolderId,
    DateTime? createdAt,
    DateTime? lastLoginAt,
    UserSettings? settings,
  }) {
    return UserModel(
      userId: userId ?? this.userId,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      googleDriveConnected: googleDriveConnected ?? this.googleDriveConnected,
      driveFolderId: driveFolderId ?? this.driveFolderId,
      createdAt: createdAt ?? this.createdAt,
      lastLoginAt: lastLoginAt ?? this.lastLoginAt,
      settings: settings ?? this.settings,
    );
  }

  @override
  String toString() {
    return 'UserModel(userId: $userId, email: $email, displayName: $displayName)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is UserModel && other.userId == userId;
  }

  @override
  int get hashCode => userId.hashCode;
}
