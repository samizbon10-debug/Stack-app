import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../../services/firebase_service.dart';
import 'user_model.dart';

/// Authentication Service
class AuthService {
  final FirebaseAuth _auth;
  final GoogleSignIn _googleSignIn;
  final FirebaseFirestore _firestore;
  final FlutterSecureStorage _secureStorage;
  final LocalAuthentication _localAuth;

  AuthService({
    required FirebaseAuth auth,
    required GoogleSignIn googleSignIn,
    required FirebaseFirestore firestore,
    required FlutterSecureStorage secureStorage,
    required LocalAuthentication localAuth,
  })  : _auth = auth,
        _googleSignIn = googleSignIn,
        _firestore = firestore,
        _secureStorage = secureStorage,
        _localAuth = localAuth;

  /// Get current user
  User? get currentUser => _auth.currentUser;

  /// Stream of auth state changes
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Sign in with Google
  Future<UserCredential> signInWithGoogle() async {
    try {
      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();

      if (googleUser == null) {
        throw Exception('Google sign in cancelled');
      }

      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Sign in to Firebase with the credential
      final userCredential = await _auth.signInWithCredential(credential);

      // Create user document if it's a new user
      if (userCredential.additionalUserInfo?.isNewUser ?? false) {
        await _createUserDocument(userCredential.user!);
      } else {
        // Update last login
        await _updateLastLogin(userCredential.user!.uid);
      }

      return userCredential;
    } catch (e) {
      rethrow;
    }
  }

  /// Sign out
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
    await _secureStorage.deleteAll();
  }

  /// Create user document in Firestore
  Future<void> _createUserDocument(User user) async {
    await _firestore.collection('users').doc(user.uid).set({
      'userId': user.uid,
      'email': user.email,
      'displayName': user.displayName ?? 'Dentist',
      'photoUrl': user.photoURL,
      'googleDriveConnected': false,
      'driveFolderId': null,
      'createdAt': FieldValue.serverTimestamp(),
      'lastLoginAt': FieldValue.serverTimestamp(),
      'settings': {
        'biometricEnabled': false,
        'autoBackup': true,
        'notificationsEnabled': true,
        'theme': 'light',
      },
    });
  }

  /// Update last login timestamp
  Future<void> _updateLastLogin(String userId) async {
    await _firestore.collection('users').doc(userId).update({
      'lastLoginAt': FieldValue.serverTimestamp(),
    });
  }

  /// Get user document
  Future<UserModel?> getUserDocument(String userId) async {
    final doc = await _firestore.collection('users').doc(userId).get();
    if (doc.exists) {
      return UserModel.fromFirestore(doc);
    }
    return null;
  }

  /// Update user settings
  Future<void> updateUserSettings(String userId, UserSettings settings) async {
    await _firestore.collection('users').doc(userId).update({
      'settings': settings.toJson(),
    });
  }

  /// Check if biometric is available
  Future<bool> isBiometricAvailable() async {
    try {
      return await _localAuth.canCheckBiometrics;
    } catch (e) {
      return false;
    }
  }

  /// Get available biometrics
  Future<List<BiometricType>> getAvailableBiometrics() async {
    try {
      return await _localAuth.getAvailableBiometrics();
    } catch (e) {
      return [];
    }
  }

  /// Authenticate with biometrics
  Future<bool> authenticateWithBiometrics() async {
    try {
      return await _localAuth.authenticate(
        localizedReason: 'Please authenticate to access Dental Case Manager',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: true,
        ),
      );
    } catch (e) {
      return false;
    }
  }

  /// Save PIN to secure storage
  Future<void> savePin(String pin) async {
    await _secureStorage.write(key: 'app_pin', value: pin);
  }

  /// Get PIN from secure storage
  Future<String?> getPin() async {
    return await _secureStorage.read(key: 'app_pin');
  }

  /// Verify PIN
  Future<bool> verifyPin(String pin) async {
    final savedPin = await getPin();
    return savedPin == pin;
  }

  /// Check if PIN is set
  Future<bool> isPinSet() async {
    final pin = await getPin();
    return pin != null && pin.isNotEmpty;
  }

  /// Remove PIN
  Future<void> removePin() async {
    await _secureStorage.delete(key: 'app_pin');
  }

  /// Save biometric enabled preference
  Future<void> setBiometricEnabled(bool enabled) async {
    await _secureStorage.write(
      key: 'biometric_enabled',
      value: enabled.toString(),
    );
  }

  /// Check if biometric is enabled
  Future<bool> isBiometricEnabled() async {
    final enabled = await _secureStorage.read(key: 'biometric_enabled');
    return enabled == 'true';
  }

  /// Store Google Drive access token
  Future<void> saveDriveAccessToken(String token) async {
    await _secureStorage.write(key: 'drive_access_token', value: token);
  }

  /// Get Google Drive access token
  Future<String?> getDriveAccessToken() async {
    return await _secureStorage.read(key: 'drive_access_token');
  }

  /// Clear drive token
  Future<void> clearDriveAccessToken() async {
    await _secureStorage.delete(key: 'drive_access_token');
  }
}

// Providers
final googleSignInProvider = Provider<GoogleSignIn>((ref) {
  return GoogleSignIn(
    scopes: [
      'email',
      'https://www.googleapis.com/auth/drive.file',
    ],
  );
});

final secureStorageProvider = Provider<FlutterSecureStorage>((ref) {
  return const FlutterSecureStorage(
    aOptions: AndroidOptions(
      encryptedSharedPreferences: true,
    ),
  );
});

final localAuthProvider = Provider<LocalAuthentication>((ref) {
  return LocalAuthentication();
});

final authServiceProvider = Provider<AuthService>((ref) {
  return AuthService(
    auth: ref.watch(firebaseAuthProvider),
    googleSignIn: ref.watch(googleSignInProvider),
    firestore: ref.watch(firestoreProvider),
    secureStorage: ref.watch(secureStorageProvider),
    localAuth: ref.watch(localAuthProvider),
  );
});

// Current user model provider
final currentUserModelProvider =
    FutureProvider.family<UserModel?, String>((ref, userId) {
  final authService = ref.watch(authServiceProvider);
  return authService.getUserDocument(userId);
});
