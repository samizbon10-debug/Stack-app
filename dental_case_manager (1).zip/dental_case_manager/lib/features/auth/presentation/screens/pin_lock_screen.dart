import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/constants/app_sizes.dart';

class PinLockScreen extends StatefulWidget {
  final VoidCallback onUnlock;

  const PinLockScreen({super.key, required this.onUnlock});

  @override
  State<PinLockScreen> createState() => _PinLockScreenState();
}

class _PinLockScreenState extends State<PinLockScreen>
    with SingleTickerProviderStateMixin {
  final List<String> _pin = [];
  final int _pinLength = 4;
  bool _isError = false;
  late AnimationController _shakeController;
  late Animation<double> _shakeAnimation;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _shakeAnimation = Tween<double>(begin: 0, end: 10)
        .chain(CurveTween(curve: Curves.elasticIn))
        .animate(_shakeController);
  }

  @override
  void dispose() {
    _shakeController.dispose();
    super.dispose();
  }

  void _onKeyPressed(String key) {
    if (_pin.length < _pinLength) {
      setState(() {
        _pin.add(key);
        _isError = false;
      });

      if (_pin.length == _pinLength) {
        _verifyPin();
      }
    }
  }

  void _onBackspace() {
    if (_pin.isNotEmpty) {
      setState(() {
        _pin.removeLast();
        _isError = false;
      });
    }
  }

  void _verifyPin() {
    // For demo purposes, accept "1234" as the PIN
    // In production, this should verify against a securely stored PIN
    if (_pin.join() == '1234') {
      HapticFeedback.lightImpact();
      widget.onUnlock();
    } else {
      HapticFeedback.heavyImpact();
      _shakeController.forward().then((_) {
        _shakeController.reset();
      });
      setState(() {
        _isError = true;
      });
      Future.delayed(const Duration(milliseconds: 500), () {
        setState(() {
          _pin.clear();
        });
      });
    }
  }

  Future<void> _authenticateBiometric() async {
    try {
      final localAuth = LocalAuthentication();
      final canCheckBiometrics = await localAuth.canCheckBiometrics;

      if (canCheckBiometrics) {
        final isAuthenticated = await localAuth.authenticate(
          localizedReason: 'Authenticate to access Dental Case Manager',
          options: const AuthenticationOptions(
            stickyAuth: true,
            biometricOnly: true,
          ),
        );

        if (isAuthenticated && mounted) {
          HapticFeedback.lightImpact();
          widget.onUnlock();
        }
      }
    } catch (e) {
      // Handle error silently
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _shakeAnimation,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(_shakeAnimation.value, 0),
              child: child,
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(AppSizes.paddingL),
            child: Column(
              children: [
                const Spacer(flex: 2),

                // App Logo and Title
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    gradient: AppColors.primaryGradient,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(
                    Icons.medical_services_rounded,
                    size: 40,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: AppSizes.spacingL),

                Text(
                  AppStrings.appName,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: AppSizes.spacingS),

                Text(
                  'Enter PIN to continue',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                ),

                const SizedBox(height: AppSizes.spacingXL),

                // PIN Dots
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(_pinLength, (index) {
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: index < _pin.length
                            ? _isError
                                ? AppColors.error
                                : AppColors.primary
                            : Colors.transparent,
                        border: Border.all(
                          color: _isError ? AppColors.error : AppColors.primary,
                          width: 2,
                        ),
                      ),
                    );
                  }),
                ),

                const Spacer(),

                // Biometric Button (if available)
                FutureBuilder<bool>(
                  future: _canCheckBiometrics(),
                  builder: (context, snapshot) {
                    if (snapshot.data == true) {
                      return Column(
                        children: [
                          IconButton(
                            onPressed: _authenticateBiometric,
                            icon: const Icon(
                              Icons.fingerprint,
                              size: 48,
                              color: AppColors.primary,
                            ),
                          ),
                          const SizedBox(height: AppSizes.spacingM),
                        ],
                      );
                    }
                    return const SizedBox.shrink();
                  },
                ),

                // Number Pad
                _buildNumberPad(),

                const SizedBox(height: AppSizes.spacingL),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<bool> _canCheckBiometrics() async {
    try {
      final localAuth = LocalAuthentication();
      return await localAuth.canCheckBiometrics;
    } catch (e) {
      return false;
    }
  }

  Widget _buildNumberPad() {
    return Column(
      children: [
        for (int i = 0; i < 3; i++) ...[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(3, (j) {
              final number = (i * 3 + j + 1).toString();
              return _buildNumberButton(number);
            }),
          ),
          const SizedBox(height: AppSizes.spacingM),
        ],
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            const SizedBox(width: 75, height: 75),
            _buildNumberButton('0'),
            _buildIconButton(
              icon: Icons.backspace_outlined,
              onPressed: _onBackspace,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildNumberButton(String number) {
    return _buildIconButton(
      child: Text(
        number,
        style: const TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
      ),
      onPressed: () => _onKeyPressed(number),
    );
  }

  Widget _buildIconButton({
    Widget? child,
    IconData? icon,
    required VoidCallback onPressed,
  }) {
    return Container(
      width: 75,
      height: 75,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      child: Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(AppSizes.radiusL),
          child: Center(
            child: child ??
                Icon(
                  icon,
                  size: 28,
                  color: AppColors.textSecondary,
                ),
          ),
        ),
      ),
    );
  }
}
