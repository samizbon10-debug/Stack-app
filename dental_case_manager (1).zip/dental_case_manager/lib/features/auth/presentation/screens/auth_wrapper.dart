import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../../auth/data/auth_provider.dart';
import 'login_screen.dart';
import 'pin_lock_screen.dart';
import '../../dashboard/presentation/screens/home_screen.dart';

class AuthWrapper extends ConsumerWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authProvider);
    final biometricEnabled = authState.isBiometricEnabled;

    // Loading state
    if (authState.isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    // Not authenticated - show login
    if (!authState.isAuthenticated) {
      return const LoginScreen();
    }

    // Authenticated with biometric enabled - show lock screen
    if (biometricEnabled) {
      return PinLockScreen(
        onUnlock: () {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const HomeScreen()),
          );
        },
      );
    }

    // Authenticated without biometric - go to home
    return const HomeScreen();
  }
}
