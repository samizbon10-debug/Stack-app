import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../../auth/data/auth_provider.dart';
import '../../../patients/data/patients_provider.dart';
import '../../../treatments/data/treatments_provider.dart';
import '../../../appointments/data/appointments_provider.dart';
import '../widgets/dashboard_card.dart';
import '../widgets/appointment_card.dart';
import '../../patients/presentation/screens/patients_list_screen.dart';
import '../../patients/presentation/screens/add_patient_screen.dart';
import '../../appointments/presentation/screens/appointments_screen.dart';
import '../../gallery/presentation/screens/case_gallery_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider).userModel;
    final userId = user?.userId ?? '';

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: [
          _buildDashboard(userId),
          const PatientsListScreen(),
          const AppointmentsScreen(),
          const CaseGalleryScreen(),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButton: _currentIndex == 1
          ? FloatingActionButton.extended(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => AddPatientScreen(userId: userId),
                  ),
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Add Patient'),
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
            ).animate().scale(duration: 300.ms, curve: Curves.elasticOut)
          : null,
    );
  }

  Widget _buildDashboard(String userId) {
    final patientsState = ref.watch(patientsProvider(userId));
    final treatmentsState = ref.watch(treatmentsProvider(userId));
    final appointmentsState = ref.watch(appointmentsProvider(userId));
    final user = ref.watch(authProvider).userModel;

    return CustomScrollView(
      slivers: [
        // App Bar
        SliverAppBar(
          expandedHeight: 180,
          floating: true,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(
                gradient: AppColors.headerGradient,
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(AppSizes.paddingL),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Hello, ${user?.displayName ?? 'Doctor'}',
                                  style: Theme.of(context)
                                      .textTheme
                                      .headlineSmall
                                      ?.copyWith(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                )
                                    .animate()
                                    .fadeIn()
                                    .slideX(begin: -0.2, end: 0),
                                const SizedBox(height: AppSizes.spacingXS),
                                Text(
                                  DateFormat('EEEE, MMMM d').format(DateTime.now()),
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: Colors.white.withOpacity(0.9),
                                      ),
                                )
                                    .animate()
                                    .fadeIn(delay: 100.ms)
                                    .slideX(begin: -0.2, end: 0),
                              ],
                            ),
                          ),
                          CircleAvatar(
                            radius: 24,
                            backgroundImage: user?.photoUrl != null
                                ? NetworkImage(user!.photoUrl!)
                                : null,
                            backgroundColor: Colors.white,
                            child: user?.photoUrl == null
                                ? Text(
                                    user?.displayName
                                            ?.substring(0, 1)
                                            .toUpperCase() ??
                                        'D',
                                    style: const TextStyle(
                                      color: AppColors.primary,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                : null,
                          )
                              .animate()
                              .scale(duration: 400.ms, curve: Curves.elasticOut),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),

        // Content
        SliverPadding(
          padding: const EdgeInsets.all(AppSizes.paddingM),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              // Quick Stats
              Row(
                children: [
                  Expanded(
                    child: _buildStatCard(
                      'Patients',
                      patientsState.patients.length.toString(),
                      Icons.people,
                      AppColors.primary,
                    ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.2, end: 0),
                  ),
                  const SizedBox(width: AppSizes.spacingM),
                  Expanded(
                    child: _buildStatCard(
                      "Today's Appts",
                      appointmentsState.todayAppointments.length.toString(),
                      Icons.calendar_today,
                      AppColors.secondary,
                    ).animate().fadeIn(delay: 300.ms).slideY(begin: 0.2, end: 0),
                  ),
                ],
              ),

              const SizedBox(height: AppSizes.spacingM),

              Row(
                children: [
                  Expanded(
                    child: _buildStatCard(
                      'Treatments',
                      treatmentsState.treatments.length.toString(),
                      Icons.medical_services,
                      AppColors.orthodontics,
                    ).animate().fadeIn(delay: 400.ms).slideY(begin: 0.2, end: 0),
                  ),
                  const SizedBox(width: AppSizes.spacingM),
                  Expanded(
                    child: _buildStatCard(
                      'In Progress',
                      treatmentsState.inProgressTreatments.length.toString(),
                      Icons.pending_actions,
                      AppColors.warning,
                    ).animate().fadeIn(delay: 500.ms).slideY(begin: 0.2, end: 0),
                  ),
                ],
              ),

              const SizedBox(height: AppSizes.spacingXL),

              // Dashboard Cards
              Text(
                'Quick Access',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ).animate().fadeIn(delay: 600.ms),

              const SizedBox(height: AppSizes.spacingM),

              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: AppSizes.spacingM,
                crossAxisSpacing: AppSizes.spacingM,
                children: [
                  DashboardCard(
                    title: 'Orthodontics',
                    icon: Icons.straighten,
                    color: AppColors.orthodontics,
                    count: treatmentsState.orthodonticsTreatments.length,
                    onTap: () => _navigateToTreatmentCategory(
                      context,
                      'Orthodontics',
                      userId,
                    ),
                  ),
                  DashboardCard(
                    title: 'Fillings',
                    icon: Icons.build_circle,
                    color: AppColors.fillings,
                    count: treatmentsState.fillingsTreatments.length,
                    onTap: () => _navigateToTreatmentCategory(
                      context,
                      'Fillings',
                      userId,
                    ),
                  ),
                  DashboardCard(
                    title: 'Scaling & Polishing',
                    icon: Icons.cleaning_services,
                    color: AppColors.scalingPolishing,
                    count: treatmentsState.scalingPolishingTreatments.length,
                    onTap: () => _navigateToTreatmentCategory(
                      context,
                      'Scaling & Polishing',
                      userId,
                    ),
                  ),
                  DashboardCard(
                    title: 'Case Gallery',
                    icon: Icons.photo_library,
                    color: AppColors.primary,
                    onTap: () {
                      setState(() => _currentIndex = 3);
                    },
                  ),
                ],
              ).animate().fadeIn(delay: 700.ms).slideY(begin: 0.1, end: 0),

              const SizedBox(height: AppSizes.spacingXL),

              // Today's Appointments
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Today's Appointments",
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  TextButton(
                    onPressed: () => setState(() => _currentIndex = 2),
                    child: const Text('View All'),
                  ),
                ],
              ).animate().fadeIn(delay: 800.ms),

              const SizedBox(height: AppSizes.spacingM),

              // Appointments List
              if (appointmentsState.todayAppointments.isEmpty)
                _buildEmptyAppointments()
              else
                ...appointmentsState.todayAppointments.take(3).map(
                      (appointment) => Padding(
                        padding: const EdgeInsets.only(
                          bottom: AppSizes.spacingS,
                        ),
                        child: AppointmentCard(
                          appointment: appointment,
                          onTap: () {
                            // Navigate to appointment details
                          },
                        ),
                      ),
                    ),

              const SizedBox(height: AppSizes.spacingXL),

              // Backup Status
              _buildBackupStatusCard(user?.settings)
                  .animate()
                  .fadeIn(delay: 900.ms)
                  .slideY(begin: 0.1, end: 0),

              const SizedBox(height: AppSizes.spacingXXL),
            ]),
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(AppSizes.paddingM),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: Colors.white, size: 24),
          ),
          const SizedBox(width: AppSizes.spacingM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: color,
                      ),
                ),
                Text(
                  title,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyAppointments() {
    return Container(
      padding: const EdgeInsets.all(AppSizes.paddingXL),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
      ),
      child: Column(
        children: [
          Icon(
            Icons.event_available,
            size: 48,
            color: AppColors.textHint,
          ),
          const SizedBox(height: AppSizes.spacingM),
          Text(
            'No appointments today',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppColors.textSecondary,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackupStatusCard(UserSettings? settings) {
    final lastBackup = settings?.lastBackupAt;
    final isBackupEnabled = settings?.autoBackupEnabled ?? true;

    return Container(
      padding: const EdgeInsets.all(AppSizes.paddingM),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.successLight,
            AppColors.success.withOpacity(0.2),
          ],
        ),
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppColors.success,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.cloud_done,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: AppSizes.spacingM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Backup Status',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                Text(
                  isBackupEnabled
                      ? lastBackup != null
                          ? 'Last backup: ${_formatLastBackup(lastBackup)}'
                          : 'Auto backup enabled'
                      : 'Auto backup disabled',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                ),
              ],
            ),
          ),
          Icon(
            isBackupEnabled ? Icons.check_circle : Icons.warning,
            color: isBackupEnabled ? AppColors.success : AppColors.warning,
          ),
        ],
      ),
    );
  }

  String _formatLastBackup(DateTime lastBackup) {
    final now = DateTime.now();
    final difference = now.difference(lastBackup);

    if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return DateFormat('MMM d, h:mm a').format(lastBackup);
    }
  }

  void _navigateToTreatmentCategory(
    BuildContext context,
    String category,
    String userId,
  ) {
    // Navigate to treatments filtered by category
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) {
          setState(() => _currentIndex = index);
        },
        backgroundColor: Colors.transparent,
        elevation: 0,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.people_outline),
            selectedIcon: Icon(Icons.people),
            label: 'Patients',
          ),
          NavigationDestination(
            icon: Icon(Icons.calendar_today_outlined),
            selectedIcon: Icon(Icons.calendar_today),
            label: 'Appointments',
          ),
          NavigationDestination(
            icon: Icon(Icons.photo_library_outlined),
            selectedIcon: Icon(Icons.photo_library),
            label: 'Gallery',
          ),
        ],
      ),
    );
  }
}
