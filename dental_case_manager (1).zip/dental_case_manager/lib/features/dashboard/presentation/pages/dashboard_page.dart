import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../auth/data/auth_service.dart';
import '../../../patients/data/repositories/patient_repository.dart';
import '../../../treatments/data/repositories/treatment_repository.dart';
import '../../../appointments/data/repositories/appointment_repository.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/animated_widgets.dart';
import '../../../../core/utils/helpers.dart';

class DashboardPage extends ConsumerStatefulWidget {
  const DashboardPage({super.key});

  @override
  ConsumerState<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends ConsumerState<DashboardPage> {
  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authStateProvider).value;
    final userId = user?.uid ?? '';

    // Get stats
    final patientsAsync = ref.watch(patientsProvider(userId));
    final treatmentsAsync = ref.watch(userTreatmentsProvider(userId));
    final appointmentsAsync = ref.watch(upcomingAppointmentsProvider(userId));
    final todaysAppointmentsAsync = ref.watch(todaysAppointmentsProvider(userId));

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            expandedHeight: 200,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: AppTheme.headerGradient,
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Welcome back,',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.8),
                                    fontSize: 14,
                                  ),
                                ).animate().fadeIn(duration: 400.ms),
                                const SizedBox(height: 4),
                                Text(
                                  user?.displayName ?? 'Dentist',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ).animate().fadeIn(delay: 100.ms, duration: 400.ms),
                              ],
                            ),
                            _buildProfileButton(user?.photoURL),
                          ],
                        ),
                        const Spacer(),
                        // Quick search
                        _buildQuickSearch(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Content
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Today's appointments section
                _buildTodaysAppointments(todaysAppointmentsAsync),

                const SizedBox(height: 24),

                // Stats cards
                Text(
                  'Overview',
                  style: Theme.of(context).textTheme.titleLarge,
                ).animate().fadeIn(delay: 200.ms),
                const SizedBox(height: 16),

                // Dashboard cards grid
                _buildDashboardCards(patientsAsync, treatmentsAsync, appointmentsAsync),

                const SizedBox(height: 24),

                // Treatment Categories
                Text(
                  'Treatment Categories',
                  style: Theme.of(context).textTheme.titleLarge,
                ).animate().fadeIn(delay: 400.ms),
                const SizedBox(height: 16),

                _buildTreatmentCategories(treatmentsAsync),

                const SizedBox(height: 24),

                // Recent patients
                Text(
                  'Recent Patients',
                  style: Theme.of(context).textTheme.titleLarge,
                ).animate().fadeIn(delay: 500.ms),
                const SizedBox(height: 16),

                _buildRecentPatients(patientsAsync),
              ]),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          context.push('/patients/new');
        },
        backgroundColor: AppTheme.primaryColor,
        icon: const Icon(Icons.add),
        label: const Text('New Patient'),
      ).animate().scale(delay: 600.ms, duration: 400.ms),
    );
  }

  Widget _buildProfileButton(String? photoUrl) {
    return GestureDetector(
      onTap: () => context.push('/settings'),
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 2),
        ),
        child: CircleAvatar(
          radius: 24,
          backgroundColor: Colors.white.withOpacity(0.2),
          backgroundImage: photoUrl != null ? NetworkImage(photoUrl) : null,
          child: photoUrl == null
              ? const Icon(Icons.person, color: Colors.white)
              : null,
        ),
      ),
    ).animate().scale(delay: 200.ms, duration: 400.ms);
  }

  Widget _buildQuickSearch() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: TextField(
        readOnly: true,
        onTap: () => context.push('/search'),
        decoration: InputDecoration(
          hintText: 'Search patients, treatments...',
          hintStyle: TextStyle(color: Colors.grey.shade400),
          prefixIcon: Icon(Icons.search, color: AppTheme.primaryColor),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
        ),
      ),
    ).animate().fadeIn(delay: 300.ms, duration: 400.ms).slideY(begin: 0.2, end: 0);
  }

  Widget _buildTodaysAppointments(AsyncValue<List> appointmentsAsync) {
    return appointmentsAsync.when(
      data: (appointments) {
        if (appointments.isEmpty) {
          return const SizedBox.shrink();
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Today\'s Appointments',
              style: Theme.of(context).textTheme.titleLarge,
            ).animate().fadeIn(),
            const SizedBox(height: 12),
            SizedBox(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: appointments.length,
                itemBuilder: (context, index) {
                  final appointment = appointments[index];
                  return _buildAppointmentCard(appointment, index);
                },
              ),
            ),
          ],
        );
      },
      loading: () => const SizedBox.shrink(),
      error: (_, __) => const SizedBox.shrink(),
    );
  }

  Widget _buildAppointmentCard(dynamic appointment, int index) {
    return Container(
      width: 200,
      margin: const EdgeInsets.only(right: 12),
      child: AnimatedCard(
        onTap: () => context.push('/appointments/${appointment.appointmentId}'),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              appointment.title,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              appointment.formattedTime,
              style: TextStyle(
                color: AppTheme.primaryColor,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const Spacer(),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppHelpers.getStatusColor(appointment.status)
                        .withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    appointment.status.toUpperCase(),
                    style: TextStyle(
                      fontSize: 10,
                      color: AppHelpers.getStatusColor(appointment.status),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ).animate().fadeIn(delay: Duration(milliseconds: 100 * index));
  }

  Widget _buildDashboardCards(
    AsyncValue<List> patientsAsync,
    AsyncValue<List> treatmentsAsync,
    AsyncValue<List> appointmentsAsync,
  ) {
    final patientCount = patientsAsync.valueOrNull?.length ?? 0;
    final treatmentCount = treatmentsAsync.valueOrNull?.length ?? 0;
    final upcomingCount = appointmentsAsync.valueOrNull?.length ?? 0;

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      childAspectRatio: 1.5,
      children: [
        DashboardCard(
          title: 'Patients',
          value: patientCount.toString(),
          icon: Icons.people_outline,
          color: AppTheme.primaryColor,
          onTap: () => context.push('/patients'),
        ),
        DashboardCard(
          title: 'Treatments',
          value: treatmentCount.toString(),
          icon: Icons.medical_services_outlined,
          color: AppTheme.secondaryColor,
          onTap: () => context.push('/treatments'),
        ),
        DashboardCard(
          title: 'Appointments',
          value: upcomingCount.toString(),
          icon: Icons.calendar_today_outlined,
          color: AppTheme.orthodonticsColor,
          subtitle: 'Upcoming',
          onTap: () => context.push('/appointments'),
        ),
        DashboardCard(
          title: 'Case Gallery',
          value: 'View',
          icon: Icons.photo_library_outlined,
          color: AppTheme.scalingColor,
          onTap: () => context.push('/gallery'),
        ),
      ],
    );
  }

  Widget _buildTreatmentCategories(AsyncValue<List> treatmentsAsync) {
    final treatments = treatmentsAsync.valueOrNull ?? [];

    final orthoCount =
        treatments.where((t) => t.category == 'orthodontics').length;
    final fillingsCount =
        treatments.where((t) => t.category == 'fillings').length;
    final scalingCount =
        treatments.where((t) => t.category == 'scaling_polishing').length;

    return Row(
      children: [
        Expanded(
          child: _buildCategoryCard(
            'Orthodontics',
            orthoCount,
            AppTheme.orthodonticsColor,
            Icons.straighten,
            () => context.push('/treatments?category=orthodontics'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildCategoryCard(
            'Fillings',
            fillingsCount,
            AppTheme.fillingsColor,
            Icons.healing,
            () => context.push('/treatments?category=fillings'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildCategoryCard(
            'Scaling',
            scalingCount,
            AppTheme.scalingColor,
            Icons.cleaning_services,
            () => context.push('/treatments?category=scaling_polishing'),
          ),
        ),
      ],
    );
  }

  Widget _buildCategoryCard(
    String title,
    int count,
    Color color,
    IconData icon,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(
              count.toString(),
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              title,
              style: TextStyle(
                fontSize: 12,
                color: color,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    )
        .animate()
        .fadeIn(duration: 400.ms)
        .scale(begin: const Offset(0.9, 0.9), end: const Offset(1, 1));
  }

  Widget _buildRecentPatients(AsyncValue<List> patientsAsync) {
    return patientsAsync.when(
      data: (patients) {
        if (patients.isEmpty) {
          return _buildEmptyState(
            icon: Icons.people_outline,
            title: 'No Patients Yet',
            subtitle: 'Add your first patient to get started',
            action: 'Add Patient',
            onTap: () => context.push('/patients/new'),
          );
        }

        final recentPatients = patients.take(5).toList();

        return Column(
          children: recentPatients.map((patient) {
            return AnimatedListItem(
              index: recentPatients.indexOf(patient),
              child: _buildPatientListItem(patient),
            );
          }).toList(),
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }

  Widget _buildPatientListItem(dynamic patient) {
    return AnimatedCard(
      margin: const EdgeInsets.only(bottom: 8),
      onTap: () => context.push('/patients/${patient.patientId}'),
      child: Row(
        children: [
          AnimatedProfileAvatar(
            imageUrl: patient.profilePhotoUrl,
            name: patient.name,
            radius: 24,
            heroTag: 'patient_${patient.patientId}',
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  patient.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
                Text(
                  '${patient.age} years • ${patient.gender}',
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.arrow_forward_ios,
            size: 16,
            color: Colors.grey.shade400,
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String title,
    required String subtitle,
    required String action,
    required VoidCallback onTap,
  }) {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: [
          Icon(icon, size: 48, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.grey.shade600,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.grey.shade500,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: onTap,
            icon: const Icon(Icons.add),
            label: Text(action),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).scale(
          begin: const Offset(0.95, 0.95),
          end: const Offset(1, 1),
        );
  }
}
