import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/patient_model.dart';

// Patients State
class PatientsState {
  final List<PatientModel> patients;
  final bool isLoading;
  final String? error;
  final String searchQuery;

  PatientsState({
    this.patients = const [],
    this.isLoading = false,
    this.error,
    this.searchQuery = '',
  });

  PatientsState copyWith({
    List<PatientModel>? patients,
    bool? isLoading,
    String? error,
    String? searchQuery,
  }) {
    return PatientsState(
      patients: patients ?? this.patients,
      isLoading: isLoading ?? this.isLoading,
      error: error,
      searchQuery: searchQuery ?? this.searchQuery,
    );
  }

  List<PatientModel> get filteredPatients {
    if (searchQuery.isEmpty) return patients;
    final query = searchQuery.toLowerCase();
    return patients.where((p) {
      return p.name.toLowerCase().contains(query) ||
          p.phone.contains(query);
    }).toList();
  }
}

// Patients Notifier
class PatientsNotifier extends StateNotifier<PatientsState> {
  final FirebaseFirestore _firestore;
  final String userId;

  PatientsNotifier({
    required FirebaseFirestore firestore,
    required this.userId,
  })  : _firestore = firestore,
        super(PatientsState()) {
    fetchPatients();
  }

  void fetchPatients() {
    state = state.copyWith(isLoading: true);
    
    _firestore
        .collection('patients')
        .where('userId', isEqualTo: userId)
        .where('isActive', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .listen(
      (snapshot) {
        final patients = snapshot.docs
            .map((doc) => PatientModel.fromFirestore(doc))
            .toList();
        state = state.copyWith(
          patients: patients,
          isLoading: false,
        );
      },
      onError: (error) {
        state = state.copyWith(
          isLoading: false,
          error: error.toString(),
        );
      },
    );
  }

  Future<PatientModel?> createPatient(PatientModel patient) async {
    try {
      state = state.copyWith(isLoading: true);
      
      final docRef = await _firestore.collection('patients').add(patient.toMap());
      
      final newPatient = patient.copyWith(
        patientId: docRef.id,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      
      await docRef.update({
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      
      state = state.copyWith(isLoading: false);
      return newPatient;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: 'Failed to create patient: $e',
      );
      return null;
    }
  }

  Future<bool> updatePatient(PatientModel patient) async {
    try {
      state = state.copyWith(isLoading: true);
      
      await _firestore
          .collection('patients')
          .doc(patient.patientId)
          .update({
            ...patient.toMap(),
            'updatedAt': FieldValue.serverTimestamp(),
          });
      
      state = state.copyWith(isLoading: false);
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: 'Failed to update patient: $e',
      );
      return false;
    }
  }

  Future<bool> deletePatient(String patientId) async {
    try {
      await _firestore
          .collection('patients')
          .doc(patientId)
          .update({
            'isActive': false,
            'updatedAt': FieldValue.serverTimestamp(),
          });
      return true;
    } catch (e) {
      state = state.copyWith(error: 'Failed to delete patient: $e');
      return false;
    }
  }

  void setSearchQuery(String query) {
    state = state.copyWith(searchQuery: query);
  }

  void clearError() {
    state = state.copyWith(error: null);
  }
}

// Provider
final patientsProvider =
    StateNotifierProvider.family<PatientsNotifier, PatientsState, String>(
  (ref, userId) {
    return PatientsNotifier(
      firestore: FirebaseFirestore.instance,
      userId: userId,
    );
  },
);

// Single Patient Provider
final patientProvider = FutureProvider.family<PatientModel?, String>((ref, patientId) async {
  final doc = await FirebaseFirestore.instance
      .collection('patients')
      .doc(patientId)
      .get();
  
  if (doc.exists) {
    return PatientModel.fromFirestore(doc);
  }
  return null;
});
