import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../patients/data/models/patient_model.dart';
import '../../../../services/firebase_service.dart';

/// Patient Repository for CRUD operations
class PatientRepository {
  final FirebaseFirestore _firestore;
  final Box _cacheBox;
  final Uuid _uuid = const Uuid();

  PatientRepository({
    required FirebaseFirestore firestore,
    required Box cacheBox,
  })  : _firestore = firestore,
        _cacheBox = cacheBox;

  CollectionReference<Map<String, dynamic>> get _patientsCollection =>
      _firestore.collection('patients');

  /// Create a new patient
  Future<PatientModel> createPatient({
    required String userId,
    required String name,
    required String phone,
    required int age,
    required String gender,
    String medicalHistory = '',
    String allergies = '',
    String smokingStatus = 'never',
    String notes = '',
    String? profilePhotoUrl,
    List<String> tags = const [],
  }) async {
    final patientId = _uuid.v4();
    final now = DateTime.now();

    final patient = PatientModel(
      patientId: patientId,
      userId: userId,
      name: name,
      phone: phone,
      age: age,
      gender: gender,
      medicalHistory: medicalHistory,
      allergies: allergies,
      smokingStatus: smokingStatus,
      notes: notes,
      profilePhotoUrl: profilePhotoUrl,
      createdAt: now,
      updatedAt: now,
      tags: tags,
    );

    // Save to Firestore
    await _patientsCollection.doc(patientId).set(patient.toFirestore());

    // Save to local cache
    await _cacheBox.put(patientId, patient.toJson());

    return patient;
  }

  /// Get a patient by ID
  Future<PatientModel?> getPatient(String patientId) async {
    // Try cache first
    final cachedData = _cacheBox.get(patientId);
    if (cachedData != null) {
      return PatientModel.fromJson(Map<String, dynamic>.from(cachedData));
    }

    // Fetch from Firestore
    final doc = await _patientsCollection.doc(patientId).get();
    if (doc.exists) {
      final patient = PatientModel.fromFirestore(doc);
      // Update cache
      await _cacheBox.put(patientId, patient.toJson());
      return patient;
    }
    return null;
  }

  /// Get all patients for a user
  Future<List<PatientModel>> getPatients(String userId) async {
    final snapshot = await _patientsCollection
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .get();

    final patients = snapshot.docs
        .map((doc) => PatientModel.fromFirestore(doc))
        .toList();

    // Update cache
    for (final patient in patients) {
      await _cacheBox.put(patient.patientId, patient.toJson());
    }

    return patients;
  }

  /// Stream patients for real-time updates
  Stream<List<PatientModel>> streamPatients(String userId) {
    return _patientsCollection
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        final patient = PatientModel.fromFirestore(doc);
        // Update cache
        _cacheBox.put(patient.patientId, patient.toJson());
        return patient;
      }).toList();
    });
  }

  /// Update a patient
  Future<void> updatePatient(PatientModel patient) async {
    final updatedPatient = patient.copyWith(updatedAt: DateTime.now());

    // Update in Firestore
    await _patientsCollection
        .doc(patient.patientId)
        .update(updatedPatient.toFirestore());

    // Update cache
    await _cacheBox.put(patient.patientId, updatedPatient.toJson());
  }

  /// Delete a patient
  Future<void> deletePatient(String patientId) async {
    // Delete from Firestore
    await _patientsCollection.doc(patientId).delete();

    // Delete from cache
    await _cacheBox.delete(patientId);
  }

  /// Search patients by name or phone
  Future<List<PatientModel>> searchPatients(String userId, String query) async {
    final lowerQuery = query.toLowerCase();

    final snapshot = await _patientsCollection
        .where('userId', isEqualTo: userId)
        .get();

    return snapshot.docs
        .map((doc) => PatientModel.fromFirestore(doc))
        .where((patient) =>
            patient.name.toLowerCase().contains(lowerQuery) ||
            patient.phone.contains(query))
        .toList();
  }

  /// Get patient count
  Future<int> getPatientCount(String userId) async {
    final snapshot = await _patientsCollection
        .where('userId', isEqualTo: userId)
        .count()
        .get();

    return snapshot.count ?? 0;
  }

  /// Update last visit date
  Future<void> updateLastVisit(String patientId, DateTime visitDate) async {
    await _patientsCollection.doc(patientId).update({
      'lastVisitDate': Timestamp.fromDate(visitDate),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// Get cached patients (for offline use)
  List<PatientModel> getCachedPatients() {
    return _cacheBox.values
        .map((data) => PatientModel.fromJson(Map<String, dynamic>.from(data)))
        .toList();
  }
}

// Provider
final patientRepositoryProvider = Provider<PatientRepository>((ref) {
  final firestore = ref.watch(firestoreProvider);
  final cacheBox = Hive.box('patients_cache');
  return PatientRepository(firestore: firestore, cacheBox: cacheBox);
});

// Patients list provider
final patientsProvider =
    StreamProvider.family<List<PatientModel>, String>((ref, userId) {
  final repository = ref.watch(patientRepositoryProvider);
  return repository.streamPatients(userId);
});

// Single patient provider
final patientProvider =
    FutureProvider.family<PatientModel?, String>((ref, patientId) {
  final repository = ref.watch(patientRepositoryProvider);
  return repository.getPatient(patientId);
});
