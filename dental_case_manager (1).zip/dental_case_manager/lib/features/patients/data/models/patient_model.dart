import 'package:cloud_firestore/cloud_firestore.dart';

/// Patient Model
class PatientModel {
  final String patientId;
  final String userId;
  final String name;
  final String phone;
  final int age;
  final String gender;
  final String medicalHistory;
  final String allergies;
  final String smokingStatus;
  final String notes;
  final String? profilePhotoUrl;
  final String? profilePhotoLocal;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isActive;
  final List<String> tags;
  final DateTime? lastVisitDate;
  final String? nextAppointmentId;

  const PatientModel({
    required this.patientId,
    required this.userId,
    required this.name,
    required this.phone,
    required this.age,
    required this.gender,
    required this.medicalHistory,
    required this.allergies,
    required this.smokingStatus,
    required this.notes,
    this.profilePhotoUrl,
    this.profilePhotoLocal,
    required this.createdAt,
    required this.updatedAt,
    this.isActive = true,
    this.tags = const [],
    this.lastVisitDate,
    this.nextAppointmentId,
  });

  factory PatientModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return PatientModel(
      patientId: doc.id,
      userId: data['userId'] ?? '',
      name: data['name'] ?? '',
      phone: data['phone'] ?? '',
      age: data['age'] ?? 0,
      gender: data['gender'] ?? 'male',
      medicalHistory: data['medicalHistory'] ?? '',
      allergies: data['allergies'] ?? '',
      smokingStatus: data['smokingStatus'] ?? 'never',
      notes: data['notes'] ?? '',
      profilePhotoUrl: data['profilePhotoUrl'],
      profilePhotoLocal: data['profilePhotoLocal'],
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isActive: data['isActive'] ?? true,
      tags: List<String>.from(data['tags'] ?? []),
      lastVisitDate: (data['lastVisitDate'] as Timestamp?)?.toDate(),
      nextAppointmentId: data['nextAppointmentId'],
    );
  }

  factory PatientModel.fromJson(Map<String, dynamic> json) {
    return PatientModel(
      patientId: json['patientId'] ?? '',
      userId: json['userId'] ?? '',
      name: json['name'] ?? '',
      phone: json['phone'] ?? '',
      age: json['age'] ?? 0,
      gender: json['gender'] ?? 'male',
      medicalHistory: json['medicalHistory'] ?? '',
      allergies: json['allergies'] ?? '',
      smokingStatus: json['smokingStatus'] ?? 'never',
      notes: json['notes'] ?? '',
      profilePhotoUrl: json['profilePhotoUrl'],
      profilePhotoLocal: json['profilePhotoLocal'],
      createdAt: json['createdAt'] is Timestamp
          ? (json['createdAt'] as Timestamp).toDate()
          : DateTime.parse(json['createdAt']),
      updatedAt: json['updatedAt'] is Timestamp
          ? (json['updatedAt'] as Timestamp).toDate()
          : DateTime.parse(json['updatedAt']),
      isActive: json['isActive'] ?? true,
      tags: List<String>.from(json['tags'] ?? []),
      lastVisitDate: json['lastVisitDate'] != null
          ? (json['lastVisitDate'] is Timestamp
              ? (json['lastVisitDate'] as Timestamp).toDate()
              : DateTime.parse(json['lastVisitDate']))
          : null,
      nextAppointmentId: json['nextAppointmentId'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'patientId': patientId,
      'userId': userId,
      'name': name,
      'phone': phone,
      'age': age,
      'gender': gender,
      'medicalHistory': medicalHistory,
      'allergies': allergies,
      'smokingStatus': smokingStatus,
      'notes': notes,
      'profilePhotoUrl': profilePhotoUrl,
      'profilePhotoLocal': profilePhotoLocal,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'isActive': isActive,
      'tags': tags,
      'lastVisitDate':
          lastVisitDate != null ? Timestamp.fromDate(lastVisitDate!) : null,
      'nextAppointmentId': nextAppointmentId,
    };
  }

  Map<String, dynamic> toJson() {
    return {
      'patientId': patientId,
      'userId': userId,
      'name': name,
      'phone': phone,
      'age': age,
      'gender': gender,
      'medicalHistory': medicalHistory,
      'allergies': allergies,
      'smokingStatus': smokingStatus,
      'notes': notes,
      'profilePhotoUrl': profilePhotoUrl,
      'profilePhotoLocal': profilePhotoLocal,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'isActive': isActive,
      'tags': tags,
      'lastVisitDate': lastVisitDate?.toIso8601String(),
      'nextAppointmentId': nextAppointmentId,
    };
  }

  PatientModel copyWith({
    String? patientId,
    String? userId,
    String? name,
    String? phone,
    int? age,
    String? gender,
    String? medicalHistory,
    String? allergies,
    String? smokingStatus,
    String? notes,
    String? profilePhotoUrl,
    String? profilePhotoLocal,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isActive,
    List<String>? tags,
    DateTime? lastVisitDate,
    String? nextAppointmentId,
  }) {
    return PatientModel(
      patientId: patientId ?? this.patientId,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      medicalHistory: medicalHistory ?? this.medicalHistory,
      allergies: allergies ?? this.allergies,
      smokingStatus: smokingStatus ?? this.smokingStatus,
      notes: notes ?? this.notes,
      profilePhotoUrl: profilePhotoUrl ?? this.profilePhotoUrl,
      profilePhotoLocal: profilePhotoLocal ?? this.profilePhotoLocal,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isActive: isActive ?? this.isActive,
      tags: tags ?? this.tags,
      lastVisitDate: lastVisitDate ?? this.lastVisitDate,
      nextAppointmentId: nextAppointmentId ?? this.nextAppointmentId,
    );
  }

  @override
  String toString() {
    return 'PatientModel(patientId: $patientId, name: $name, phone: $phone)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is PatientModel && other.patientId == patientId;
  }

  @override
  int get hashCode => patientId.hashCode;
}
