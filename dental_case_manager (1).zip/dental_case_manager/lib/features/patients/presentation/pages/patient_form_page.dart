import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:io';

import '../../data/models/patient_model.dart';
import '../../data/repositories/patient_repository.dart';
import '../../../auth/data/auth_service.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/animated_widgets.dart';

class PatientFormPage extends ConsumerStatefulWidget {
  final String? patientId;

  const PatientFormPage({super.key, this.patientId});

  @override
  ConsumerState<PatientFormPage> createState() => _PatientFormPageState();
}

class _PatientFormPageState extends ConsumerState<PatientFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _ageController = TextEditingController();
  final _medicalHistoryController = TextEditingController();
  final _allergiesController = TextEditingController();
  final _notesController = TextEditingController();

  String _gender = 'male';
  String _smokingStatus = 'never';
  File? _profileImage;
  bool _isLoading = false;
  bool _isEditing = false;
  PatientModel? _existingPatient;

  @override
  void initState() {
    super.initState();
    _isEditing = widget.patientId != null;
    if (_isEditing) {
      _loadPatient();
    }
  }

  Future<void> _loadPatient() async {
    final patient = await ref
        .read(patientRepositoryProvider)
        .getPatient(widget.patientId!);

    if (patient != null && mounted) {
      setState(() {
        _existingPatient = patient;
        _nameController.text = patient.name;
        _phoneController.text = patient.phone;
        _ageController.text = patient.age.toString();
        _gender = patient.gender;
        _smokingStatus = patient.smokingStatus;
        _medicalHistoryController.text = patient.medicalHistory;
        _allergiesController.text = patient.allergies;
        _notesController.text = patient.notes;
      });
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _ageController.dispose();
    _medicalHistoryController.dispose();
    _allergiesController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 800,
      maxHeight: 800,
      imageQuality: 85,
    );

    if (pickedFile != null) {
      setState(() {
        _profileImage = File(pickedFile.path);
      });
    }
  }

  Future<void> _takePhoto() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 800,
      maxHeight: 800,
      imageQuality: 85,
    );

    if (pickedFile != null) {
      setState(() {
        _profileImage = File(pickedFile.path);
      });
    }
  }

  Future<void> _savePatient() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final user = ref.read(authStateProvider).value;
      if (user == null) return;

      final repository = ref.read(patientRepositoryProvider);

      if (_isEditing && _existingPatient != null) {
        // Update existing patient
        await repository.updatePatient(_existingPatient!.copyWith(
          name: _nameController.text.trim(),
          phone: _phoneController.text.trim(),
          age: int.parse(_ageController.text),
          gender: _gender,
          smokingStatus: _smokingStatus,
          medicalHistory: _medicalHistoryController.text.trim(),
          allergies: _allergiesController.text.trim(),
          notes: _notesController.text.trim(),
          // profilePhotoUrl would be updated if new image uploaded
        ));
      } else {
        // Create new patient
        await repository.createPatient(
          userId: user.uid,
          name: _nameController.text.trim(),
          phone: _phoneController.text.trim(),
          age: int.parse(_ageController.text),
          gender: _gender,
          smokingStatus: _smokingStatus,
          medicalHistory: _medicalHistoryController.text.trim(),
          allergies: _allergiesController.text.trim(),
          notes: _notesController.text.trim(),
        );
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_isEditing
                ? 'Patient updated successfully'
                : 'Patient created successfully'),
            backgroundColor: AppTheme.successColor,
            behavior: SnackBarBehavior.floating,
          ),
        );
        context.pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: AppTheme.errorColor,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Patient' : 'New Patient'),
        actions: [
          TextButton(
            onPressed: _isLoading ? null : _savePatient,
            child: const Text('Save'),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Profile Photo Section
              Center(
                child: GestureDetector(
                  onTap: _showImageSourceDialog,
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: _profileImage == null &&
                              (_existingPatient?.profilePhotoUrl == null ||
                                  _existingPatient!.profilePhotoUrl!.isEmpty)
                          ? AppTheme.primaryGradient
                          : null,
                      border: Border.all(color: AppTheme.primaryColor, width: 2),
                    ),
                    child: Stack(
                      children: [
                        if (_profileImage != null)
                          ClipOval(
                            child: Image.file(
                              _profileImage!,
                              fit: BoxFit.cover,
                              width: 120,
                              height: 120,
                            ),
                          )
                        else if (_existingPatient?.profilePhotoUrl != null &&
                            _existingPatient!.profilePhotoUrl!.isNotEmpty)
                          ClipOval(
                            child: Image.network(
                              _existingPatient!.profilePhotoUrl!,
                              fit: BoxFit.cover,
                              width: 120,
                              height: 120,
                            ),
                          )
                        else
                          Center(
                            child: Text(
                              _nameController.text.isEmpty
                                  ? '?'
                                  : _nameController.text[0].toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 40,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: const BoxDecoration(
                              color: AppTheme.primaryColor,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.camera_alt,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ).animate().scale(duration: 400.ms, curve: Curves.elasticOut),
              ),

              const SizedBox(height: 8),
              Center(
                child: TextButton(
                  onPressed: _showImageSourceDialog,
                  child: const Text('Add Photo'),
                ),
              ),

              const SizedBox(height: 24),

              // Basic Information Section
              _buildSectionTitle('Basic Information'),
              const SizedBox(height: 12),

              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Patient Name *',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                textCapitalization: TextCapitalization.words,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter patient name';
                  }
                  return null;
                },
              ).animate().fadeIn(delay: 100.ms).slideX(begin: 0.1, end: 0),

              const SizedBox(height: 16),

              TextFormField(
                controller: _phoneController,
                decoration: const InputDecoration(
                  labelText: 'Phone Number *',
                  prefixIcon: Icon(Icons.phone_outlined),
                ),
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter phone number';
                  }
                  return null;
                },
              ).animate().fadeIn(delay: 150.ms).slideX(begin: 0.1, end: 0),

              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _ageController,
                      decoration: const InputDecoration(
                        labelText: 'Age *',
                        prefixIcon: Icon(Icons.cake_outlined),
                      ),
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Required';
                        }
                        final age = int.tryParse(value);
                        if (age == null || age < 0 || age > 150) {
                          return 'Invalid age';
                        }
                        return null;
                      },
                    ).animate().fadeIn(delay: 200.ms).slideX(begin: 0.1, end: 0),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _gender,
                      decoration: const InputDecoration(
                        labelText: 'Gender',
                        prefixIcon: Icon(Icons.wc_outlined),
                      ),
                      items: const [
                        DropdownMenuItem(value: 'male', child: Text('Male')),
                        DropdownMenuItem(value: 'female', child: Text('Female')),
                        DropdownMenuItem(value: 'other', child: Text('Other')),
                      ],
                      onChanged: (value) {
                        setState(() => _gender = value!);
                      },
                    ).animate().fadeIn(delay: 250.ms).slideX(begin: 0.1, end: 0),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // Medical Information Section
              _buildSectionTitle('Medical Information'),
              const SizedBox(height: 12),

              TextFormField(
                controller: _medicalHistoryController,
                decoration: const InputDecoration(
                  labelText: 'Medical History',
                  prefixIcon: Icon(Icons.medical_information_outlined),
                  alignLabelWithHint: true,
                ),
                maxLines: 3,
                textCapitalization: TextCapitalization.sentences,
              ).animate().fadeIn(delay: 300.ms).slideX(begin: 0.1, end: 0),

              const SizedBox(height: 16),

              TextFormField(
                controller: _allergiesController,
                decoration: const InputDecoration(
                  labelText: 'Allergies',
                  prefixIcon: Icon(Icons.warning_amber_outlined),
                ),
                textCapitalization: TextCapitalization.sentences,
              ).animate().fadeIn(delay: 350.ms).slideX(begin: 0.1, end: 0),

              const SizedBox(height: 16),

              DropdownButtonFormField<String>(
                value: _smokingStatus,
                decoration: const InputDecoration(
                  labelText: 'Smoking Status',
                  prefixIcon: Icon(Icons.smoking_rooms_outlined),
                ),
                items: const [
                  DropdownMenuItem(value: 'never', child: Text('Never Smoked')),
                  DropdownMenuItem(value: 'former', child: Text('Former Smoker')),
                  DropdownMenuItem(value: 'current', child: Text('Current Smoker')),
                ],
                onChanged: (value) {
                  setState(() => _smokingStatus = value!);
                },
              ).animate().fadeIn(delay: 400.ms).slideX(begin: 0.1, end: 0),

              const SizedBox(height: 24),

              // Notes Section
              _buildSectionTitle('Additional Notes'),
              const SizedBox(height: 12),

              TextFormField(
                controller: _notesController,
                decoration: const InputDecoration(
                  labelText: 'Notes',
                  prefixIcon: Icon(Icons.note_outlined),
                  alignLabelWithHint: true,
                ),
                maxLines: 4,
                textCapitalization: TextCapitalization.sentences,
              ).animate().fadeIn(delay: 450.ms).slideX(begin: 0.1, end: 0),

              const SizedBox(height: 32),

              // Save Button
              AnimatedButton(
                text: _isEditing ? 'Update Patient' : 'Create Patient',
                isLoading: _isLoading,
                onPressed: _savePatient,
                width: double.infinity,
              ).animate().fadeIn(delay: 500.ms),

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryColor,
          ),
    );
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take Photo'),
              onTap: () {
                Navigator.pop(context);
                _takePhoto();
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickImage();
              },
            ),
            if (_profileImage != null || _existingPatient?.profilePhotoUrl != null)
              ListTile(
                leading: const Icon(Icons.delete, color: AppTheme.errorColor),
                title: const Text('Remove Photo',
                    style: TextStyle(color: AppTheme.errorColor)),
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _profileImage = null);
                },
              ),
          ],
        ),
      ),
    );
  }
}
