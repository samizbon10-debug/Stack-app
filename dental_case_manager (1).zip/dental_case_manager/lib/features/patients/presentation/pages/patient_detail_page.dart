import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:photo_view/photo_view.dart';

import '../../data/models/patient_model.dart';
import '../../data/repositories/patient_repository.dart';
import '../../../treatments/data/models/treatment_model.dart';
import '../../../treatments/data/repositories/treatment_repository.dart';
import '../../../appointments/data/models/appointment_model.dart';
import '../../../appointments/data/repositories/appointment_repository.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/animated_widgets.dart';
import '../../../../core/utils/helpers.dart';

class PatientDetailPage extends ConsumerStatefulWidget {
  final String patientId;

  const PatientDetailPage({super.key, required this.patientId});

  @override
  ConsumerState<PatientDetailPage> createState() => _PatientDetailPageState();
}

class _PatientDetailPageState extends ConsumerState<PatientDetailPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final patientAsync = ref.watch(patientProvider(widget.patientId));
    final treatmentsAsync =
        ref.watch(patientTreatmentsProvider(widget.patientId));
    final appointmentsAsync =
        ref.watch(patientAppointmentsProvider(widget.patientId));

    return patientAsync.when(
      data: (patient) {
        if (patient == null) {
          return Scaffold(
            appBar: AppBar(title: const Text('Patient Not Found')),
            body: const Center(child: Text('Patient not found')),
          );
        }

        return Scaffold(
          body: NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) {
              return [
                // Patient Header
                SliverAppBar(
                  expandedHeight: 320,
                  floating: false,
                  pinned: true,
                  actions: [
                    IconButton(
                      icon: const Icon(Icons.edit_outlined),
                      onPressed: () =>
                          context.push('/patients/${patient.patientId}/edit'),
                    ),
                    IconButton(
                      icon: const Icon(Icons.more_vert),
                      onPressed: () => _showOptionsBottomSheet(patient),
                    ),
                  ],
                  flexibleSpace: FlexibleSpaceBar(
                    background: _buildPatientHeader(patient),
                  ),
                  bottom: TabBar(
                    controller: _tabController,
                    labelColor: AppTheme.primaryColor,
                    unselectedLabelColor: Colors.grey,
                    indicatorColor: AppTheme.primaryColor,
                    tabs: const [
                      Tab(text: 'Info'),
                      Tab(text: 'Treatments'),
                      Tab(text: 'Photos'),
                      Tab(text: 'Appointments'),
                    ],
                  ),
                ),
              ];
            },
            body: TabBarView(
              controller: _tabController,
              children: [
                // Info Tab
                _buildInfoTab(patient),

                // Treatments Tab
                _buildTreatmentsTab(treatmentsAsync),

                // Photos Tab
                _buildPhotosTab(treatmentsAsync),

                // Appointments Tab
                _buildAppointmentsTab(appointmentsAsync),
              ],
            ),
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: () =>
                context.push('/patients/${patient.patientId}/treatments/new'),
            backgroundColor: AppTheme.primaryColor,
            child: const Icon(Icons.add),
          ).animate().scale(delay: 400.ms),
        );
      },
      loading: () => Scaffold(
        appBar: AppBar(title: const Text('Loading...')),
        body: const Center(child: CircularProgressIndicator()),
      ),
      error: (error, _) => Scaffold(
        appBar: AppBar(title: const Text('Error')),
        body: Center(child: Text('Error: $error')),
      ),
    );
  }

  Widget _buildPatientHeader(PatientModel patient) {
    return Container(
      decoration: const BoxDecoration(
        gradient: AppTheme.headerGradient,
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 20),

              // Profile Photo with Hero
              GestureDetector(
                onTap: () => _showFullPhoto(patient),
                child: Hero(
                  tag: 'patient_avatar_${patient.patientId}',
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: AppTheme.primaryGradient,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: patient.profilePhotoUrl != null
                        ? ClipOval(
                            child: CachedNetworkImage(
                              imageUrl: patient.profilePhotoUrl!,
                              fit: BoxFit.cover,
                              placeholder: (context, url) =>
                                  const CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                              errorWidget: (context, url, error) => _buildInitials(patient),
                            ),
                          )
                        : _buildInitials(patient),
                  ),
                ),
              ).animate().scale(duration: 500.ms, curve: Curves.elasticOut),

              const SizedBox(height: 16),

              // Name
              Text(
                patient.name,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
              ).animate().fadeIn(delay: 100.ms),

              const SizedBox(height: 8),

              // Quick Info Row
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildQuickInfoChip(
                    icon: Icons.cake_outlined,
                    label: '${patient.age} years',
                  ),
                  const SizedBox(width: 12),
                  _buildQuickInfoChip(
                    icon: patient.gender == 'male'
                        ? Icons.male
                        : patient.gender == 'female'
                            ? Icons.female
                            : Icons.person,
                    label: patient.gender.capitalize(),
                  ),
                  const SizedBox(width: 12),
                  _buildQuickInfoChip(
                    icon: Icons.phone_outlined,
                    label: AppHelpers.formatPhoneNumber(patient.phone),
                  ),
                ],
              ).animate().fadeIn(delay: 200.ms),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInitials(PatientModel patient) {
    return Center(
      child: Text(
        AppHelpers.getInitials(patient.name),
        style: const TextStyle(
          color: Colors.white,
          fontSize: 36,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildQuickInfoChip({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white, size: 14),
          const SizedBox(width: 4),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoTab(PatientModel patient) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildInfoSection(
            title: 'Contact Information',
            children: [
              _buildInfoRow(Icons.phone_outlined, 'Phone', patient.phone),
              _buildInfoRow(
                  Icons.cake_outlined, 'Age', '${patient.age} years'),
              _buildInfoRow(
                  Icons.wc_outlined, 'Gender', patient.gender.capitalize()),
            ],
          ),
          const SizedBox(height: 16),
          _buildInfoSection(
            title: 'Medical Information',
            children: [
              _buildInfoRow(Icons.medical_information_outlined,
                  'Medical History', patient.medicalHistory,
                  isMultiline: true),
              _buildInfoRow(Icons.warning_amber_outlined, 'Allergies',
                  patient.allergies.isEmpty ? 'None' : patient.allergies),
              _buildInfoRow(
                Icons.smoking_rooms_outlined,
                'Smoking Status',
                patient.smokingStatus == 'never'
                    ? 'Never Smoked'
                    : patient.smokingStatus == 'former'
                        ? 'Former Smoker'
                        : 'Current Smoker',
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (patient.notes.isNotEmpty)
            _buildInfoSection(
              title: 'Notes',
              children: [
                _buildInfoRow(Icons.note_outlined, '', patient.notes,
                    isMultiline: true),
              ],
            ),
          if (patient.tags.isNotEmpty) ...[
            const SizedBox(height: 16),
            _buildInfoSection(
              title: 'Tags',
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: patient.tags.map((tag) {
                    return Chip(
                      label: Text(tag),
                      backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
                      labelStyle: const TextStyle(color: AppTheme.primaryColor),
                    );
                  }).toList(),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoSection({
    required String title,
    required List<Widget> children,
  }) {
    return AnimatedCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    ).animate().fadeIn(duration: 300.ms).slideY(begin: 0.1, end: 0);
  }

  Widget _buildInfoRow(IconData icon, String label, String value,
      {bool isMultiline = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment:
            isMultiline ? CrossAxisAlignment.start : CrossAxisAlignment.center,
        children: [
          Icon(icon, color: AppTheme.primaryColor, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (label.isNotEmpty) ...[
                  Text(
                    label,
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 2),
                ],
                Text(
                  value.isEmpty ? 'Not specified' : value,
                  style: TextStyle(
                    fontSize: 14,
                    color: value.isEmpty ? Colors.grey : AppTheme.textPrimary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTreatmentsTab(AsyncValue<List<TreatmentModel>> treatmentsAsync) {
    return treatmentsAsync.when(
      data: (treatments) {
        if (treatments.isEmpty) {
          return _buildEmptyTab(
            icon: Icons.medical_services_outlined,
            title: 'No Treatments Yet',
            subtitle: 'Add a treatment record for this patient',
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: treatments.length,
          itemBuilder: (context, index) {
            final treatment = treatments[index];
            return AnimatedListItem(
              index: index,
              child: _buildTreatmentCard(treatment),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }

  Widget _buildTreatmentCard(TreatmentModel treatment) {
    final categoryColor = AppHelpers.getTreatmentColor(treatment.category);
    final categoryName = treatment.category == 'orthodontics'
        ? 'Orthodontics'
        : treatment.category == 'fillings'
            ? 'Fillings'
            : 'Scaling & Polishing';

    return AnimatedCard(
      margin: const EdgeInsets.only(bottom: 12),
      onTap: () =>
          context.push('/treatments/${treatment.treatmentId}'),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: categoryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              treatment.category == 'orthodontics'
                  ? Icons.straighten
                  : treatment.category == 'fillings'
                      ? Icons.healing
                      : Icons.cleaning_services,
              color: categoryColor,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      categoryName,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: categoryColor,
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (treatment.toothNumber != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'Tooth #${treatment.toothNumber}',
                          style: const TextStyle(fontSize: 10),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  treatment.diagnosis.isNotEmpty
                      ? treatment.diagnosis
                      : 'No diagnosis recorded',
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(Icons.calendar_today_outlined,
                        size: 12, color: Colors.grey.shade500),
                    const SizedBox(width: 4),
                    Text(
                      AppHelpers.formatDate(treatment.date),
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppHelpers.getStatusColor(treatment.status)
                            .withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        treatment.status.toUpperCase(),
                        style: TextStyle(
                          fontSize: 10,
                          color: AppHelpers.getStatusColor(treatment.status),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (treatment.images.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.photo_library,
                      size: 14, color: AppTheme.primaryColor),
                  const SizedBox(width: 4),
                  Text(
                    '${treatment.images.length}',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPhotosTab(AsyncValue<List<TreatmentModel>> treatmentsAsync) {
    return treatmentsAsync.when(
      data: (treatments) {
        final allImages = <Map<String, dynamic>>[];

        for (final treatment in treatments) {
          for (final image in treatment.images) {
            allImages.add({
              'image': image,
              'treatment': treatment,
            });
          }
        }

        if (allImages.isEmpty) {
          return _buildEmptyTab(
            icon: Icons.photo_library_outlined,
            title: 'No Photos Yet',
            subtitle: 'Add photos to treatment records',
          );
        }

        // Group by label
        final beforeImages =
            allImages.where((i) => i['image'].label == 'before').toList();
        final duringImages =
            allImages.where((i) => i['image'].label == 'during').toList();
        final afterImages =
            allImages.where((i) => i['image'].label == 'after').toList();

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (beforeImages.isNotEmpty) ...[
                _buildPhotoSection('Before', beforeImages),
                const SizedBox(height: 16),
              ],
              if (duringImages.isNotEmpty) ...[
                _buildPhotoSection('During', duringImages),
                const SizedBox(height: 16),
              ],
              if (afterImages.isNotEmpty)
                _buildPhotoSection('After', afterImages),
            ],
          ),
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }

  Widget _buildPhotoSection(String title, List<Map<String, dynamic>> images) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: images.length,
          itemBuilder: (context, index) {
            final imageData = images[index];
            final image = imageData['image'] as TreatmentImage;

            return GestureDetector(
              onTap: () => _showPhotoGallery(images, index),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Hero(
                  tag: image.imageId,
                  child: CachedNetworkImage(
                    imageUrl: image.url,
                    fit: BoxFit.cover,
                    placeholder: (context, url) => Container(
                      color: Colors.grey.shade200,
                      child: const Center(
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    ),
                    errorWidget: (context, url, error) => Container(
                      color: Colors.grey.shade200,
                      child: const Icon(Icons.error_outline),
                    ),
                  ),
                ),
              ),
            ).animate().fadeIn(delay: Duration(milliseconds: 50 * index));
          },
        ),
      ],
    );
  }

  Widget _buildAppointmentsTab(
      AsyncValue<List<AppointmentModel>> appointmentsAsync) {
    return appointmentsAsync.when(
      data: (appointments) {
        if (appointments.isEmpty) {
          return _buildEmptyTab(
            icon: Icons.calendar_today_outlined,
            title: 'No Appointments Yet',
            subtitle: 'Schedule an appointment for this patient',
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: appointments.length,
          itemBuilder: (context, index) {
            final appointment = appointments[index];
            return AnimatedListItem(
              index: index,
              child: _buildAppointmentCard(appointment),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }

  Widget _buildAppointmentCard(AppointmentModel appointment) {
    return AnimatedCard(
      margin: const EdgeInsets.only(bottom: 12),
      onTap: () =>
          context.push('/appointments/${appointment.appointmentId}'),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: AppHelpers.getStatusColor(appointment.status)
                  .withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  appointment.date.day.toString(),
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppHelpers.getStatusColor(appointment.status),
                  ),
                ),
                Text(
                  ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][appointment.date.month - 1],
                  style: TextStyle(
                    fontSize: 10,
                    color: AppHelpers.getStatusColor(appointment.status),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  appointment.title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  appointment.treatmentType,
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${appointment.formattedTime} • ${appointment.duration} min',
                  style: TextStyle(
                    color: Colors.grey.shade500,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: AppHelpers.getStatusColor(appointment.status)
                  .withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              appointment.status.toUpperCase(),
              style: TextStyle(
                fontSize: 10,
                color: AppHelpers.getStatusColor(appointment.status),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyTab({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 64, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.grey.shade600,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.grey.shade500,
                ),
          ),
        ],
      ),
    ).animate().fadeIn();
  }

  void _showFullPhoto(PatientModel patient) {
    if (patient.profilePhotoUrl == null) return;

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            iconTheme: const IconThemeData(color: Colors.white),
          ),
          body: Center(
            child: Hero(
              tag: 'patient_avatar_${patient.patientId}',
              child: PhotoView(
                imageProvider: CachedNetworkImageProvider(patient.profilePhotoUrl!),
                minScale: PhotoViewComputedScale.contained,
                maxScale: PhotoViewComputedScale.covered * 2,
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showPhotoGallery(List<Map<String, dynamic>> images, int initialIndex) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => _PhotoGalleryView(
          images: images,
          initialIndex: initialIndex,
        ),
      ),
    );
  }

  void _showOptionsBottomSheet(PatientModel patient) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: const Text('Edit Patient'),
              onTap: () {
                Navigator.pop(context);
                context.push('/patients/${patient.patientId}/edit');
              },
            ),
            ListTile(
              leading: const Icon(Icons.add_photo_alternate_outlined),
              title: const Text('Change Photo'),
              onTap: () {
                Navigator.pop(context);
                // Implement photo picker
              },
            ),
            ListTile(
              leading: const Icon(Icons.calendar_today_outlined),
              title: const Text('Schedule Appointment'),
              onTap: () {
                Navigator.pop(context);
                context.push('/patients/${patient.patientId}/appointments/new');
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: AppTheme.errorColor),
              title: const Text('Delete Patient',
                  style: TextStyle(color: AppTheme.errorColor)),
              onTap: () {
                Navigator.pop(context);
                _showDeleteConfirmation(patient);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmation(PatientModel patient) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Patient'),
        content: Text(
            'Are you sure you want to delete ${patient.name}? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              final repository = ref.read(patientRepositoryProvider);
              await repository.deletePatient(patient.patientId);
              if (context.mounted) context.pop();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorColor,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class _PhotoGalleryView extends StatefulWidget {
  final List<Map<String, dynamic>> images;
  final int initialIndex;

  const _PhotoGalleryView({
    required this.images,
    required this.initialIndex,
  });

  @override
  State<_PhotoGalleryView> createState() => _PhotoGalleryViewState();
}

class _PhotoGalleryViewState extends State<_PhotoGalleryView> {
  late PageController _pageController;
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          '${_currentIndex + 1} / ${widget.images.length}',
          style: const TextStyle(color: Colors.white),
        ),
      ),
      body: PageView.builder(
        controller: _pageController,
        itemCount: widget.images.length,
        onPageChanged: (index) {
          setState(() => _currentIndex = index);
        },
        itemBuilder: (context, index) {
          final imageData = widget.images[index];
          final image = imageData['image'] as TreatmentImage;

          return Center(
            child: Hero(
              tag: image.imageId,
              child: PhotoView(
                imageProvider: CachedNetworkImageProvider(image.url),
                minScale: PhotoViewComputedScale.contained,
                maxScale: PhotoViewComputedScale.covered * 3,
              ),
            ),
          );
        },
      ),
    );
  }
}
