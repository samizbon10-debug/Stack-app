import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../../models/patient_model.dart';
import '../../../models/treatment_model.dart';
import '../../../treatments/data/treatments_provider.dart';
import '../../../appointments/data/appointments_provider.dart';
import '../../data/patients_provider.dart';
import 'add_patient_screen.dart';
import '../../treatments/presentation/screens/add_treatment_screen.dart';

class PatientDetailScreen extends ConsumerStatefulWidget {
  final PatientModel patient;

  const PatientDetailScreen({super.key, required this.patient});

  @override
  ConsumerState<PatientDetailScreen> createState() => _PatientDetailScreenState();
}

class _PatientDetailScreenState extends ConsumerState<PatientDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final treatmentsAsync = ref.watch(patientTreatmentsProvider(widget.patient.patientId));
    final appointmentsAsync = ref.watch(patientAppointmentsProvider(widget.patient.patientId));

    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) {
          return [
            // Sliver App Bar with Hero Image
            SliverAppBar(
              expandedHeight: 280,
              pinned: true,
              floating: false,
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: AppColors.headerGradient,
                  ),
                  child: SafeArea(
                    child: _buildPatientHeader(context),
                  ),
                ),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => AddPatientScreen(
                          userId: widget.patient.userId,
                          existingPatient: widget.patient,
                        ),
                      ),
                    );
                  },
                ),
                PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'delete') {
                      _showDeleteConfirmation(context);
                    }
                  },
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'delete',
                      child: ListTile(
                        leading: Icon(Icons.delete, color: AppColors.error),
                        title: Text('Delete Patient'),
                      ),
                    ),
                  ],
                ),
              ],
            ),

            // Tab Bar
            SliverPersistentHeader(
              delegate: _SliverTabBarDelegate(
                TabBar(
                  controller: _tabController,
                  labelColor: AppColors.primary,
                  unselectedLabelColor: AppColors.textSecondary,
                  indicatorColor: AppColors.primary,
                  tabs: const [
                    Tab(text: 'Overview'),
                    Tab(text: 'Orthodontics'),
                    Tab(text: 'Fillings'),
                    Tab(text: 'Scale & Polish'),
                  ],
                ),
              ),
              pinned: true,
            ),
          ];
        },
        body: TabBarView(
          controller: _tabController,
          children: [
            _buildOverviewTab(treatmentsAsync, appointmentsAsync),
            _buildTreatmentsTab(treatmentsAsync, TreatmentCategory.orthodontics),
            _buildTreatmentsTab(treatmentsAsync, TreatmentCategory.fillings),
            _buildTreatmentsTab(treatmentsAsync, TreatmentCategory.scalingPolishing),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => AddTreatmentScreen(
                patientId: widget.patient.patientId,
                userId: widget.patient.userId,
              ),
            ),
          );
        },
        icon: const Icon(Icons.add),
        label: const Text('Add Treatment'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ).animate().scale(duration: 300.ms, curve: Curves.elasticOut),
    );
  }

  Widget _buildPatientHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(AppSizes.paddingL),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Profile Photo with Hero Animation
          Hero(
            tag: 'patient_photo_${widget.patient.patientId}',
            child: Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: CircleAvatar(
                radius: 48,
                backgroundImage: widget.patient.profilePhoto != null
                    ? NetworkImage(widget.patient.profilePhoto!)
                    : null,
                backgroundColor: Colors.white,
                child: widget.patient.profilePhoto == null
                    ? Text(
                        widget.patient.name.isNotEmpty
                            ? widget.patient.name[0].toUpperCase()
                            : 'P',
                        style: const TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.bold,
                          fontSize: 40,
                        ),
                      )
                    : null,
              ),
            ),
          )
              .animate()
              .scale(duration: 400.ms, curve: Curves.elasticOut)
              .fadeIn(),

          const SizedBox(height: AppSizes.spacingM),

          // Patient Name
          Text(
            widget.patient.name,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
          )
              .animate()
              .fadeIn(delay: 100.ms)
              .slideY(begin: 0.2, end: 0),

          const SizedBox(height: AppSizes.spacingXS),

          // Age and Gender
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildInfoChip(
                '${widget.patient.age} years',
                Icons.cake,
              ),
              const SizedBox(width: AppSizes.spacingS),
              _buildInfoChip(
                widget.patient.gender.name.toUpperCase(),
                Icons.wc,
              ),
            ],
          )
              .animate()
              .fadeIn(delay: 200.ms)
              .slideY(begin: 0.2, end: 0),

          const SizedBox(height: AppSizes.spacingS),

          // Phone
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.phone, size: 16, color: Colors.white70),
              const SizedBox(width: 4),
              Text(
                widget.patient.phone,
                style: const TextStyle(color: Colors.white70),
              ),
            ],
          ).animate().fadeIn(delay: 300.ms),
        ],
      ),
    );
  }

  Widget _buildInfoChip(String text, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.white),
          const SizedBox(width: 4),
          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOverviewTab(
    AsyncValue<List<TreatmentModel>> treatmentsAsync,
    AsyncValue appointmentsAsync,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppSizes.paddingM),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Allergies Warning
          if (widget.patient.allergies.isNotEmpty) ...[
            _buildAllergyWarning(),
            const SizedBox(height: AppSizes.spacingM),
          ],

          // Medical History Card
          _buildMedicalHistoryCard(),
          const SizedBox(height: AppSizes.spacingM),

          // Smoking Status
          _buildSmokingStatusCard(),
          const SizedBox(height: AppSizes.spacingM),

          // Treatment Summary
          treatmentsAsync.when(
            data: (treatments) => _buildTreatmentSummaryCard(treatments),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (_, __) => const SizedBox.shrink(),
          ),

          const SizedBox(height: AppSizes.spacingM),

          // Recent Appointments
          appointmentsAsync.when(
            data: (appointments) =>
                _buildRecentAppointmentsCard(appointments as List),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (_, __) => const SizedBox.shrink(),
          ),

          // Notes
          if (widget.patient.notes.isNotEmpty) ...[
            const SizedBox(height: AppSizes.spacingM),
            _buildNotesCard(),
          ],

          const SizedBox(height: 100), // Space for FAB
        ],
      ),
    );
  }

  Widget _buildAllergyWarning() {
    return Container(
      padding: const EdgeInsets.all(AppSizes.paddingM),
      decoration: BoxDecoration(
        color: AppColors.warningLight,
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
        border: Border.all(color: AppColors.warning.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.warning,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.warning, color: Colors.white),
          ),
          const SizedBox(width: AppSizes.spacingM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Allergies',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.warning,
                      ),
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: widget.patient.allergies.map((allergy) {
                    return Chip(
                      label: Text(allergy),
                      backgroundColor: Colors.white,
                      labelStyle: const TextStyle(
                        color: AppColors.warning,
                        fontSize: 12,
                      ),
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      visualDensity: VisualDensity.compact,
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMedicalHistoryCard() {
    final history = widget.patient.medicalHistory;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSizes.paddingM),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.medical_information, color: AppColors.primary),
                const SizedBox(width: AppSizes.spacingS),
                Text(
                  'Medical History',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
            const Divider(),
            if (history.conditions.isEmpty &&
                history.medications.isEmpty &&
                history.previousSurgeries.isEmpty)
              Text(
                'No medical history recorded',
                style: TextStyle(color: AppColors.textHint),
              )
            else ...[
              if (history.conditions.isNotEmpty) ...[
                Text(
                  'Conditions',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                ),
                const SizedBox(height: 4),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: history.conditions
                      .map((c) => Chip(label: Text(c)))
                      .toList(),
                ),
                const SizedBox(height: AppSizes.spacingM),
              ],
              if (history.medications.isNotEmpty) ...[
                Text(
                  'Current Medications',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                ),
                const SizedBox(height: 4),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: history.medications
                      .map((m) => Chip(label: Text(m)))
                      .toList(),
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSmokingStatusCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSizes.paddingM),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: _getSmokingColor().withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.smoking_rooms,
                color: _getSmokingColor(),
              ),
            ),
            const SizedBox(width: AppSizes.spacingM),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Smoking Status',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                  ),
                  Text(
                    _getSmokingStatusText(),
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getSmokingColor() {
    switch (widget.patient.smokingStatus) {
      case SmokingStatus.never:
        return AppColors.success;
      case SmokingStatus.former:
        return AppColors.warning;
      case SmokingStatus.current:
        return AppColors.error;
      case SmokingStatus.unknown:
        return AppColors.textHint;
    }
  }

  String _getSmokingStatusText() {
    switch (widget.patient.smokingStatus) {
      case SmokingStatus.never:
        return 'Never Smoked';
      case SmokingStatus.former:
        return 'Former Smoker';
      case SmokingStatus.current:
        return 'Current Smoker';
      case SmokingStatus.unknown:
        return 'Unknown';
    }
  }

  Widget _buildTreatmentSummaryCard(List<TreatmentModel> treatments) {
    final orthodontics = treatments
        .where((t) => t.category == TreatmentCategory.orthodontics)
        .length;
    final fillings =
        treatments.where((t) => t.category == TreatmentCategory.fillings).length;
    final scaling =
        treatments.where((t) => t.category == TreatmentCategory.scalingPolishing).length;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSizes.paddingM),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.analytics, color: AppColors.primary),
                const SizedBox(width: AppSizes.spacingS),
                Text(
                  'Treatment Summary',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildTreatmentStat(
                  'Orthodontics',
                  orthodontics,
                  AppColors.orthodontics,
                ),
                _buildTreatmentStat('Fillings', fillings, AppColors.fillings),
                _buildTreatmentStat(
                  'Scale & Polish',
                  scaling,
                  AppColors.scalingPolishing,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTreatmentStat(String label, int count, Color color) {
    return Column(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(
              count.toString(),
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: AppColors.textSecondary,
              ),
        ),
      ],
    );
  }

  Widget _buildRecentAppointmentsCard(List appointments) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSizes.paddingM),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.calendar_today, color: AppColors.primary),
                    const SizedBox(width: AppSizes.spacingS),
                    Text(
                      'Recent Appointments',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                TextButton(
                  onPressed: () {},
                  child: const Text('View All'),
                ),
              ],
            ),
            const Divider(),
            if (appointments.isEmpty)
              Text(
                'No appointments recorded',
                style: TextStyle(color: AppColors.textHint),
              )
            else
              Text('appointments.length appointments'),
          ],
        ),
      ),
    );
  }

  Widget _buildNotesCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSizes.paddingM),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.notes, color: AppColors.primary),
                const SizedBox(width: AppSizes.spacingS),
                Text(
                  'Notes',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
            const Divider(),
            Text(widget.patient.notes),
          ],
        ),
      ),
    );
  }

  Widget _buildTreatmentsTab(
    AsyncValue<List<TreatmentModel>> treatmentsAsync,
    TreatmentCategory category,
  ) {
    return treatmentsAsync.when(
      data: (treatments) {
        final filteredTreatments =
            treatments.where((t) => t.category == category).toList();

        if (filteredTreatments.isEmpty) {
          return _buildEmptyTreatments(category);
        }

        return ListView.builder(
          padding: const EdgeInsets.all(AppSizes.paddingM),
          itemCount: filteredTreatments.length,
          itemBuilder: (context, index) {
            final treatment = filteredTreatments[index];
            return _buildTreatmentCard(treatment)
                .animate()
                .fadeIn(delay: Duration(milliseconds: index * 50))
                .slideX(begin: 0.1, end: 0);
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }

  Widget _buildEmptyTreatments(TreatmentCategory category) {
    String categoryName;
    switch (category) {
      case TreatmentCategory.orthodontics:
        categoryName = 'Orthodontics';
        break;
      case TreatmentCategory.fillings:
        categoryName = 'Fillings';
        break;
      case TreatmentCategory.scalingPolishing:
        categoryName = 'Scaling & Polishing';
        break;
    }

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.medical_services_outlined,
            size: 64,
            color: AppColors.textHint,
          ),
          const SizedBox(height: AppSizes.spacingM),
          Text(
            'No $categoryName treatments',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: AppColors.textSecondary,
                ),
          ),
          const SizedBox(height: AppSizes.spacingS),
          Text(
            'Tap the + button to add a treatment',
            style: TextStyle(color: AppColors.textHint),
          ),
        ],
      ),
    );
  }

  Widget _buildTreatmentCard(TreatmentModel treatment) {
    return Card(
      margin: const EdgeInsets.only(bottom: AppSizes.spacingM),
      child: InkWell(
        onTap: () {
          // Navigate to treatment detail
        },
        borderRadius: BorderRadius.circular(AppSizes.cardBorderRadius),
        child: Padding(
          padding: const EdgeInsets.all(AppSizes.paddingM),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: _getCategoryColor(treatment.category),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        treatment.toothNumber ?? '#',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: AppSizes.spacingM),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          treatment.diagnosis,
                          style:
                              Theme.of(context).textTheme.titleSmall?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                        Text(
                          DateFormat('MMM d, y').format(treatment.date),
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AppColors.textSecondary,
                                  ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: _getStatusColor(treatment.status).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      _getStatusText(treatment.status),
                      style: TextStyle(
                        fontSize: 12,
                        color: _getStatusColor(treatment.status),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              if (treatment.treatmentNotes.isNotEmpty) ...[
                const SizedBox(height: AppSizes.spacingM),
                Text(
                  treatment.treatmentNotes,
                  style: Theme.of(context).textTheme.bodySmall,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
              if (treatment.images.totalImages > 0) ...[
                const SizedBox(height: AppSizes.spacingM),
                Row(
                  children: [
                    Icon(
                      Icons.photo_library,
                      size: 16,
                      color: AppColors.textSecondary,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${treatment.images.totalImages} photos',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: AppColors.textSecondary,
                          ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Color _getCategoryColor(TreatmentCategory category) {
    switch (category) {
      case TreatmentCategory.orthodontics:
        return AppColors.orthodontics;
      case TreatmentCategory.fillings:
        return AppColors.fillings;
      case TreatmentCategory.scalingPolishing:
        return AppColors.scalingPolishing;
    }
  }

  Color _getStatusColor(TreatmentStatus status) {
    switch (status) {
      case TreatmentStatus.planned:
        return AppColors.info;
      case TreatmentStatus.inProgress:
        return AppColors.warning;
      case TreatmentStatus.completed:
        return AppColors.success;
      case TreatmentStatus.cancelled:
        return AppColors.error;
    }
  }

  String _getStatusText(TreatmentStatus status) {
    switch (status) {
      case TreatmentStatus.planned:
        return 'Planned';
      case TreatmentStatus.inProgress:
        return 'In Progress';
      case TreatmentStatus.completed:
        return 'Completed';
      case TreatmentStatus.cancelled:
        return 'Cancelled';
    }
  }

  void _showDeleteConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Patient'),
        content: Text(
            'Are you sure you want to delete ${widget.patient.name}? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await ref
                  .read(patientsProvider(widget.patient.userId).notifier)
                  .deletePatient(widget.patient.patientId);
              if (mounted) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Patient deleted'),
                    backgroundColor: AppColors.success,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class _SliverTabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar tabBar;

  _SliverTabBarDelegate(this.tabBar);

  @override
  double get minExtent => tabBar.preferredSize.height;

  @override
  double get maxExtent => tabBar.preferredSize.height;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor,
      child: tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverTabBarDelegate oldDelegate) {
    return false;
  }
}
