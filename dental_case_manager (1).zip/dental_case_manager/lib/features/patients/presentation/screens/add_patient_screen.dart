import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../../models/patient_model.dart';
import '../../../patients/data/patients_provider.dart';
import '../../../services/storage_service.dart';

class AddPatientScreen extends ConsumerStatefulWidget {
  final String userId;
  final PatientModel? existingPatient;

  const AddPatientScreen({
    super.key,
    required this.userId,
    this.existingPatient,
  });

  @override
  ConsumerState<AddPatientScreen> createState() => _AddPatientScreenState();
}

class _AddPatientScreenState extends ConsumerState<AddPatientScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _ageController = TextEditingController();
  final _notesController = TextEditingController();
  final _allergyController = TextEditingController();
  final _conditionController = TextEditingController();
  final _medicationController = TextEditingController();

  Gender _selectedGender = Gender.male;
  SmokingStatus _smokingStatus = SmokingStatus.never;
  List<String> _allergies = [];
  List<String> _conditions = [];
  List<String> _medications = [];
  String? _profilePhotoPath;
  bool _isLoading = false;
  bool get _isEditing => widget.existingPatient != null;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      _loadExistingData();
    }
  }

  void _loadExistingData() {
    final patient = widget.existingPatient!;
    _nameController.text = patient.name;
    _phoneController.text = patient.phone;
    _ageController.text = patient.age.toString();
    _notesController.text = patient.notes;
    _selectedGender = patient.gender;
    _smokingStatus = patient.smokingStatus;
    _allergies = List.from(patient.allergies);
    _conditions = List.from(patient.medicalHistory.conditions);
    _medications = List.from(patient.medicalHistory.medications);
    _profilePhotoPath = patient.profilePhoto;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _ageController.dispose();
    _notesController.dispose();
    _allergyController.dispose();
    _conditionController.dispose();
    _medicationController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 85,
    );

    if (pickedFile != null) {
      setState(() {
        _profilePhotoPath = pickedFile.path;
      });
    }
  }

  Future<void> _takePhoto() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 85,
    );

    if (pickedFile != null) {
      setState(() {
        _profilePhotoPath = pickedFile.path;
      });
    }
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickImage();
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take Photo'),
              onTap: () {
                Navigator.pop(context);
                _takePhoto();
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _savePatient() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      String? photoUrl = widget.existingPatient?.profilePhoto;

      // Upload new photo if selected
      if (_profilePhotoPath != null && !_profilePhotoPath!.startsWith('http')) {
        // Upload to Firebase Storage
        final storageService = StorageService();
        photoUrl = await storageService.uploadProfilePhoto(
          userId: widget.userId,
          patientId: widget.existingPatient?.patientId ?? 'temp',
          filePath: _profilePhotoPath!,
        );
      }

      final patient = PatientModel(
        patientId: widget.existingPatient?.patientId ?? '',
        userId: widget.userId,
        name: _nameController.text.trim(),
        phone: _phoneController.text.trim(),
        age: int.parse(_ageController.text),
        gender: _selectedGender,
        profilePhoto: photoUrl,
        medicalHistory: MedicalHistory(
          conditions: _conditions,
          medications: _medications,
        ),
        allergies: _allergies,
        smokingStatus: _smokingStatus,
        notes: _notesController.text.trim(),
        createdAt: widget.existingPatient?.createdAt ?? DateTime.now(),
        updatedAt: DateTime.now(),
      );

      final notifier = ref.read(patientsProvider(widget.userId).notifier);

      if (_isEditing) {
        await notifier.updatePatient(patient);
      } else {
        await notifier.createPatient(patient);
      }

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_isEditing
                ? 'Patient updated successfully'
                : 'Patient added successfully'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error saving patient: $e'),
          backgroundColor: AppColors.error,
        ),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? AppStrings.editPatient : AppStrings.addPatient),
        actions: [
          TextButton.icon(
            onPressed: _isLoading ? null : _savePatient,
            icon: _isLoading
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.check),
            label: Text(_isEditing ? AppStrings.update : AppStrings.save),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(AppSizes.paddingM),
          children: [
            // Profile Photo
            Center(
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundImage: _profilePhotoPath != null
                        ? _profilePhotoPath!.startsWith('http')
                            ? NetworkImage(_profilePhotoPath!) as ImageProvider
                            : FileImage(File(_profilePhotoPath!))
                        : null,
                    backgroundColor: AppColors.primaryLight.withOpacity(0.3),
                    child: _profilePhotoPath == null
                        ? const Icon(
                            Icons.person,
                            size: 50,
                            color: AppColors.primary,
                          )
                        : null,
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: InkWell(
                      onTap: _showImageSourceDialog,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: const BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.camera_alt,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: AppSizes.spacingL),

            // Basic Information Section
            _buildSectionHeader('Basic Information'),

            const SizedBox(height: AppSizes.spacingM),

            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Patient Name *',
                prefixIcon: Icon(Icons.person_outline),
              ),
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Please enter patient name';
                }
                return null;
              },
              textCapitalization: TextCapitalization.words,
            ),

            const SizedBox(height: AppSizes.spacingM),

            TextFormField(
              controller: _phoneController,
              decoration: const InputDecoration(
                labelText: 'Phone Number *',
                prefixIcon: Icon(Icons.phone_outlined),
              ),
              keyboardType: TextInputType.phone,
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Please enter phone number';
                }
                return null;
              },
            ),

            const SizedBox(height: AppSizes.spacingM),

            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _ageController,
                    decoration: const InputDecoration(
                      labelText: 'Age *',
                      prefixIcon: Icon(Icons.cake_outlined),
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Required';
                      }
                      if (int.tryParse(value) == null) {
                        return 'Invalid age';
                      }
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: AppSizes.spacingM),
                Expanded(
                  child: DropdownButtonFormField<Gender>(
                    value: _selectedGender,
                    decoration: const InputDecoration(
                      labelText: 'Gender',
                      prefixIcon: Icon(Icons.wc),
                    ),
                    items: const [
                      DropdownMenuItem(value: Gender.male, child: Text('Male')),
                      DropdownMenuItem(value: Gender.female, child: Text('Female')),
                      DropdownMenuItem(value: Gender.other, child: Text('Other')),
                    ],
                    onChanged: (value) {
                      setState(() => _selectedGender = value!);
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: AppSizes.spacingL),

            // Medical History Section
            _buildSectionHeader('Medical History'),

            const SizedBox(height: AppSizes.spacingM),

            // Allergies
            _buildChipsInput(
              label: 'Allergies',
              controller: _allergyController,
              items: _allergies,
              onAdd: () {
                if (_allergyController.text.isNotEmpty) {
                  setState(() {
                    _allergies.add(_allergyController.text.trim());
                    _allergyController.clear();
                  });
                }
              },
              onRemove: (item) {
                setState(() => _allergies.remove(item));
              },
            ),

            const SizedBox(height: AppSizes.spacingM),

            // Medical Conditions
            _buildChipsInput(
              label: 'Medical Conditions',
              controller: _conditionController,
              items: _conditions,
              onAdd: () {
                if (_conditionController.text.isNotEmpty) {
                  setState(() {
                    _conditions.add(_conditionController.text.trim());
                    _conditionController.clear();
                  });
                }
              },
              onRemove: (item) {
                setState(() => _conditions.remove(item));
              },
            ),

            const SizedBox(height: AppSizes.spacingM),

            // Current Medications
            _buildChipsInput(
              label: 'Current Medications',
              controller: _medicationController,
              items: _medications,
              onAdd: () {
                if (_medicationController.text.isNotEmpty) {
                  setState(() {
                    _medications.add(_medicationController.text.trim());
                    _medicationController.clear();
                  });
                }
              },
              onRemove: (item) {
                setState(() => _medications.remove(item));
              },
            ),

            const SizedBox(height: AppSizes.spacingM),

            // Smoking Status
            DropdownButtonFormField<SmokingStatus>(
              value: _smokingStatus,
              decoration: const InputDecoration(
                labelText: 'Smoking Status',
                prefixIcon: Icon(Icons.smoking_rooms),
              ),
              items: const [
                DropdownMenuItem(value: SmokingStatus.never, child: Text('Never')),
                DropdownMenuItem(value: SmokingStatus.former, child: Text('Former Smoker')),
                DropdownMenuItem(value: SmokingStatus.current, child: Text('Current Smoker')),
                DropdownMenuItem(value: SmokingStatus.unknown, child: Text('Unknown')),
              ],
              onChanged: (value) {
                setState(() => _smokingStatus = value!);
              },
            ),

            const SizedBox(height: AppSizes.spacingL),

            // Notes Section
            _buildSectionHeader('Additional Notes'),

            const SizedBox(height: AppSizes.spacingM),

            TextFormField(
              controller: _notesController,
              decoration: const InputDecoration(
                labelText: 'Notes',
                prefixIcon: Icon(Icons.notes_outlined),
                alignLabelWithHint: true,
              ),
              maxLines: 4,
              textCapitalization: TextCapitalization.sentences,
            ),

            const SizedBox(height: AppSizes.spacingXXL),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: AppColors.primary,
          ),
    );
  }

  Widget _buildChipsInput({
    required String label,
    required TextEditingController controller,
    required List<String> items,
    required VoidCallback onAdd,
    required void Function(String) onRemove,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: AppColors.textSecondary,
              ),
        ),
        const SizedBox(height: AppSizes.spacingS),
        if (items.isNotEmpty)
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: items.map((item) {
              return Chip(
                label: Text(item),
                onDeleted: () => onRemove(item),
                backgroundColor: AppColors.primaryLight.withOpacity(0.2),
                deleteIconColor: AppColors.primary,
              );
            }).toList(),
          ),
        const SizedBox(height: AppSizes.spacingS),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: controller,
                decoration: InputDecoration(
                  hintText: 'Add $label',
                  border: const OutlineInputBorder(),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: AppSizes.paddingM,
                    vertical: AppSizes.paddingS,
                  ),
                ),
                onSubmitted: (_) => onAdd(),
              ),
            ),
            const SizedBox(width: AppSizes.spacingS),
            IconButton(
              onPressed: onAdd,
              icon: const Icon(Icons.add_circle),
              color: AppColors.primary,
            ),
          ],
        ),
      ],
    );
  }
}
