import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as path;
import 'package:flutter/foundation.dart';

import '../../../auth/data/auth_service.dart';
import '../../../patients/data/models/patient_model.dart';
import '../../../treatments/data/models/treatment_model.dart';
import '../../../../core/constants/app_constants.dart';

/// Google Drive Backup Service
class DriveBackupService {
  final GoogleSignIn _googleSignIn;
  final Ref _ref;

  DriveBackupService({
    required GoogleSignIn googleSignIn,
    required Ref ref,
  })  : _googleSignIn = googleSignIn,
        _ref = ref;

  /// Get Google Drive API client
  Future<drive.DriveApi?> _getDriveApi() async {
    try {
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null;

      final headers = await googleUser.authHeaders;
      final client = _GoogleAuthClient(headers);

      return drive.DriveApi(client);
    } catch (e) {
      debugPrint('Error getting Drive API: $e');
      return null;
    }
  }

  /// Create main folder in Google Drive
  Future<String?> createMainFolder() async {
    final driveApi = await _getDriveApi();
    if (driveApi == null) return null;

    try {
      // Check if folder already exists
      final existingFolder = await _findFolder(driveApi, AppConstants.driveFolderName);
      if (existingFolder != null) {
        return existingFolder.id;
      }

      // Create new folder
      final folder = drive.File()
        ..name = AppConstants.driveFolderName
        ..mimeType = 'application/vnd.google-apps.folder';

      final createdFolder = await driveApi.files.create(folder);
      return createdFolder.id;
    } catch (e) {
      debugPrint('Error creating main folder: $e');
      return null;
    }
  }

  /// Find folder by name
  Future<drive.File?> _findFolder(drive.DriveApi driveApi, String name,
      {String? parentId}) async {
    try {
      String query = "mimeType='application/vnd.google-apps.folder' and name='$name' and trashed=false";
      if (parentId != null) {
        query += " and '$parentId' in parents";
      }

      final result = await driveApi.files.list(
        q: query,
        spaces: 'drive',
        fields: 'files(id, name)',
      );

      return result.files?.isNotEmpty == true ? result.files!.first : null;
    } catch (e) {
      debugPrint('Error finding folder: $e');
      return null;
    }
  }

  /// Create patient folder
  Future<String?> createPatientFolder(String patientName, String mainFolderId) async {
    final driveApi = await _getDriveApi();
    if (driveApi == null) return null;

    try {
      // Check if patient folder exists
      final existingFolder = await _findFolder(
        driveApi,
        patientName,
        parentId: mainFolderId,
      );
      if (existingFolder != null) {
        return existingFolder.id;
      }

      // Create patient folder
      final folder = drive.File()
        ..name = patientName
        ..mimeType = 'application/vnd.google-apps.folder'
        ..parents = [mainFolderId];

      final createdFolder = await driveApi.files.create(folder);
      return createdFolder.id;
    } catch (e) {
      debugPrint('Error creating patient folder: $e');
      return null;
    }
  }

  /// Create treatment category folder
  Future<String?> createTreatmentFolder(
    String categoryName,
    String patientFolderId,
  ) async {
    final driveApi = await _getDriveApi();
    if (driveApi == null) return null;

    try {
      // Map category to folder name
      String folderName;
      switch (categoryName) {
        case 'orthodontics':
          folderName = AppConstants.orthodonticsFolderName;
          break;
        case 'fillings':
          folderName = AppConstants.fillingsFolderName;
          break;
        case 'scaling_polishing':
          folderName = AppConstants.scalingFolderName;
          break;
        default:
          folderName = categoryName;
      }

      // Check if folder exists
      final existingFolder = await _findFolder(
        driveApi,
        folderName,
        parentId: patientFolderId,
      );
      if (existingFolder != null) {
        return existingFolder.id;
      }

      // Create folder
      final folder = drive.File()
        ..name = folderName
        ..mimeType = 'application/vnd.google-apps.folder'
        ..parents = [patientFolderId];

      final createdFolder = await driveApi.files.create(folder);
      return createdFolder.id;
    } catch (e) {
      debugPrint('Error creating treatment folder: $e');
      return null;
    }
  }

  /// Upload file to Google Drive
  Future<String?> uploadFile({
    required File file,
    required String fileName,
    required String folderId,
  }) async {
    final driveApi = await _getDriveApi();
    if (driveApi == null) return null;

    try {
      final driveFile = drive.File()
        ..name = fileName
        ..parents = [folderId];

      final stream = http.ByteStream(file.openRead());
      final length = await file.length();

      final uploadedFile = await driveApi.files.create(
        driveFile,
        uploadMedia: drive.UploadMedia(
          stream,
          'image/jpeg',
          length,
        ),
      );

      return uploadedFile.id;
    } catch (e) {
      debugPrint('Error uploading file: $e');
      return null;
    }
  }

  /// Upload bytes to Google Drive
  Future<String?> uploadBytes({
    required Uint8List bytes,
    required String fileName,
    required String folderId,
    String mimeType = 'image/jpeg',
  }) async {
    final driveApi = await _getDriveApi();
    if (driveApi == null) return null;

    try {
      final driveFile = drive.File()
        ..name = fileName
        ..parents = [folderId];

      final stream = http.ByteStream.fromBytes(bytes);

      final uploadedFile = await driveApi.files.create(
        driveFile,
        uploadMedia: drive.UploadMedia(
          stream,
          mimeType,
          bytes.length,
        ),
      );

      return uploadedFile.id;
    } catch (e) {
      debugPrint('Error uploading bytes: $e');
      return null;
    }
  }

  /// Backup patient profile photo
  Future<String?> backupPatientPhoto({
    required PatientModel patient,
    required File photoFile,
  }) async {
    try {
      // Create main folder if needed
      final mainFolderId = await createMainFolder();
      if (mainFolderId == null) return null;

      // Create patient folder
      final patientFolderId = await createPatientFolder(
        patient.name,
        mainFolderId,
      );
      if (patientFolderId == null) return null;

      // Create profile folder
      final profileFolderId = await _createSubFolder(
        patientFolderId,
        AppConstants.profileFolderName,
      );
      if (profileFolderId == null) return null;

      // Upload photo
      final fileName = 'profile_${DateTime.now().millisecondsSinceEpoch}.jpg';
      return await uploadFile(
        file: photoFile,
        fileName: fileName,
        folderId: profileFolderId,
      );
    } catch (e) {
      debugPrint('Error backing up patient photo: $e');
      return null;
    }
  }

  /// Backup treatment images
  Future<List<String>> backupTreatmentImages({
    required PatientModel patient,
    required TreatmentModel treatment,
    required List<File> imageFiles,
    required List<String> labels,
  }) async {
    final uploadedIds = <String>[];

    try {
      // Create folder structure
      final mainFolderId = await createMainFolder();
      if (mainFolderId == null) return uploadedIds;

      final patientFolderId = await createPatientFolder(
        patient.name,
        mainFolderId,
      );
      if (patientFolderId == null) return uploadedIds;

      final treatmentFolderId = await createTreatmentFolder(
        treatment.category,
        patientFolderId,
      );
      if (treatmentFolderId == null) return uploadedIds;

      // Create date folder
      final dateFolderName = AppHelpers.formatDateForFolder(treatment.date);
      final dateFolderId = await _createSubFolder(
        treatmentFolderId,
        dateFolderName,
      );
      if (dateFolderId == null) return uploadedIds;

      // Upload images
      for (var i = 0; i < imageFiles.length; i++) {
        final file = imageFiles[i];
        final label = i < labels.length ? labels[i] : 'photo';
        final fileName = '${label}_${i + 1}_${DateTime.now().millisecondsSinceEpoch}.jpg';

        final fileId = await uploadFile(
          file: file,
          fileName: fileName,
          folderId: dateFolderId,
        );

        if (fileId != null) {
          uploadedIds.add(fileId);
        }
      }
    } catch (e) {
      debugPrint('Error backing up treatment images: $e');
    }

    return uploadedIds;
  }

  /// Create subfolder
  Future<String?> _createSubFolder(String parentId, String name) async {
    final driveApi = await _getDriveApi();
    if (driveApi == null) return null;

    try {
      // Check if exists
      final existingFolder = await _findFolder(
        driveApi,
        name,
        parentId: parentId,
      );
      if (existingFolder != null) {
        return existingFolder.id;
      }

      // Create folder
      final folder = drive.File()
        ..name = name
        ..mimeType = 'application/vnd.google-apps.folder'
        ..parents = [parentId];

      final createdFolder = await driveApi.files.create(folder);
      return createdFolder.id;
    } catch (e) {
      debugPrint('Error creating subfolder: $e');
      return null;
    }
  }

  /// Get backup status
  Future<BackupStatus> getBackupStatus(String userId) async {
    try {
      final driveApi = await _getDriveApi();
      if (driveApi == null) {
        return BackupStatus.notConnected;
      }

      final mainFolder = await _findFolder(driveApi, AppConstants.driveFolderName);
      if (mainFolder == null) {
        return BackupStatus.noBackup;
      }

      return BackupStatus.connected;
    } catch (e) {
      return BackupStatus.error;
    }
  }

  /// Delete file from Google Drive
  Future<bool> deleteFile(String fileId) async {
    final driveApi = await _getDriveApi();
    if (driveApi == null) return false;

    try {
      await driveApi.files.delete(fileId);
      return true;
    } catch (e) {
      debugPrint('Error deleting file: $e');
      return false;
    }
  }

  /// List files in folder
  Future<List<drive.File>> listFiles(String folderId) async {
    final driveApi = await _getDriveApi();
    if (driveApi == null) return [];

    try {
      final result = await driveApi.files.list(
        q: "'$folderId' in parents and trashed=false",
        spaces: 'drive',
        fields: 'files(id, name, createdTime, mimeType)',
        orderBy: 'createdTime desc',
      );

      return result.files ?? [];
    } catch (e) {
      debugPrint('Error listing files: $e');
      return [];
    }
  }
}

enum BackupStatus {
  notConnected,
  noBackup,
  connected,
  error,
}

/// Google Auth Client for API calls
class _GoogleAuthClient extends http.BaseClient {
  final Map<String, String> headers;
  final http.Client _client = http.Client();

  _GoogleAuthClient(this.headers);

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    request.headers.addAll(headers);
    return _client.send(request);
  }
}

// Provider
final driveBackupServiceProvider = Provider<DriveBackupService>((ref) {
  return DriveBackupService(
    googleSignIn: ref.watch(googleSignInProvider),
    ref: ref,
  );
});

// Backup status provider
final backupStatusProvider = FutureProvider.family<BackupStatus, String>((ref, userId) {
  final service = ref.watch(driveBackupServiceProvider);
  return service.getBackupStatus(userId);
});
