import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../../models/treatment_model.dart';
import '../../../treatments/data/treatments_provider.dart';
import '../../../services/storage_service.dart';

class AddTreatmentScreen extends ConsumerStatefulWidget {
  final String patientId;
  final String userId;
  final TreatmentModel? existingTreatment;

  const AddTreatmentScreen({
    super.key,
    required this.patientId,
    required this.userId,
    this.existingTreatment,
  });

  @override
  ConsumerState<AddTreatmentScreen> createState() => _AddTreatmentScreenState();
}

class _AddTreatmentScreenState extends ConsumerState<AddTreatmentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _diagnosisController = TextEditingController();
  final _notesController = TextEditingController();
  final _toothNumberController = TextEditingController();
  final _materialController = TextEditingController();

  TreatmentCategory _selectedCategory = TreatmentCategory.fillings;
  TreatmentStatus _status = TreatmentStatus.planned;
  DateTime _selectedDate = DateTime.now();
  List<String> _materials = [];
  List<String> _beforeImages = [];
  List<String> _duringImages = [];
  List<String> _afterImages = [];
  bool _isLoading = false;
  bool get _isEditing => widget.existingTreatment != null;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      _loadExistingData();
    }
  }

  void _loadExistingData() {
    final treatment = widget.existingTreatment!;
    _diagnosisController.text = treatment.diagnosis;
    _notesController.text = treatment.treatmentNotes;
    _toothNumberController.text = treatment.toothNumber ?? '';
    _selectedCategory = treatment.category;
    _status = treatment.status;
    _selectedDate = treatment.date;
    _materials = List.from(treatment.materials);
    _beforeImages = List.from(treatment.images.before);
    _duringImages = List.from(treatment.images.during);
    _afterImages = List.from(treatment.images.after);
  }

  @override
  void dispose() {
    _diagnosisController.dispose();
    _notesController.dispose();
    _toothNumberController.dispose();
    _materialController.dispose();
    super.dispose();
  }

  Future<void> _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _pickImages(String label) async {
    final picker = ImagePicker();
    final pickedFiles = await picker.pickMultiImage(
      maxWidth: 1920,
      maxHeight: 1920,
      imageQuality: 85,
    );

    if (pickedFiles.isNotEmpty) {
      setState(() {
        final paths = pickedFiles.map((f) => f.path).toList();
        switch (label) {
          case 'before':
            _beforeImages.addAll(paths);
            break;
          case 'during':
            _duringImages.addAll(paths);
            break;
          case 'after':
            _afterImages.addAll(paths);
            break;
        }
      });
    }
  }

  Future<void> _takePhoto(String label) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 1920,
      maxHeight: 1920,
      imageQuality: 85,
    );

    if (pickedFile != null) {
      setState(() {
        switch (label) {
          case 'before':
            _beforeImages.add(pickedFile.path);
            break;
          case 'during':
            _duringImages.add(pickedFile.path);
            break;
          case 'after':
            _afterImages.add(pickedFile.path);
            break;
        }
      });
    }
  }

  void _showImageSourceDialog(String label) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickImages(label);
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take Photo'),
              onTap: () {
                Navigator.pop(context);
                _takePhoto(label);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<List<String>> _uploadImages(
    List<String> localPaths,
    String label,
    String treatmentId,
  ) async {
    final uploadedUrls = <String>[];
    final storageService = StorageService();

    for (final path in localPaths) {
      if (!path.startsWith('http')) {
        final url = await storageService.uploadTreatmentImage(
          userId: widget.userId,
          patientId: widget.patientId,
          treatmentId: treatmentId,
          label: label,
          filePath: path,
        );
        uploadedUrls.add(url);
      } else {
        uploadedUrls.add(path);
      }
    }

    return uploadedUrls;
  }

  Future<void> _saveTreatment() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final treatmentId =
          widget.existingTreatment?.treatmentId ?? DateTime.now().millisecondsSinceEpoch.toString();

      // Upload images
      final beforeUrls = await _uploadImages(_beforeImages, 'before', treatmentId);
      final duringUrls = await _uploadImages(_duringImages, 'during', treatmentId);
      final afterUrls = await _uploadImages(_afterImages, 'after', treatmentId);

      final treatment = TreatmentModel(
        treatmentId: treatmentId,
        patientId: widget.patientId,
        userId: widget.userId,
        category: _selectedCategory,
        toothNumber: _toothNumberController.text.trim().isNotEmpty
            ? _toothNumberController.text.trim()
            : null,
        date: _selectedDate,
        diagnosis: _diagnosisController.text.trim(),
        treatmentNotes: _notesController.text.trim(),
        materials: _materials,
        status: _status,
        images: TreatmentImages(
          before: beforeUrls,
          during: duringUrls,
          after: afterUrls,
        ),
        createdAt: widget.existingTreatment?.createdAt ?? DateTime.now(),
        updatedAt: DateTime.now(),
      );

      final notifier = ref.read(treatmentsProvider(widget.userId).notifier);

      if (_isEditing) {
        await notifier.updateTreatment(treatment);
      } else {
        await notifier.createTreatment(treatment);
      }

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_isEditing
                ? 'Treatment updated successfully'
                : 'Treatment added successfully'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error saving treatment: $e'),
          backgroundColor: AppColors.error,
        ),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Treatment' : 'Add Treatment'),
        actions: [
          TextButton.icon(
            onPressed: _isLoading ? null : _saveTreatment,
            icon: _isLoading
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.check),
            label: Text(_isEditing ? AppStrings.update : AppStrings.save),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(AppSizes.paddingM),
          children: [
            // Category Selection
            _buildCategorySelector(),

            const SizedBox(height: AppSizes.spacingL),

            // Treatment Details
            _buildSectionHeader('Treatment Details'),

            const SizedBox(height: AppSizes.spacingM),

            // Date Picker
            InkWell(
              onTap: _selectDate,
              child: InputDecorator(
                decoration: const InputDecoration(
                  labelText: 'Date',
                  prefixIcon: Icon(Icons.calendar_today),
                ),
                child: Text(
                  DateFormat('MMMM d, y').format(_selectedDate),
                ),
              ),
            ),

            const SizedBox(height: AppSizes.spacingM),

            // Tooth Number
            TextFormField(
              controller: _toothNumberController,
              decoration: const InputDecoration(
                labelText: 'Tooth Number (optional)',
                prefixIcon: Icon(Icons.looks_one),
                hintText: 'e.g., 18, 24',
              ),
              keyboardType: TextInputType.number,
            ),

            const SizedBox(height: AppSizes.spacingM),

            // Diagnosis
            TextFormField(
              controller: _diagnosisController,
              decoration: const InputDecoration(
                labelText: 'Diagnosis *',
                prefixIcon: Icon(Icons.medical_information),
              ),
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Please enter diagnosis';
                }
                return null;
              },
              textCapitalization: TextCapitalization.sentences,
            ),

            const SizedBox(height: AppSizes.spacingM),

            // Treatment Notes
            TextFormField(
              controller: _notesController,
              decoration: const InputDecoration(
                labelText: 'Treatment Notes',
                prefixIcon: Icon(Icons.notes),
                alignLabelWithHint: true,
              ),
              maxLines: 4,
              textCapitalization: TextCapitalization.sentences,
            ),

            const SizedBox(height: AppSizes.spacingM),

            // Status
            DropdownButtonFormField<TreatmentStatus>(
              value: _status,
              decoration: const InputDecoration(
                labelText: 'Status',
                prefixIcon: Icon(Icons.pending_actions),
              ),
              items: const [
                DropdownMenuItem(
                  value: TreatmentStatus.planned,
                  child: Text('Planned'),
                ),
                DropdownMenuItem(
                  value: TreatmentStatus.inProgress,
                  child: Text('In Progress'),
                ),
                DropdownMenuItem(
                  value: TreatmentStatus.completed,
                  child: Text('Completed'),
                ),
                DropdownMenuItem(
                  value: TreatmentStatus.cancelled,
                  child: Text('Cancelled'),
                ),
              ],
              onChanged: (value) {
                setState(() => _status = value!);
              },
            ),

            const SizedBox(height: AppSizes.spacingL),

            // Materials Used
            _buildSectionHeader('Materials Used'),

            const SizedBox(height: AppSizes.spacingM),

            _buildChipsInput(
              controller: _materialController,
              items: _materials,
              onAdd: () {
                if (_materialController.text.isNotEmpty) {
                  setState(() {
                    _materials.add(_materialController.text.trim());
                    _materialController.clear();
                  });
                }
              },
              onRemove: (item) {
                setState(() => _materials.remove(item));
              },
            ),

            const SizedBox(height: AppSizes.spacingL),

            // Photos Section
            _buildSectionHeader('Clinical Photos'),

            const SizedBox(height: AppSizes.spacingM),

            // Before Photos
            _buildPhotoSection(
              'Before Treatment',
              _beforeImages,
              'before',
              AppColors.error,
            ),

            const SizedBox(height: AppSizes.spacingM),

            // During Photos
            _buildPhotoSection(
              'During Treatment',
              _duringImages,
              'during',
              AppColors.warning,
            ),

            const SizedBox(height: AppSizes.spacingM),

            // After Photos
            _buildPhotoSection(
              'After Treatment',
              _afterImages,
              'after',
              AppColors.success,
            ),

            const SizedBox(height: AppSizes.spacingXXL),
          ],
        ),
      ),
    );
  }

  Widget _buildCategorySelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Treatment Category',
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: AppSizes.spacingM),
        Row(
          children: [
            _buildCategoryCard(
              'Orthodontics',
              TreatmentCategory.orthodontics,
              AppColors.orthodontics,
              Icons.straighten,
            ),
            const SizedBox(width: AppSizes.spacingS),
            _buildCategoryCard(
              'Fillings',
              TreatmentCategory.fillings,
              AppColors.fillings,
              Icons.build_circle,
            ),
            const SizedBox(width: AppSizes.spacingS),
            _buildCategoryCard(
              'Scale & Polish',
              TreatmentCategory.scalingPolishing,
              AppColors.scalingPolishing,
              Icons.cleaning_services,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCategoryCard(
    String title,
    TreatmentCategory category,
    Color color,
    IconData icon,
  ) {
    final isSelected = _selectedCategory == category;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _selectedCategory = category),
        borderRadius: BorderRadius.circular(AppSizes.radiusM),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: AppSizes.paddingM),
          decoration: BoxDecoration(
            color: isSelected ? color : color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(AppSizes.radiusM),
            border: Border.all(
              color: isSelected ? color : color.withOpacity(0.3),
            ),
          ),
          child: Column(
            children: [
              Icon(
                icon,
                color: isSelected ? Colors.white : color,
                size: 24,
              ),
              const SizedBox(height: 4),
              Text(
                title,
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: isSelected ? Colors.white : color,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: AppColors.primary,
          ),
    );
  }

  Widget _buildChipsInput({
    required TextEditingController controller,
    required List<String> items,
    required VoidCallback onAdd,
    required void Function(String) onRemove,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (items.isNotEmpty)
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: items.map((item) {
              return Chip(
                label: Text(item),
                onDeleted: () => onRemove(item),
                backgroundColor: AppColors.primaryLight.withOpacity(0.2),
              );
            }).toList(),
          ),
        const SizedBox(height: AppSizes.spacingS),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: controller,
                decoration: InputDecoration(
                  hintText: 'Add material',
                  border: const OutlineInputBorder(),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: AppSizes.paddingM,
                    vertical: AppSizes.paddingS,
                  ),
                ),
                onSubmitted: (_) => onAdd(),
              ),
            ),
            const SizedBox(width: AppSizes.spacingS),
            IconButton(
              onPressed: onAdd,
              icon: const Icon(Icons.add_circle),
              color: AppColors.primary,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildPhotoSection(
    String title,
    List<String> images,
    String label,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(AppSizes.paddingM),
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: color,
                    ),
              ),
              IconButton(
                onPressed: () => _showImageSourceDialog(label),
                icon: Icon(Icons.add_a_photo, color: color),
                tooltip: 'Add Photo',
              ),
            ],
          ),
          if (images.isNotEmpty) ...[
            const SizedBox(height: AppSizes.spacingS),
            SizedBox(
              height: 80,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: images.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(right: AppSizes.spacingS),
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: images[index].startsWith('http')
                              ? Image.network(
                                  images[index],
                                  width: 80,
                                  height: 80,
                                  fit: BoxFit.cover,
                                )
                              : Image.file(
                                  File(images[index]),
                                  width: 80,
                                  height: 80,
                                  fit: BoxFit.cover,
                                ),
                        ),
                        Positioned(
                          top: 4,
                          right: 4,
                          child: InkWell(
                            onTap: () {
                              setState(() => images.removeAt(index));
                            },
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: const BoxDecoration(
                                color: AppColors.error,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.close,
                                size: 12,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ] else
            Padding(
              padding: const EdgeInsets.symmetric(vertical: AppSizes.paddingM),
              child: Center(
                child: Text(
                  'No photos added',
                  style: TextStyle(color: AppColors.textHint),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
