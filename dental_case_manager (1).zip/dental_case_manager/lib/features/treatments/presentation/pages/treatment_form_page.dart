import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:uuid/uuid.dart';
import 'dart:io';

import '../../data/models/treatment_model.dart';
import '../../data/repositories/treatment_repository.dart';
import '../../../patients/data/repositories/patient_repository.dart';
import '../../../auth/data/auth_service.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/animated_widgets.dart';
import '../../../../core/utils/helpers.dart';
import '../../../../core/constants/app_constants.dart';

class TreatmentFormPage extends ConsumerStatefulWidget {
  final String patientId;
  final String? treatmentId;

  const TreatmentFormPage({
    super.key,
    required this.patientId,
    this.treatmentId,
  });

  @override
  ConsumerState<TreatmentFormPage> createState() => _TreatmentFormPageState();
}

class _TreatmentFormPageState extends ConsumerState<TreatmentFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _diagnosisController = TextEditingController();
  final _notesController = TextEditingController();
  final _materialsController = TextEditingController();
  final _progressController = TextEditingController();
  final _costController = TextEditingController();

  String _category = 'fillings';
  String _status = 'planned';
  DateTime _selectedDate = DateTime.now();
  String? _selectedTooth;
  List<String> _selectedTeeth = [];
  List<_LocalImage> _images = [];
  bool _isLoading = false;
  bool _isEditing = false;
  TreatmentModel? _existingTreatment;
  final Uuid _uuid = const Uuid();

  @override
  void initState() {
    super.initState();
    _isEditing = widget.treatmentId != null;
    if (_isEditing) {
      _loadTreatment();
    }
  }

  Future<void> _loadTreatment() async {
    final treatment = await ref
        .read(treatmentRepositoryProvider)
        .getTreatment(widget.treatmentId!);

    if (treatment != null && mounted) {
      setState(() {
        _existingTreatment = treatment;
        _category = treatment.category;
        _status = treatment.status;
        _selectedDate = treatment.date;
        _selectedTooth = treatment.toothNumber;
        _selectedTeeth = treatment.toothNumbers ?? [];
        _diagnosisController.text = treatment.diagnosis;
        _notesController.text = treatment.treatmentNotes;
        _materialsController.text = treatment.materials.join(', ');
        _progressController.text = treatment.progressNotes;
        _costController.text = treatment.cost?.toString() ?? '';
        _images = treatment.images
            .map((img) => _LocalImage(
                  imageId: img.imageId,
                  label: img.label,
                  isExisting: true,
                  url: img.url,
                ))
            .toList();
      });
    }
  }

  @override
  void dispose() {
    _diagnosisController.dispose();
    _notesController.dispose();
    _materialsController.dispose();
    _progressController.dispose();
    _costController.dispose();
    super.dispose();
  }

  Future<void> _pickImages(String label) async {
    final picker = ImagePicker();
    final pickedFiles = await picker.pickMultiImage(
      maxWidth: 1920,
      maxHeight: 1920,
      imageQuality: 85,
    );

    if (pickedFiles.isNotEmpty) {
      setState(() {
        for (final file in pickedFiles) {
          _images.add(_LocalImage(
            imageId: _uuid.v4(),
            label: label,
            file: File(file.path),
            isExisting: false,
          ));
        }
      });
    }
  }

  Future<void> _takePhoto(String label) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 1920,
      maxHeight: 1920,
      imageQuality: 85,
    );

    if (pickedFile != null) {
      setState(() {
        _images.add(_LocalImage(
          imageId: _uuid.v4(),
          label: label,
          file: File(pickedFile.path),
          isExisting: false,
        ));
      });
    }
  }

  Future<void> _selectDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (date != null) {
      setState(() => _selectedDate = date);
    }
  }

  Future<void> _saveTreatment() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final user = ref.read(authStateProvider).value;
      if (user == null) return;

      final repository = ref.read(treatmentRepositoryProvider);

      // Parse materials
      final materials = _materialsController.text
          .split(',')
          .map((m) => m.trim())
          .where((m) => m.isNotEmpty)
          .toList();

      // Upload images and get URLs
      final treatmentImages = await _uploadImages();

      if (_isEditing && _existingTreatment != null) {
        await repository.updateTreatment(_existingTreatment!.copyWith(
          category: _category,
          toothNumber: _selectedTooth,
          toothNumbers: _selectedTeeth.isNotEmpty ? _selectedTeeth : null,
          date: _selectedDate,
          diagnosis: _diagnosisController.text.trim(),
          treatmentNotes: _notesController.text.trim(),
          materials: materials,
          progressNotes: _progressController.text.trim(),
          status: _status,
          cost: _costController.text.isNotEmpty
              ? double.parse(_costController.text)
              : null,
          images: treatmentImages,
        ));
      } else {
        await repository.createTreatment(
          patientId: widget.patientId,
          userId: user.uid,
          category: _category,
          toothNumber: _selectedTooth,
          toothNumbers: _selectedTeeth.isNotEmpty ? _selectedTeeth : null,
          date: _selectedDate,
          diagnosis: _diagnosisController.text.trim(),
          treatmentNotes: _notesController.text.trim(),
          materials: materials,
          progressNotes: _progressController.text.trim(),
          status: _status,
          cost: _costController.text.isNotEmpty
              ? double.parse(_costController.text)
              : null,
          images: treatmentImages,
        );
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_isEditing
                ? 'Treatment updated successfully'
                : 'Treatment created successfully'),
            backgroundColor: AppTheme.successColor,
            behavior: SnackBarBehavior.floating,
          ),
        );
        context.pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: AppTheme.errorColor,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<List<TreatmentImage>> _uploadImages() async {
    // In a real app, you would upload to Firebase Storage here
    // For now, we'll return the existing images
    final images = <TreatmentImage>[];

    for (final localImage in _images) {
      if (localImage.isExisting && localImage.url != null) {
        images.add(TreatmentImage(
          imageId: localImage.imageId,
          url: localImage.url!,
          label: localImage.label,
          uploadedAt: DateTime.now(),
        ));
      } else if (localImage.file != null) {
        // Upload to Firebase Storage
        // final url = await uploadImage(localImage.file!);
        // For demo, use a placeholder
        images.add(TreatmentImage(
          imageId: localImage.imageId,
          url: 'https://placeholder.com/image.jpg',
          localPath: localImage.file!.path,
          label: localImage.label,
          uploadedAt: DateTime.now(),
        ));
      }
    }

    return images;
  }

  @override
  Widget build(BuildContext context) {
    final patientAsync = ref.watch(patientProvider(widget.patientId));
    final categoryColor = AppHelpers.getTreatmentColor(_category);

    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Treatment' : 'New Treatment'),
        actions: [
          TextButton(
            onPressed: _isLoading ? null : _saveTreatment,
            child: const Text('Save'),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Patient Info Card
              patientAsync.when(
                data: (patient) {
                  if (patient == null) return const SizedBox.shrink();
                  return Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: AppTheme.primaryColor,
                          child: Text(
                            AppHelpers.getInitials(patient.name),
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                patient.name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text(
                                'Patient ID: ${patient.patientId.substring(0, 8)}',
                                style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ).animate().fadeIn();
                },
                loading: () => const SizedBox.shrink(),
                error: (_, __) => const SizedBox.shrink(),
              ),

              const SizedBox(height: 24),

              // Treatment Category
              _buildSectionTitle('Treatment Category'),
              const SizedBox(height: 12),

              Row(
                children: [
                  _buildCategoryChip(
                    'Orthodontics',
                    'orthodontics',
                    AppTheme.orthodonticsColor,
                    Icons.straighten,
                  ),
                  const SizedBox(width: 8),
                  _buildCategoryChip(
                    'Fillings',
                    'fillings',
                    AppTheme.fillingsColor,
                    Icons.healing,
                  ),
                  const SizedBox(width: 8),
                  _buildCategoryChip(
                    'Scaling',
                    'scaling_polishing',
                    AppTheme.scalingColor,
                    Icons.cleaning_services,
                  ),
                ],
              ).animate().fadeIn(delay: 100.ms),

              const SizedBox(height: 24),

              // Date and Status
              Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: _selectDate,
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: 'Date',
                          prefixIcon: Icon(Icons.calendar_today_outlined),
                        ),
                        child: Text(
                          AppHelpers.formatDate(_selectedDate),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _status,
                      decoration: const InputDecoration(
                        labelText: 'Status',
                        prefixIcon: Icon(Icons.flag_outlined),
                      ),
                      items: const [
                        DropdownMenuItem(value: 'planned', child: Text('Planned')),
                        DropdownMenuItem(value: 'in_progress', child: Text('In Progress')),
                        DropdownMenuItem(value: 'completed', child: Text('Completed')),
                      ],
                      onChanged: (value) {
                        setState(() => _status = value!);
                      },
                    ),
                  ),
                ],
              ).animate().fadeIn(delay: 150.ms),

              const SizedBox(height: 16),

              // Tooth Number
              if (_category == 'fillings' || _category == 'orthodontics')
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Select Teeth',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(height: 8),
                    _buildToothSelector(),
                  ],
                ).animate().fadeIn(delay: 200.ms),

              const SizedBox(height: 24),

              // Diagnosis
              _buildSectionTitle('Diagnosis & Notes'),
              const SizedBox(height: 12),

              TextFormField(
                controller: _diagnosisController,
                decoration: const InputDecoration(
                  labelText: 'Diagnosis',
                  prefixIcon: Icon(Icons.search),
                ),
                maxLines: 2,
                textCapitalization: TextCapitalization.sentences,
              ).animate().fadeIn(delay: 250.ms),

              const SizedBox(height: 16),

              TextFormField(
                controller: _notesController,
                decoration: const InputDecoration(
                  labelText: 'Treatment Notes',
                  prefixIcon: Icon(Icons.note_outlined),
                  alignLabelWithHint: true,
                ),
                maxLines: 3,
                textCapitalization: TextCapitalization.sentences,
              ).animate().fadeIn(delay: 300.ms),

              const SizedBox(height: 16),

              TextFormField(
                controller: _materialsController,
                decoration: const InputDecoration(
                  labelText: 'Materials Used (comma separated)',
                  prefixIcon: Icon(Icons.build_outlined),
                ),
              ).animate().fadeIn(delay: 350.ms),

              const SizedBox(height: 16),

              TextFormField(
                controller: _progressController,
                decoration: const InputDecoration(
                  labelText: 'Progress Notes',
                  prefixIcon: Icon(Icons.trending_up_outlined),
                  alignLabelWithHint: true,
                ),
                maxLines: 2,
              ).animate().fadeIn(delay: 400.ms),

              const SizedBox(height: 16),

              TextFormField(
                controller: _costController,
                decoration: const InputDecoration(
                  labelText: 'Cost (optional)',
                  prefixIcon: Icon(Icons.attach_money),
                ),
                keyboardType: TextInputType.number,
              ).animate().fadeIn(delay: 450.ms),

              const SizedBox(height: 24),

              // Photos Section
              _buildSectionTitle('Clinical Photos'),
              const SizedBox(height: 12),

              // Photo Buttons
              Row(
                children: [
                  Expanded(
                    child: _buildPhotoButton(
                      'Before',
                      Icons.photo_camera_outlined,
                      AppTheme.primaryColor,
                      () => _showPhotoOptions('before'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildPhotoButton(
                      'During',
                      Icons.photo_camera_outlined,
                      AppTheme.secondaryColor,
                      () => _showPhotoOptions('during'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildPhotoButton(
                      'After',
                      Icons.photo_camera_outlined,
                      AppTheme.successColor,
                      () => _showPhotoOptions('after'),
                    ),
                  ),
                ],
              ).animate().fadeIn(delay: 500.ms),

              const SizedBox(height: 16),

              // Photos Grid
              if (_images.isNotEmpty) _buildPhotosGrid(),

              const SizedBox(height: 32),

              // Save Button
              AnimatedButton(
                text: _isEditing ? 'Update Treatment' : 'Save Treatment',
                isLoading: _isLoading,
                onPressed: _saveTreatment,
                width: double.infinity,
              ).animate().fadeIn(delay: 550.ms),

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryColor,
          ),
    );
  }

  Widget _buildCategoryChip(
    String label,
    String value,
    Color color,
    IconData icon,
  ) {
    final isSelected = _category == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _category = value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? color : color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? color : color.withOpacity(0.3),
            ),
          ),
          child: Column(
            children: [
              Icon(
                icon,
                color: isSelected ? Colors.white : color,
                size: 20,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : color,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildToothSelector() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          // Upper teeth
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Upper Right
              ...AppConstants.upperRightTeeth.map((tooth) => _buildToothButton(tooth)),
              const SizedBox(width: 8),
              // Upper Left
              ...AppConstants.upperLeftTeeth.map((tooth) => _buildToothButton(tooth)),
            ],
          ),
          const SizedBox(height: 4),
          // Divider
          Container(
            width: double.infinity,
            height: 2,
            color: Colors.grey.shade300,
          ),
          const SizedBox(height: 4),
          // Lower teeth
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Lower Left
              ...AppConstants.lowerLeftTeeth.map((tooth) => _buildToothButton(tooth)),
              const SizedBox(width: 8),
              // Lower Right
              ...AppConstants.lowerRightTeeth.map((tooth) => _buildToothButton(tooth)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildToothButton(String toothNumber) {
    final isSelected = _selectedTeeth.contains(toothNumber);
    return GestureDetector(
      onTap: () {
        setState(() {
          if (isSelected) {
            _selectedTeeth.remove(toothNumber);
          } else {
            _selectedTeeth.add(toothNumber);
          }
        });
      },
      child: Container(
        width: 24,
        height: 24,
        margin: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryColor : Colors.transparent,
          border: Border.all(
            color: isSelected ? AppTheme.primaryColor : Colors.grey,
          ),
          borderRadius: BorderRadius.circular(4),
        ),
        child: Center(
          child: Text(
            toothNumber,
            style: TextStyle(
              fontSize: 8,
              fontWeight: FontWeight.bold,
              color: isSelected ? Colors.white : Colors.grey,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPhotoButton(
    String label,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w600,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhotosGrid() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Before photos
        if (_images.any((i) => i.label == 'before')) ...[
          Text('Before', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          _buildPhotoRow(_images.where((i) => i.label == 'before').toList()),
          const SizedBox(height: 12),
        ],
        // During photos
        if (_images.any((i) => i.label == 'during')) ...[
          Text('During', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          _buildPhotoRow(_images.where((i) => i.label == 'during').toList()),
          const SizedBox(height: 12),
        ],
        // After photos
        if (_images.any((i) => i.label == 'after')) ...[
          Text('After', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          _buildPhotoRow(_images.where((i) => i.label == 'after').toList()),
        ],
      ],
    );
  }

  Widget _buildPhotoRow(List<_LocalImage> images) {
    return SizedBox(
      height: 80,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: images.length,
        itemBuilder: (context, index) {
          final image = images[index];
          return Stack(
            children: [
              Container(
                width: 80,
                height: 80,
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.grey.shade200,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: image.isExisting && image.url != null
                      ? Image.network(
                          image.url!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Icon(Icons.error),
                        )
                      : image.file != null
                          ? Image.file(image.file!, fit: BoxFit.cover)
                          : const Icon(Icons.image),
                ),
              ),
              Positioned(
                top: 0,
                right: 8,
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _images.removeWhere((i) => i.imageId == image.imageId);
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: AppTheme.errorColor,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.close, color: Colors.white, size: 12),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  void _showPhotoOptions(String label) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take Photo'),
              onTap: () {
                Navigator.pop(context);
                _takePhoto(label);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickImages(label);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _LocalImage {
  final String imageId;
  final String label;
  final File? file;
  final bool isExisting;
  final String? url;

  _LocalImage({
    required this.imageId,
    required this.label,
    this.file,
    required this.isExisting,
    this.url,
  });
}
