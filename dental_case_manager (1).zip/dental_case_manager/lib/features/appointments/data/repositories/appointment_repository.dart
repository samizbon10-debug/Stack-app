import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';

import '../models/appointment_model.dart';
import '../../../../services/firebase_service.dart';

/// Appointment Repository for CRUD operations
class AppointmentRepository {
  final FirebaseFirestore _firestore;
  final Box _cacheBox;
  final Uuid _uuid = const Uuid();

  AppointmentRepository({
    required FirebaseFirestore firestore,
    required Box cacheBox,
  })  : _firestore = firestore,
        _cacheBox = cacheBox;

  CollectionReference<Map<String, dynamic>> get _appointmentsCollection =>
      _firestore.collection('appointments');

  /// Create a new appointment
  Future<AppointmentModel> createAppointment({
    required String patientId,
    required String userId,
    required String title,
    required String treatmentType,
    required DateTime date,
    int duration = 30,
    String notes = '',
    String status = 'scheduled',
    bool reminderEnabled = true,
    DateTime? reminderTime,
  }) async {
    final appointmentId = _uuid.v4();
    final now = DateTime.now();

    final appointment = AppointmentModel(
      appointmentId: appointmentId,
      patientId: patientId,
      userId: userId,
      title: title,
      treatmentType: treatmentType,
      date: date,
      duration: duration,
      notes: notes,
      status: status,
      reminderEnabled: reminderEnabled,
      reminderTime: reminderTime,
      createdAt: now,
      updatedAt: now,
    );

    // Save to Firestore
    await _appointmentsCollection
        .doc(appointmentId)
        .set(appointment.toFirestore());

    // Save to local cache
    await _cacheBox.put(appointmentId, appointment.toJson());

    return appointment;
  }

  /// Get an appointment by ID
  Future<AppointmentModel?> getAppointment(String appointmentId) async {
    // Try cache first
    final cachedData = _cacheBox.get(appointmentId);
    if (cachedData != null) {
      return AppointmentModel.fromJson(Map<String, dynamic>.from(cachedData));
    }

    // Fetch from Firestore
    final doc = await _appointmentsCollection.doc(appointmentId).get();
    if (doc.exists) {
      final appointment = AppointmentModel.fromFirestore(doc);
      // Update cache
      await _cacheBox.put(appointmentId, appointment.toJson());
      return appointment;
    }
    return null;
  }

  /// Get all appointments for a patient
  Future<List<AppointmentModel>> getPatientAppointments(
    String patientId,
  ) async {
    final snapshot = await _appointmentsCollection
        .where('patientId', isEqualTo: patientId)
        .orderBy('date', descending: true)
        .get();

    return snapshot.docs.map((doc) {
      final appointment = AppointmentModel.fromFirestore(doc);
      _cacheBox.put(appointment.appointmentId, appointment.toJson());
      return appointment;
    }).toList();
  }

  /// Get all appointments for a user
  Future<List<AppointmentModel>> getUserAppointments(String userId) async {
    final snapshot = await _appointmentsCollection
        .where('userId', isEqualTo: userId)
        .orderBy('date', descending: false)
        .get();

    return snapshot.docs.map((doc) {
      final appointment = AppointmentModel.fromFirestore(doc);
      _cacheBox.put(appointment.appointmentId, appointment.toJson());
      return appointment;
    }).toList();
  }

  /// Get upcoming appointments
  Future<List<AppointmentModel>> getUpcomingAppointments(String userId) async {
    final now = DateTime.now();
    final snapshot = await _appointmentsCollection
        .where('userId', isEqualTo: userId)
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(now))
        .where('status', whereIn: ['scheduled', 'confirmed'])
        .orderBy('date', descending: false)
        .limit(10)
        .get();

    return snapshot.docs.map((doc) => AppointmentModel.fromFirestore(doc)).toList();
  }

  /// Stream appointments for a patient
  Stream<List<AppointmentModel>> streamPatientAppointments(String patientId) {
    return _appointmentsCollection
        .where('patientId', isEqualTo: patientId)
        .orderBy('date', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        final appointment = AppointmentModel.fromFirestore(doc);
        _cacheBox.put(appointment.appointmentId, appointment.toJson());
        return appointment;
      }).toList();
    });
  }

  /// Stream all appointments for a user
  Stream<List<AppointmentModel>> streamUserAppointments(String userId) {
    return _appointmentsCollection
        .where('userId', isEqualTo: userId)
        .orderBy('date', descending: false)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) => AppointmentModel.fromFirestore(doc)).toList();
    });
  }

  /// Stream upcoming appointments
  Stream<List<AppointmentModel>> streamUpcomingAppointments(String userId) {
    final now = DateTime.now();
    return _appointmentsCollection
        .where('userId', isEqualTo: userId)
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(now))
        .where('status', whereIn: ['scheduled', 'confirmed'])
        .orderBy('date', descending: false)
        .limit(10)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) => AppointmentModel.fromFirestore(doc)).toList();
    });
  }

  /// Get today's appointments
  Stream<List<AppointmentModel>> streamTodaysAppointments(String userId) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = DateTime(now.year, now.month, now.day, 23, 59, 59);

    return _appointmentsCollection
        .where('userId', isEqualTo: userId)
        .where('date',
            isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('date', isLessThanOrEqualTo: Timestamp.fromDate(endOfDay))
        .orderBy('date', descending: false)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) => AppointmentModel.fromFirestore(doc)).toList();
    });
  }

  /// Update an appointment
  Future<void> updateAppointment(AppointmentModel appointment) async {
    final updatedAppointment = appointment.copyWith(updatedAt: DateTime.now());

    // Update in Firestore
    await _appointmentsCollection
        .doc(appointment.appointmentId)
        .update(updatedAppointment.toFirestore());

    // Update cache
    await _cacheBox.put(
      appointment.appointmentId,
      updatedAppointment.toJson(),
    );
  }

  /// Update appointment status
  Future<void> updateAppointmentStatus(
    String appointmentId,
    String status,
  ) async {
    await _appointmentsCollection.doc(appointmentId).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// Delete an appointment
  Future<void> deleteAppointment(String appointmentId) async {
    // Delete from Firestore
    await _appointmentsCollection.doc(appointmentId).delete();

    // Delete from cache
    await _cacheBox.delete(appointmentId);
  }

  /// Get appointment count for a date range
  Future<int> getAppointmentCount(String userId, DateTime start, DateTime end) async {
    final snapshot = await _appointmentsCollection
        .where('userId', isEqualTo: userId)
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('date', isLessThanOrEqualTo: Timestamp.fromDate(end))
        .count()
        .get();

    return snapshot.count ?? 0;
  }

  /// Get cached appointments (for offline use)
  List<AppointmentModel> getCachedAppointments() {
    return _cacheBox.values
        .map((data) =>
            AppointmentModel.fromJson(Map<String, dynamic>.from(data)))
        .toList();
  }
}

// Provider
final appointmentRepositoryProvider = Provider<AppointmentRepository>((ref) {
  final firestore = ref.watch(firestoreProvider);
  final cacheBox = Hive.box('appointments_cache');
  return AppointmentRepository(firestore: firestore, cacheBox: cacheBox);
});

// Patient appointments provider
final patientAppointmentsProvider =
    StreamProvider.family<List<AppointmentModel>, String>((ref, patientId) {
  final repository = ref.watch(appointmentRepositoryProvider);
  return repository.streamPatientAppointments(patientId);
});

// User appointments provider
final userAppointmentsProvider =
    StreamProvider.family<List<AppointmentModel>, String>((ref, userId) {
  final repository = ref.watch(appointmentRepositoryProvider);
  return repository.streamUserAppointments(userId);
});

// Upcoming appointments provider
final upcomingAppointmentsProvider =
    StreamProvider.family<List<AppointmentModel>, String>((ref, userId) {
  final repository = ref.watch(appointmentRepositoryProvider);
  return repository.streamUpcomingAppointments(userId);
});

// Today's appointments provider
final todaysAppointmentsProvider =
    StreamProvider.family<List<AppointmentModel>, String>((ref, userId) {
  final repository = ref.watch(appointmentRepositoryProvider);
  return repository.streamTodaysAppointments(userId);
});
