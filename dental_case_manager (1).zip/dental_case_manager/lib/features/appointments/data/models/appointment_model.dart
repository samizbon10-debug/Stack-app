import 'package:cloud_firestore/cloud_firestore.dart';

/// Appointment Model
class AppointmentModel {
  final String appointmentId;
  final String patientId;
  final String userId;
  final String title;
  final String treatmentType;
  final DateTime date;
  final int duration; // in minutes
  final String notes;
  final String status; // scheduled, confirmed, completed, cancelled
  final bool reminderEnabled;
  final DateTime? reminderTime;
  final DateTime createdAt;
  final DateTime updatedAt;

  const AppointmentModel({
    required this.appointmentId,
    required this.patientId,
    required this.userId,
    required this.title,
    required this.treatmentType,
    required this.date,
    this.duration = 30,
    required this.notes,
    this.status = 'scheduled',
    this.reminderEnabled = true,
    this.reminderTime,
    required this.createdAt,
    required this.updatedAt,
  });

  factory AppointmentModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return AppointmentModel(
      appointmentId: doc.id,
      patientId: data['patientId'] ?? '',
      userId: data['userId'] ?? '',
      title: data['title'] ?? '',
      treatmentType: data['treatmentType'] ?? '',
      date: (data['date'] as Timestamp?)?.toDate() ?? DateTime.now(),
      duration: data['duration'] ?? 30,
      notes: data['notes'] ?? '',
      status: data['status'] ?? 'scheduled',
      reminderEnabled: data['reminderEnabled'] ?? true,
      reminderTime: (data['reminderTime'] as Timestamp?)?.toDate(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  factory AppointmentModel.fromJson(Map<String, dynamic> json) {
    return AppointmentModel(
      appointmentId: json['appointmentId'] ?? '',
      patientId: json['patientId'] ?? '',
      userId: json['userId'] ?? '',
      title: json['title'] ?? '',
      treatmentType: json['treatmentType'] ?? '',
      date: json['date'] is Timestamp
          ? (json['date'] as Timestamp).toDate()
          : DateTime.parse(json['date']),
      duration: json['duration'] ?? 30,
      notes: json['notes'] ?? '',
      status: json['status'] ?? 'scheduled',
      reminderEnabled: json['reminderEnabled'] ?? true,
      reminderTime: json['reminderTime'] != null
          ? (json['reminderTime'] is Timestamp
              ? (json['reminderTime'] as Timestamp).toDate()
              : DateTime.parse(json['reminderTime']))
          : null,
      createdAt: json['createdAt'] is Timestamp
          ? (json['createdAt'] as Timestamp).toDate()
          : DateTime.parse(json['createdAt']),
      updatedAt: json['updatedAt'] is Timestamp
          ? (json['updatedAt'] as Timestamp).toDate()
          : DateTime.parse(json['updatedAt']),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'appointmentId': appointmentId,
      'patientId': patientId,
      'userId': userId,
      'title': title,
      'treatmentType': treatmentType,
      'date': Timestamp.fromDate(date),
      'duration': duration,
      'notes': notes,
      'status': status,
      'reminderEnabled': reminderEnabled,
      'reminderTime':
          reminderTime != null ? Timestamp.fromDate(reminderTime!) : null,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  Map<String, dynamic> toJson() {
    return {
      'appointmentId': appointmentId,
      'patientId': patientId,
      'userId': userId,
      'title': title,
      'treatmentType': treatmentType,
      'date': date.toIso8601String(),
      'duration': duration,
      'notes': notes,
      'status': status,
      'reminderEnabled': reminderEnabled,
      'reminderTime': reminderTime?.toIso8601String(),
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  AppointmentModel copyWith({
    String? appointmentId,
    String? patientId,
    String? userId,
    String? title,
    String? treatmentType,
    DateTime? date,
    int? duration,
    String? notes,
    String? status,
    bool? reminderEnabled,
    DateTime? reminderTime,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return AppointmentModel(
      appointmentId: appointmentId ?? this.appointmentId,
      patientId: patientId ?? this.patientId,
      userId: userId ?? this.userId,
      title: title ?? this.title,
      treatmentType: treatmentType ?? this.treatmentType,
      date: date ?? this.date,
      duration: duration ?? this.duration,
      notes: notes ?? this.notes,
      status: status ?? this.status,
      reminderEnabled: reminderEnabled ?? this.reminderEnabled,
      reminderTime: reminderTime ?? this.reminderTime,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  // Check if appointment is upcoming
  bool get isUpcoming => date.isAfter(DateTime.now());

  // Check if appointment is today
  bool get isToday {
    final now = DateTime.now();
    return date.year == now.year &&
        date.month == now.month &&
        date.day == now.day;
  }

  // Get formatted time
  String get formattedTime {
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  @override
  String toString() {
    return 'AppointmentModel(appointmentId: $appointmentId, title: $title, date: $date)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is AppointmentModel && other.appointmentId == appointmentId;
  }

  @override
  int get hashCode => appointmentId.hashCode;
}
