import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/appointment_model.dart';

// Appointments State
class AppointmentsState {
  final List<AppointmentModel> appointments;
  final bool isLoading;
  final String? error;

  AppointmentsState({
    this.appointments = const [],
    this.isLoading = false,
    this.error,
  });

  AppointmentsState copyWith({
    List<AppointmentModel>? appointments,
    bool? isLoading,
    String? error,
  }) {
    return AppointmentsState(
      appointments: appointments ?? this.appointments,
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }

  List<AppointmentModel> get upcomingAppointments {
    final now = DateTime.now();
    return appointments
        .where((a) => a.startDateTime.isAfter(now) && 
            a.status != AppointmentStatus.cancelled)
        .toList()
      ..sort((a, b) => a.startDateTime.compareTo(b.startDateTime));
  }

  List<AppointmentModel> get todayAppointments {
    final now = DateTime.now();
    return appointments
        .where((a) => a.isToday && a.status != AppointmentStatus.cancelled)
        .toList()
      ..sort((a, b) => a.startTime.compareTo(b.startTime));
  }

  List<AppointmentModel> get pastAppointments {
    final now = DateTime.now();
    return appointments
        .where((a) => a.endDateTime.isBefore(now))
        .toList()
      ..sort((a, b) => b.startDateTime.compareTo(a.startDateTime));
  }
}

// Appointments Notifier
class AppointmentsNotifier extends StateNotifier<AppointmentsState> {
  final FirebaseFirestore _firestore;
  final String userId;

  AppointmentsNotifier({
    required FirebaseFirestore firestore,
    required this.userId,
  })  : _firestore = firestore,
        super(AppointmentsState()) {
    fetchAppointments();
  }

  void fetchAppointments() {
    state = state.copyWith(isLoading: true);
    
    _firestore
        .collection('appointments')
        .where('userId', isEqualTo: userId)
        .orderBy('date', descending: false)
        .snapshots()
        .listen(
      (snapshot) {
        final appointments = snapshot.docs
            .map((doc) => AppointmentModel.fromFirestore(doc))
            .toList();
        state = state.copyWith(
          appointments: appointments,
          isLoading: false,
        );
      },
      onError: (error) {
        state = state.copyWith(
          isLoading: false,
          error: error.toString(),
        );
      },
    );
  }

  Future<AppointmentModel?> createAppointment(AppointmentModel appointment) async {
    try {
      state = state.copyWith(isLoading: true);
      
      final docRef = await _firestore.collection('appointments').add(appointment.toMap());
      
      final newAppointment = appointment.copyWith(
        appointmentId: docRef.id,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      
      state = state.copyWith(isLoading: false);
      return newAppointment;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: 'Failed to create appointment: $e',
      );
      return null;
    }
  }

  Future<bool> updateAppointment(AppointmentModel appointment) async {
    try {
      await _firestore
          .collection('appointments')
          .doc(appointment.appointmentId)
          .update({
            ...appointment.toMap(),
            'updatedAt': FieldValue.serverTimestamp(),
          });
      return true;
    } catch (e) {
      state = state.copyWith(error: 'Failed to update appointment: $e');
      return false;
    }
  }

  Future<bool> deleteAppointment(String appointmentId) async {
    try {
      await _firestore.collection('appointments').doc(appointmentId).delete();
      return true;
    } catch (e) {
      state = state.copyWith(error: 'Failed to delete appointment: $e');
      return false;
    }
  }

  Future<bool> updateAppointmentStatus(
    String appointmentId,
    AppointmentStatus status,
  ) async {
    try {
      await _firestore
          .collection('appointments')
          .doc(appointmentId)
          .update({
            'status': _statusToString(status),
            'updatedAt': FieldValue.serverTimestamp(),
          });
      return true;
    } catch (e) {
      state = state.copyWith(error: 'Failed to update status: $e');
      return false;
    }
  }

  String _statusToString(AppointmentStatus status) {
    switch (status) {
      case AppointmentStatus.scheduled:
        return 'scheduled';
      case AppointmentStatus.confirmed:
        return 'confirmed';
      case AppointmentStatus.completed:
        return 'completed';
      case AppointmentStatus.cancelled:
        return 'cancelled';
      case AppointmentStatus.noShow:
        return 'no_show';
    }
  }

  void clearError() {
    state = state.copyWith(error: null);
  }
}

// Provider
final appointmentsProvider =
    StateNotifierProvider.family<AppointmentsNotifier, AppointmentsState, String>(
  (ref, userId) {
    return AppointmentsNotifier(
      firestore: FirebaseFirestore.instance,
      userId: userId,
    );
  },
);

// Patient Appointments Provider
final patientAppointmentsProvider =
    FutureProvider.family<List<AppointmentModel>, String>((ref, patientId) async {
  final snapshot = await FirebaseFirestore.instance
      .collection('appointments')
      .where('patientId', isEqualTo: patientId)
      .orderBy('date', descending: true)
      .get();

  return snapshot.docs
      .map((doc) => AppointmentModel.fromFirestore(doc))
      .toList();
});

// Upcoming Appointments Count Provider
final upcomingAppointmentsCountProvider = Provider.family<int, String>((ref, userId) {
  final state = ref.watch(appointmentsProvider(userId));
  return state.upcomingAppointments.length;
});

// Today's Appointments Count Provider
final todayAppointmentsCountProvider = Provider.family<int, String>((ref, userId) {
  final state = ref.watch(appointmentsProvider(userId));
  return state.todayAppointments.length;
});
