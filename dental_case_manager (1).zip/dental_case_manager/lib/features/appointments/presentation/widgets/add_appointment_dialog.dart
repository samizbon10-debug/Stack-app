import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../../patients/data/patients_provider.dart';
import '../../../appointments/data/appointments_provider.dart';
import '../../../models/appointment_model.dart';

class AddAppointmentDialog extends ConsumerStatefulWidget {
  final String userId;
  final DateTime? initialDate;

  const AddAppointmentDialog({
    super.key,
    required this.userId,
    this.initialDate,
  });

  @override
  ConsumerState<AddAppointmentDialog> createState() => _AddAppointmentDialogState();
}

class _AddAppointmentDialogState extends ConsumerState<AddAppointmentDialog> {
  final _formKey = GlobalKey<FormState>();
  final _notesController = TextEditingController();
  
  String? _selectedPatientId;
  String _treatmentType = '';
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _startTime = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _endTime = const TimeOfDay(hour: 9, minute: 30);
  AppointmentStatus _status = AppointmentStatus.scheduled;
  bool _isLoading = false;

  final List<String> _treatmentTypes = [
    'Orthodontics Consultation',
    'Orthodontics Adjustment',
    'Filling',
    'Root Canal',
    'Extraction',
    'Scaling & Polishing',
    'Teeth Whitening',
    'Crown Fitting',
    'Bridge Work',
    'Dental Implant',
    'Check-up',
    'Other',
  ];

  @override
  void initState() {
    super.initState();
    if (widget.initialDate != null) {
      _selectedDate = widget.initialDate!;
    }
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _selectTime(bool isStartTime) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: isStartTime ? _startTime : _endTime,
    );
    if (picked != null) {
      setState(() {
        if (isStartTime) {
          _startTime = picked;
          // Auto-set end time 30 mins later
          _endTime = TimeOfDay(
            hour: picked.hour,
            minute: (picked.minute + 30) % 60,
          );
          if (picked.minute + 30 >= 60) {
            _endTime = TimeOfDay(hour: picked.hour + 1, minute: 0);
          }
        } else {
          _endTime = picked;
        }
      });
    }
  }

  Future<void> _saveAppointment() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedPatientId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a patient')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final appointment = AppointmentModel(
        appointmentId: '',
        patientId: _selectedPatientId!,
        userId: widget.userId,
        date: _selectedDate,
        startTime: '${_startTime.hour.toString().padLeft(2, '0')}:${_startTime.minute.toString().padLeft(2, '0')}',
        endTime: '${_endTime.hour.toString().padLeft(2, '0')}:${_endTime.minute.toString().padLeft(2, '0')}',
        treatmentType: _treatmentType,
        notes: _notesController.text.trim(),
        status: _status,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await ref.read(appointmentsProvider(widget.userId).notifier).createAppointment(appointment);

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Appointment scheduled successfully'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: AppColors.error,
        ),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final patientsState = ref.watch(patientsProvider(widget.userId));

    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Padding(
        padding: const EdgeInsets.all(AppSizes.paddingL),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Handle bar
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: AppSizes.spacingM),
                    decoration: BoxDecoration(
                      color: AppColors.textHint,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),

                Text(
                  'New Appointment',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),

                const SizedBox(height: AppSizes.spacingL),

                // Patient Selection
                DropdownButtonFormField<String>(
                  value: _selectedPatientId,
                  decoration: const InputDecoration(
                    labelText: 'Select Patient *',
                    prefixIcon: Icon(Icons.person),
                  ),
                  items: patientsState.patients.map((patient) {
                    return DropdownMenuItem(
                      value: patient.patientId,
                      child: Text(patient.name),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() => _selectedPatientId = value);
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Please select a patient';
                    }
                    return null;
                  },
                ),

                const SizedBox(height: AppSizes.spacingM),

                // Treatment Type
                DropdownButtonFormField<String>(
                  value: _treatmentType.isNotEmpty ? _treatmentType : null,
                  decoration: const InputDecoration(
                    labelText: 'Treatment Type *',
                    prefixIcon: Icon(Icons.medical_services),
                  ),
                  items: _treatmentTypes.map((type) {
                    return DropdownMenuItem(
                      value: type,
                      child: Text(type),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() => _treatmentType = value ?? '');
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select treatment type';
                    }
                    return null;
                  },
                ),

                const SizedBox(height: AppSizes.spacingM),

                // Date Selection
                InkWell(
                  onTap: _selectDate,
                  child: InputDecorator(
                    decoration: const InputDecoration(
                      labelText: 'Date',
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                    child: Text(
                      DateFormat('EEEE, MMMM d, y').format(_selectedDate),
                    ),
                  ),
                ),

                const SizedBox(height: AppSizes.spacingM),

                // Time Selection
                Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () => _selectTime(true),
                        child: InputDecorator(
                          decoration: const InputDecoration(
                            labelText: 'Start Time',
                            prefixIcon: Icon(Icons.access_time),
                          ),
                          child: Text(
                            _startTime.format(context),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSizes.spacingM),
                    Expanded(
                      child: InkWell(
                        onTap: () => _selectTime(false),
                        child: InputDecorator(
                          decoration: const InputDecoration(
                            labelText: 'End Time',
                            prefixIcon: Icon(Icons.access_time),
                          ),
                          child: Text(
                            _endTime.format(context),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: AppSizes.spacingM),

                // Status
                DropdownButtonFormField<AppointmentStatus>(
                  value: _status,
                  decoration: const InputDecoration(
                    labelText: 'Status',
                    prefixIcon: Icon(Icons.info_outline),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: AppointmentStatus.scheduled,
                      child: Text('Scheduled'),
                    ),
                    DropdownMenuItem(
                      value: AppointmentStatus.confirmed,
                      child: Text('Confirmed'),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() => _status = value!);
                  },
                ),

                const SizedBox(height: AppSizes.spacingM),

                // Notes
                TextFormField(
                  controller: _notesController,
                  decoration: const InputDecoration(
                    labelText: 'Notes',
                    prefixIcon: Icon(Icons.notes),
                  ),
                  maxLines: 2,
                ),

                const SizedBox(height: AppSizes.spacingL),

                // Save Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _saveAppointment,
                    child: _isLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Text('Schedule Appointment'),
                  ),
                ),

                const SizedBox(height: AppSizes.spacingM),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
