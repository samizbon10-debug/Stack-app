import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:photo_view/photo_view.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../../auth/data/auth_provider.dart';
import '../../../treatments/data/treatments_provider.dart';
import '../../../models/treatment_model.dart';

class CaseGalleryScreen extends ConsumerStatefulWidget {
  const CaseGalleryScreen({super.key});

  @override
  ConsumerState<CaseGalleryScreen> createState() => _CaseGalleryScreenState();
}

class _CaseGalleryScreenState extends ConsumerState<CaseGalleryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _selectedCategory = 'all';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider).userModel;
    final userId = user?.userId ?? '';
    final treatmentsState = ref.watch(treatmentsProvider(userId));

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            expandedHeight: 120,
            floating: true,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: AppColors.headerGradient,
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(AppSizes.paddingM),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          AppStrings.caseGallery,
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        Text(
                          'Before & After Cases',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(
                                color: Colors.white.withOpacity(0.9),
                              ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Category Filter
          SliverPersistentHeader(
            delegate: _CategoryFilterDelegate(
              selectedCategory: _selectedCategory,
              onCategorySelected: (category) {
                setState(() => _selectedCategory = category);
              },
            ),
            pinned: true,
          ),

          // Gallery Grid
          treatmentsState.isLoading
              ? const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator()),
                )
              : _buildGalleryGrid(treatmentsState.treatments),
        ],
      ),
    );
  }

  Widget _buildGalleryGrid(List<TreatmentModel> treatments) {
    // Filter treatments with images
    var filteredTreatments = treatments.where((t) => t.images.totalImages > 0).toList();

    // Apply category filter
    if (_selectedCategory != 'all') {
      filteredTreatments = filteredTreatments.where((t) {
        switch (_selectedCategory) {
          case 'orthodontics':
            return t.category == TreatmentCategory.orthodontics;
          case 'fillings':
            return t.category == TreatmentCategory.fillings;
          case 'scaling':
            return t.category == TreatmentCategory.scalingPolishing;
          default:
            return true;
        }
      }).toList();
    }

    if (filteredTreatments.isEmpty) {
      return SliverFillRemaining(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.photo_library_outlined,
                size: 64,
                color: AppColors.textHint,
              ),
              const SizedBox(height: AppSizes.spacingM),
              Text(
                'No cases with photos',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: AppColors.textSecondary,
                    ),
              ),
              const SizedBox(height: AppSizes.spacingS),
              Text(
                'Add photos to treatments to see them here',
                style: TextStyle(color: AppColors.textHint),
              ),
            ],
          ),
        ),
      );
    }

    return SliverPadding(
      padding: const EdgeInsets.all(AppSizes.paddingM),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: AppSizes.spacingM,
          crossAxisSpacing: AppSizes.spacingM,
          childAspectRatio: 1.0,
        ),
        delegate: SliverChildBuilderDelegate(
          (context, index) {
            final treatment = filteredTreatments[index];
            return _buildCaseCard(treatment, index);
          },
          childCount: filteredTreatments.length,
        ),
      ),
    );
  }

  Widget _buildCaseCard(TreatmentModel treatment, int index) {
    final hasBefore = treatment.images.before.isNotEmpty;
    final hasAfter = treatment.images.after.isNotEmpty;
    final primaryImage = hasAfter
        ? treatment.images.after.first
        : hasBefore
            ? treatment.images.before.first
            : treatment.images.during.firstOrNull;

    return GestureDetector(
      onTap: () => _showCaseDetail(treatment),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppSizes.radiusL),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(AppSizes.radiusL),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Primary Image
              if (primaryImage != null)
                Image.network(
                  primaryImage,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: AppColors.surfaceVariant,
                    child: const Icon(Icons.broken_image, color: AppColors.textHint),
                  ),
                ),
              
              // Gradient Overlay
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.7),
                    ],
                    stops: const [0.5, 1.0],
                  ),
                ),
              ),
              
              // Category Badge
              Positioned(
                top: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: _getCategoryColor(treatment.category),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    _getCategoryName(treatment.category),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              
              // Before/After Badge
              if (hasBefore && hasAfter)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.success,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text(
                      'B/A',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              
              // Info
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                padding: const EdgeInsets.all(AppSizes.paddingS),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      treatment.diagnosis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Icon(
                          Icons.photo_library,
                          size: 12,
                          color: Colors.white.withOpacity(0.8),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${treatment.images.totalImages} photos',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.8),
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    )
        .animate()
        .fadeIn(delay: Duration(milliseconds: index * 50))
        .scale(
          begin: const Offset(0.9, 0.9),
          end: const Offset(1, 1),
          delay: Duration(milliseconds: index * 50),
        );
  }

  void _showCaseDetail(TreatmentModel treatment) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.9,
        maxChildSize: 0.95,
        minChildSize: 0.5,
        builder: (context, scrollController) {
          return Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(AppSizes.radiusXL),
              ),
            ),
            child: _CaseDetailView(
              treatment: treatment,
              scrollController: scrollController,
            ),
          );
        },
      ),
    );
  }

  Color _getCategoryColor(TreatmentCategory category) {
    switch (category) {
      case TreatmentCategory.orthodontics:
        return AppColors.orthodontics;
      case TreatmentCategory.fillings:
        return AppColors.fillings;
      case TreatmentCategory.scalingPolishing:
        return AppColors.scalingPolishing;
    }
  }

  String _getCategoryName(TreatmentCategory category) {
    switch (category) {
      case TreatmentCategory.orthodontics:
        return 'Orthodontics';
      case TreatmentCategory.fillings:
        return 'Fillings';
      case TreatmentCategory.scalingPolishing:
        return 'Scale & Polish';
    }
  }
}

class _CategoryFilterDelegate extends SliverPersistentHeaderDelegate {
  final String selectedCategory;
  final Function(String) onCategorySelected;

  _CategoryFilterDelegate({
    required this.selectedCategory,
    required this.onCategorySelected,
  });

  @override
  double get minExtent => 60;

  @override
  double get maxExtent => 60;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor,
      padding: const EdgeInsets.symmetric(
        horizontal: AppSizes.paddingM,
        vertical: AppSizes.paddingS,
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildFilterChip(context, 'All Cases', 'all'),
            const SizedBox(width: AppSizes.spacingS),
            _buildFilterChip(
                context, 'Orthodontics', 'orthodontics', AppColors.orthodontics),
            const SizedBox(width: AppSizes.spacingS),
            _buildFilterChip(
                context, 'Fillings', 'fillings', AppColors.fillings),
            const SizedBox(width: AppSizes.spacingS),
            _buildFilterChip(
                context, 'Scale & Polish', 'scaling', AppColors.scalingPolishing),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(
    BuildContext context,
    String label,
    String value, [
    Color? color,
  ]) {
    final isSelected = selectedCategory == value;
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) => onCategorySelected(value),
      backgroundColor: Colors.white,
      selectedColor: color ?? AppColors.primary,
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : AppColors.textPrimary,
        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
      ),
      checkmarkColor: Colors.white,
    );
  }

  @override
  bool shouldRebuild(_CategoryFilterDelegate oldDelegate) {
    return selectedCategory != oldDelegate.selectedCategory;
  }
}

class _CaseDetailView extends StatelessWidget {
  final TreatmentModel treatment;
  final ScrollController scrollController;

  const _CaseDetailView({
    required this.treatment,
    required this.scrollController,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Handle bar
        Center(
          child: Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.symmetric(vertical: AppSizes.spacingM),
            decoration: BoxDecoration(
              color: AppColors.textHint,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),

        Expanded(
          child: ListView(
            controller: scrollController,
            padding: const EdgeInsets.all(AppSizes.paddingM),
            children: [
              // Before/After Comparison
              if (treatment.images.before.isNotEmpty &&
                  treatment.images.after.isNotEmpty) ...[
                _buildComparisonSection(context),
                const SizedBox(height: AppSizes.spacingL),
              ],

              // Before Photos
              if (treatment.images.before.isNotEmpty) ...[
                _buildPhotoSection(
                  context,
                  'Before Treatment',
                  treatment.images.before,
                  AppColors.error,
                ),
                const SizedBox(height: AppSizes.spacingM),
              ],

              // During Photos
              if (treatment.images.during.isNotEmpty) ...[
                _buildPhotoSection(
                  context,
                  'During Treatment',
                  treatment.images.during,
                  AppColors.warning,
                ),
                const SizedBox(height: AppSizes.spacingM),
              ],

              // After Photos
              if (treatment.images.after.isNotEmpty)
                _buildPhotoSection(
                  context,
                  'After Treatment',
                  treatment.images.after,
                  AppColors.success,
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildComparisonSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Before & After Comparison',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: AppSizes.spacingM),
        Row(
          children: [
            Expanded(
              child: _buildComparisonImage(
                treatment.images.before.first,
                'Before',
                AppColors.error,
              ),
            ),
            const SizedBox(width: AppSizes.spacingS),
            Expanded(
              child: _buildComparisonImage(
                treatment.images.after.first,
                'After',
                AppColors.success,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildComparisonImage(String url, String label, Color color) {
    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(AppSizes.radiusM),
          child: Image.network(
            url,
            height: 150,
            width: double.infinity,
            fit: BoxFit.cover,
          ),
        ),
        Positioned(
          bottom: 8,
          left: 8,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPhotoSection(
    BuildContext context,
    String title,
    List<String> photos,
    Color color,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
          ],
        ),
        const SizedBox(height: AppSizes.spacingM),
        SizedBox(
          height: 120,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: photos.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () => _showFullScreenImage(context, photos, index),
                child: Padding(
                  padding: const EdgeInsets.only(right: AppSizes.spacingS),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(AppSizes.radiusM),
                    child: Image.network(
                      photos[index],
                      height: 120,
                      width: 120,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  void _showFullScreenImage(
      BuildContext context, List<String> photos, int initialIndex) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => _FullScreenGallery(
          photos: photos,
          initialIndex: initialIndex,
        ),
      ),
    );
  }
}

class _FullScreenGallery extends StatefulWidget {
  final List<String> photos;
  final int initialIndex;

  const _FullScreenGallery({
    required this.photos,
    required this.initialIndex,
  });

  @override
  State<_FullScreenGallery> createState() => _FullScreenGalleryState();
}

class _FullScreenGalleryState extends State<_FullScreenGallery> {
  late PageController _pageController;
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        title: Text('${_currentIndex + 1} / ${widget.photos.length}'),
      ),
      body: PageView.builder(
        controller: _pageController,
        itemCount: widget.photos.length,
        onPageChanged: (index) {
          setState(() => _currentIndex = index);
        },
        itemBuilder: (context, index) {
          return PhotoView(
            imageProvider: NetworkImage(widget.photos[index]),
            minScale: PhotoViewComputedScale.contained,
            maxScale: PhotoViewComputedScale.covered * 2,
          );
        },
      ),
    );
  }
}
