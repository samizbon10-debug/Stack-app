import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:photo_view/photo_view.dart';

import '../../../treatments/data/models/treatment_model.dart';
import '../../../treatments/data/repositories/treatment_repository.dart';
import '../../../patients/data/repositories/patient_repository.dart';
import '../../../auth/data/auth_service.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/animated_widgets.dart';
import '../../../../core/utils/helpers.dart';

class CaseGalleryPage extends ConsumerStatefulWidget {
  final String? category;

  const CaseGalleryPage({super.key, this.category});

  @override
  ConsumerState<CaseGalleryPage> createState() => _CaseGalleryPageState();
}

class _CaseGalleryPageState extends ConsumerState<CaseGalleryPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _selectedCategory = 'all';

  @override
  void initState() {
    super.initState();
    _selectedCategory = widget.category ?? 'all';
    _tabController = TabController(length: 4, vsync: this);
    _tabController.index = _getTabIndex(_selectedCategory);
    _tabController.addListener(_onTabChanged);
  }

  int _getTabIndex(String category) {
    switch (category) {
      case 'orthodontics':
        return 1;
      case 'fillings':
        return 2;
      case 'scaling_polishing':
        return 3;
      default:
        return 0;
    }
  }

  void _onTabChanged() {
    final categories = ['all', 'orthodontics', 'fillings', 'scaling_polishing'];
    setState(() => _selectedCategory = categories[_tabController.index]);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authStateProvider).value;
    final userId = user?.uid ?? '';

    final treatmentsAsync = ref.watch(userTreatmentsProvider(userId));

    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) {
          return [
            SliverAppBar(
              expandedHeight: 160,
              floating: false,
              pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: AppTheme.headerGradient,
                  ),
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Case Gallery',
                            style:
                                Theme.of(context).textTheme.headlineMedium?.copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                          ).animate().fadeIn(duration: 300.ms),
                          const SizedBox(height: 4),
                          Text(
                            'Before & After Treatment Results',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: 14,
                            ),
                          ).animate().fadeIn(delay: 100.ms, duration: 300.ms),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              bottom: TabBar(
                controller: _tabController,
                labelColor: AppTheme.primaryColor,
                unselectedLabelColor: Colors.grey,
                indicatorColor: AppTheme.primaryColor,
                isScrollable: false,
                tabs: const [
                  Tab(text: 'All'),
                  Tab(text: 'Orthodontics'),
                  Tab(text: 'Fillings'),
                  Tab(text: 'Scaling'),
                ],
              ),
            ),
          ];
        },
        body: TabBarView(
          controller: _tabController,
          children: [
            _buildGalleryList(treatmentsAsync, null),
            _buildGalleryList(treatmentsAsync, 'orthodontics'),
            _buildGalleryList(treatmentsAsync, 'fillings'),
            _buildGalleryList(treatmentsAsync, 'scaling_polishing'),
          ],
        ),
      ),
    );
  }

  Widget _buildGalleryList(
    AsyncValue<List<TreatmentModel>> treatmentsAsync,
    String? category,
  ) {
    return treatmentsAsync.when(
      data: (treatments) {
        // Filter treatments with before/after images
        var filteredTreatments = treatments.where((t) {
          final hasBefore = t.images.any((img) => img.label == 'before');
          final hasAfter = t.images.any((img) => img.label == 'after');
          return hasBefore && hasAfter;
        }).toList();

        // Filter by category if specified
        if (category != null) {
          filteredTreatments =
              filteredTreatments.where((t) => t.category == category).toList();
        }

        if (filteredTreatments.isEmpty) {
          return _buildEmptyState();
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: filteredTreatments.length,
          itemBuilder: (context, index) {
            final treatment = filteredTreatments[index];
            return AnimatedListItem(
              index: index,
              child: _buildCaseCard(treatment),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }

  Widget _buildCaseCard(TreatmentModel treatment) {
    final categoryColor = AppHelpers.getTreatmentColor(treatment.category);
    final categoryName = treatment.category == 'orthodontics'
        ? 'Orthodontics'
        : treatment.category == 'fillings'
            ? 'Fillings'
            : 'Scaling & Polishing';

    final beforeImages = treatment.beforeImages;
    final afterImages = treatment.afterImages;

    return AnimatedCard(
      margin: const EdgeInsets.only(bottom: 16),
      onTap: () => _showCaseDetail(treatment),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: categoryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  categoryName,
                  style: TextStyle(
                    color: categoryColor,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                AppHelpers.formatDate(treatment.date),
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Before/After Images
          if (beforeImages.isNotEmpty && afterImages.isNotEmpty)
            _buildBeforeAfterComparison(
              beforeImages.first.url,
              afterImages.first.url,
            ),

          const SizedBox(height: 12),

          // Diagnosis
          if (treatment.diagnosis.isNotEmpty)
            Text(
              treatment.diagnosis,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),

          const SizedBox(height: 8),

          // View details button
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${treatment.images.length} photos',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 12,
                ),
              ),
              TextButton(
                onPressed: () => _showCaseDetail(treatment),
                child: const Text('View Details'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBeforeAfterComparison(String beforeUrl, String afterUrl) {
    return GestureDetector(
      onTap: () => _showComparisonSlider(beforeUrl, afterUrl),
      child: Stack(
        children: [
          // After image (full width)
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: CachedNetworkImage(
              imageUrl: afterUrl,
              height: 200,
              width: double.infinity,
              fit: BoxFit.cover,
              placeholder: (context, url) => Container(
                height: 200,
                color: Colors.grey.shade200,
                child: const Center(child: CircularProgressIndicator()),
              ),
              errorWidget: (context, url, error) => Container(
                height: 200,
                color: Colors.grey.shade200,
                child: const Icon(Icons.error_outline),
              ),
            ),
          ),

          // Before image (half width with clip)
          Positioned(
            left: 0,
            top: 0,
            bottom: 0,
            child: ClipRect(
              child: Align(
                alignment: Alignment.centerLeft,
                widthFactor: 0.5,
                child: CachedNetworkImage(
                  imageUrl: beforeUrl,
                  height: 200,
                  width: MediaQuery.of(context).size.width - 64,
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Container(
                    height: 200,
                    color: Colors.grey.shade200,
                  ),
                  errorWidget: (context, url, error) => Container(
                    height: 200,
                    color: Colors.grey.shade200,
                    child: const Icon(Icons.error_outline),
                  ),
                ),
              ),
            ),
          ),

          // Center divider
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            child: Center(
              child: Container(
                width: 2,
                color: Colors.white,
              ),
            ),
          ),

          // Labels
          Positioned(
            left: 8,
            top: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                'BEFORE',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Positioned(
            right: 8,
            top: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                'AFTER',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),

          // Tap to view overlay
          Positioned(
            right: 8,
            bottom: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.primaryColor,
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Row(
                children: [
                  Icon(Icons.touch_app, color: Colors.white, size: 14),
                  SizedBox(width: 4),
                  Text(
                    'Compare',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.photo_library_outlined,
            size: 80,
            color: Colors.grey.shade300,
          ),
          const SizedBox(height: 16),
          Text(
            'No Cases Yet',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: Colors.grey.shade600,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'Add before/after photos to your treatments\nto see them here',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey.shade500,
                ),
          ),
        ],
      ),
    ).animate().fadeIn();
  }

  void _showCaseDetail(TreatmentModel treatment) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _CaseDetailSheet(treatment: treatment),
    );
  }

  void _showComparisonSlider(String beforeUrl, String afterUrl) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => _BeforeAfterSlider(
          beforeUrl: beforeUrl,
          afterUrl: afterUrl,
        ),
      ),
    );
  }
}

class _CaseDetailSheet extends StatelessWidget {
  final TreatmentModel treatment;

  const _CaseDetailSheet({required this.treatment});

  @override
  Widget build(BuildContext context) {
    final categoryColor = AppHelpers.getTreatmentColor(treatment.category);

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.8,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Category and date
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: categoryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          treatment.category.toUpperCase(),
                          style: TextStyle(
                            color: categoryColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      const Spacer(),
                      Text(
                        AppHelpers.formatDate(treatment.date),
                        style: TextStyle(color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Diagnosis
                  if (treatment.diagnosis.isNotEmpty) ...[
                    Text(
                      'Diagnosis',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(height: 4),
                    Text(treatment.diagnosis),
                    const SizedBox(height: 16),
                  ],

                  // Treatment Notes
                  if (treatment.treatmentNotes.isNotEmpty) ...[
                    Text(
                      'Treatment Notes',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(height: 4),
                    Text(treatment.treatmentNotes),
                    const SizedBox(height: 16),
                  ],

                  // Materials
                  if (treatment.materials.isNotEmpty) ...[
                    Text(
                      'Materials Used',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: treatment.materials.map((m) {
                        return Chip(
                          label: Text(m),
                          backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // Photos
                  Text(
                    'Photos',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 8),

                  // Before photos
                  if (treatment.beforeImages.isNotEmpty) ...[
                    const Text('Before',
                        style: TextStyle(fontWeight: FontWeight.w500)),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 100,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: treatment.beforeImages.length,
                        itemBuilder: (context, index) {
                          return _buildPhotoThumb(
                              treatment.beforeImages[index].url);
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // During photos
                  if (treatment.duringImages.isNotEmpty) ...[
                    const Text('During',
                        style: TextStyle(fontWeight: FontWeight.w500)),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 100,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: treatment.duringImages.length,
                        itemBuilder: (context, index) {
                          return _buildPhotoThumb(
                              treatment.duringImages[index].url);
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // After photos
                  if (treatment.afterImages.isNotEmpty) ...[
                    const Text('After',
                        style: TextStyle(fontWeight: FontWeight.w500)),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 100,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: treatment.afterImages.length,
                        itemBuilder: (context, index) {
                          return _buildPhotoThumb(
                              treatment.afterImages[index].url);
                        },
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPhotoThumb(String url) {
    return Container(
      width: 100,
      height: 100,
      margin: const EdgeInsets.only(right: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: Colors.grey.shade200,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: CachedNetworkImage(
          imageUrl: url,
          fit: BoxFit.cover,
          placeholder: (context, url) => const Center(
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
          errorWidget: (context, url, error) => const Icon(Icons.error_outline),
        ),
      ),
    );
  }
}

class _BeforeAfterSlider extends StatefulWidget {
  final String beforeUrl;
  final String afterUrl;

  const _BeforeAfterSlider({
    required this.beforeUrl,
    required this.afterUrl,
  });

  @override
  State<_BeforeAfterSlider> createState() => _BeforeAfterSliderState();
}

class _BeforeAfterSliderState extends State<_BeforeAfterSlider> {
  double _sliderValue = 0.5;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Before / After',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Stack(
        children: [
          // After image (background)
          Center(
            child: PhotoView(
              imageProvider: CachedNetworkImageProvider(widget.afterUrl),
              minScale: PhotoViewComputedScale.contained,
              maxScale: PhotoViewComputedScale.covered * 2,
            ),
          ),

          // Before image (clipped)
          Center(
            child: ClipRect(
              child: Align(
                alignment: Alignment.centerLeft,
                widthFactor: _sliderValue,
                child: PhotoView(
                  imageProvider: CachedNetworkImageProvider(widget.beforeUrl),
                  minScale: PhotoViewComputedScale.contained,
                  maxScale: PhotoViewComputedScale.covered * 2,
                ),
              ),
            ),
          ),

          // Slider line
          Positioned(
            left: MediaQuery.of(context).size.width * _sliderValue,
            top: 0,
            bottom: 0,
            child: Container(
              width: 2,
              color: Colors.white,
            ),
          ),

          // Slider handle
          Positioned(
            left: MediaQuery.of(context).size.width * _sliderValue - 25,
            top: 0,
            bottom: 0,
            child: Center(
              child: Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: const Icon(Icons.compare_arrows),
              ),
            ),
          ),

          // Slider control
          Positioned(
            left: 0,
            right: 0,
            bottom: 40,
            child: Slider(
              value: _sliderValue,
              onChanged: (value) {
                setState(() => _sliderValue = value);
              },
              activeColor: AppTheme.primaryColor,
              inactiveColor: Colors.grey,
            ),
          ),

          // Labels
          Positioned(
            left: 16,
            top: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                'BEFORE',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Positioned(
            right: 16,
            top: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                'AFTER',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
