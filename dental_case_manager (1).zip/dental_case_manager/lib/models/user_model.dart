import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String id;
  final String email;
  final String displayName;
  final String? photoUrl;
  final String? pinHash;
  final bool biometricEnabled;
  final DateTime createdAt;
  final DateTime lastLoginAt;
  final UserSettings settings;

  UserModel({
    required this.id,
    required this.email,
    required this.displayName,
    this.photoUrl,
    this.pinHash,
    this.biometricEnabled = false,
    required this.createdAt,
    required this.lastLoginAt,
    required this.settings,
  });

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      id: doc.id,
      email: data['email'] ?? '',
      displayName: data['displayName'] ?? '',
      photoUrl: data['photoUrl'],
      pinHash: data['pinHash'],
      biometricEnabled: data['biometricEnabled'] ?? false,
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      lastLoginAt: (data['lastLoginAt'] as Timestamp).toDate(),
      settings: UserSettings.fromMap(data['settings'] ?? {}),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'pinHash': pinHash,
      'biometricEnabled': biometricEnabled,
      'createdAt': Timestamp.fromDate(createdAt),
      'lastLoginAt': Timestamp.fromDate(lastLoginAt),
      'settings': settings.toMap(),
    };
  }

  UserModel copyWith({
    String? id,
    String? email,
    String? displayName,
    String? photoUrl,
    String? pinHash,
    bool? biometricEnabled,
    DateTime? createdAt,
    DateTime? lastLoginAt,
    UserSettings? settings,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      pinHash: pinHash ?? this.pinHash,
      biometricEnabled: biometricEnabled ?? this.biometricEnabled,
      createdAt: createdAt ?? this.createdAt,
      lastLoginAt: lastLoginAt ?? this.lastLoginAt,
      settings: settings ?? this.settings,
    );
  }

  bool get hasPinLock => pinHash != null && pinHash!.isNotEmpty;
}

class UserSettings {
  final bool autoBackup;
  final bool backupWifiOnly;
  final String theme;

  UserSettings({
    this.autoBackup = true,
    this.backupWifiOnly = false,
    this.theme = 'system',
  });

  factory UserSettings.fromMap(Map<String, dynamic> map) {
    return UserSettings(
      autoBackup: map['autoBackup'] ?? true,
      backupWifiOnly: map['backupWifiOnly'] ?? false,
      theme: map['theme'] ?? 'system',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'autoBackup': autoBackup,
      'backupWifiOnly': backupWifiOnly,
      'theme': theme,
    };
  }

  UserSettings copyWith({
    bool? autoBackup,
    bool? backupWifiOnly,
    String? theme,
  }) {
    return UserSettings(
      autoBackup: autoBackup ?? this.autoBackup,
      backupWifiOnly: backupWifiOnly ?? this.backupWifiOnly,
      theme: theme ?? this.theme,
    );
  }
}

class BackupStatus {
  final String id;
  final DateTime? lastBackupTime;
  final String backupStatus;
  final int totalRecordsBackedUp;
  final int totalImagesBackedUp;
  final String? driveFolderId;
  final String? errorMessage;

  BackupStatus({
    required this.id,
    this.lastBackupTime,
    this.backupStatus = 'never',
    this.totalRecordsBackedUp = 0,
    this.totalImagesBackedUp = 0,
    this.driveFolderId,
    this.errorMessage,
  });

  factory BackupStatus.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return BackupStatus(
      id: doc.id,
      lastBackupTime: data['lastBackupTime'] != null
          ? (data['lastBackupTime'] as Timestamp).toDate()
          : null,
      backupStatus: data['backupStatus'] ?? 'never',
      totalRecordsBackedUp: data['totalRecordsBackedUp'] ?? 0,
      totalImagesBackedUp: data['totalImagesBackedUp'] ?? 0,
      driveFolderId: data['driveFolderId'],
      errorMessage: data['errorMessage'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'lastBackupTime':
          lastBackupTime != null ? Timestamp.fromDate(lastBackupTime!) : null,
      'backupStatus': backupStatus,
      'totalRecordsBackedUp': totalRecordsBackedUp,
      'totalImagesBackedUp': totalImagesBackedUp,
      'driveFolderId': driveFolderId,
      'errorMessage': errorMessage,
    };
  }

  BackupStatus copyWith({
    String? id,
    DateTime? lastBackupTime,
    String? backupStatus,
    int? totalRecordsBackedUp,
    int? totalImagesBackedUp,
    String? driveFolderId,
    String? errorMessage,
  }) {
    return BackupStatus(
      id: id ?? this.id,
      lastBackupTime: lastBackupTime ?? this.lastBackupTime,
      backupStatus: backupStatus ?? this.backupStatus,
      totalRecordsBackedUp: totalRecordsBackedUp ?? this.totalRecordsBackedUp,
      totalImagesBackedUp: totalImagesBackedUp ?? this.totalImagesBackedUp,
      driveFolderId: driveFolderId ?? this.driveFolderId,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }

  bool get isBackedUp => backupStatus == 'success';
  bool get isBackingUp => backupStatus == 'in_progress';
  bool get hasError => backupStatus == 'failed';
}
