import 'package:cloud_firestore/cloud_firestore.dart';

enum Gender { male, female, other }

class PatientModel {
  final String id;
  final String name;
  final String phone;
  final int age;
  final Gender gender;
  final String medicalHistory;
  final List<String> allergies;
  final bool smokingStatus;
  final String notes;
  final String? profilePhotoUrl;
  final String? profilePhotoPath;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String userId;

  PatientModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.age,
    required this.gender,
    this.medicalHistory = '',
    this.allergies = const [],
    this.smokingStatus = false,
    this.notes = '',
    this.profilePhotoUrl,
    this.profilePhotoPath,
    required this.createdAt,
    required this.updatedAt,
    required this.userId,
  });

  factory PatientModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return PatientModel(
      id: doc.id,
      name: data['name'] ?? '',
      phone: data['phone'] ?? '',
      age: data['age'] ?? 0,
      gender: Gender.values.firstWhere(
        (e) => e.name == data['gender'],
        orElse: () => Gender.other,
      ),
      medicalHistory: data['medicalHistory'] ?? '',
      allergies: List<String>.from(data['allergies'] ?? []),
      smokingStatus: data['smokingStatus'] ?? false,
      notes: data['notes'] ?? '',
      profilePhotoUrl: data['profilePhotoUrl'],
      profilePhotoPath: data['profilePhotoPath'],
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
      userId: data['userId'] ?? '',
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'phone': phone,
      'age': age,
      'gender': gender.name,
      'medicalHistory': medicalHistory,
      'allergies': allergies,
      'smokingStatus': smokingStatus,
      'notes': notes,
      'profilePhotoUrl': profilePhotoUrl,
      'profilePhotoPath': profilePhotoPath,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'userId': userId,
    };
  }

  PatientModel copyWith({
    String? id,
    String? name,
    String? phone,
    int? age,
    Gender? gender,
    String? medicalHistory,
    List<String>? allergies,
    bool? smokingStatus,
    String? notes,
    String? profilePhotoUrl,
    String? profilePhotoPath,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? userId,
  }) {
    return PatientModel(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      medicalHistory: medicalHistory ?? this.medicalHistory,
      allergies: allergies ?? this.allergies,
      smokingStatus: smokingStatus ?? this.smokingStatus,
      notes: notes ?? this.notes,
      profilePhotoUrl: profilePhotoUrl ?? this.profilePhotoUrl,
      profilePhotoPath: profilePhotoPath ?? this.profilePhotoPath,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      userId: userId ?? this.userId,
    );
  }

  String get genderDisplay {
    switch (gender) {
      case Gender.male:
        return 'Male';
      case Gender.female:
        return 'Female';
      case Gender.other:
        return 'Other';
    }
  }

  String get initials {
    final nameParts = name.split(' ');
    if (nameParts.length >= 2) {
      return '${nameParts[0][0]}${nameParts[1][0]}'.toUpperCase();
    }
    return name.isNotEmpty ? name[0].toUpperCase() : '?';
  }
}
