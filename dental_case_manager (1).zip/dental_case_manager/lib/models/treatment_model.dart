import 'package:cloud_firestore/cloud_firestore.dart';

enum TreatmentCategory {
  orthodontics,
  fillings,
  scalingPolishing;

  String get displayName {
    switch (this) {
      case TreatmentCategory.orthodontics:
        return 'Orthodontics';
      case TreatmentCategory.fillings:
        return 'Fillings';
      case TreatmentCategory.scalingPolishing:
        return 'Scaling & Polishing';
    }
  }

  String get folderName {
    switch (this) {
      case TreatmentCategory.orthodontics:
        return 'Orthodontics';
      case TreatmentCategory.fillings:
        return 'Fillings';
      case TreatmentCategory.scalingPolishing:
        return 'Scaling & Polishing';
    }
  }
}

enum PhotoLabel { before, during, after }

class TreatmentImage {
  final String id;
  final String url;
  final String storagePath;
  final PhotoLabel label;
  final DateTime uploadedAt;
  final String? driveBackupPath;

  TreatmentImage({
    required this.id,
    required this.url,
    required this.storagePath,
    required this.label,
    required this.uploadedAt,
    this.driveBackupPath,
  });

  factory TreatmentImage.fromMap(Map<String, dynamic> map) {
    return TreatmentImage(
      id: map['id'] ?? '',
      url: map['url'] ?? '',
      storagePath: map['storagePath'] ?? '',
      label: PhotoLabel.values.firstWhere(
        (e) => e.name == map['label'],
        orElse: () => PhotoLabel.before,
      ),
      uploadedAt: map['uploadedAt'] is Timestamp
          ? (map['uploadedAt'] as Timestamp).toDate()
          : DateTime.now(),
      driveBackupPath: map['driveBackupPath'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'url': url,
      'storagePath': storagePath,
      'label': label.name,
      'uploadedAt': Timestamp.fromDate(uploadedAt),
      'driveBackupPath': driveBackupPath,
    };
  }

  String get labelDisplay {
    switch (label) {
      case PhotoLabel.before:
        return 'Before';
      case PhotoLabel.during:
        return 'During';
      case PhotoLabel.after:
        return 'After';
    }
  }

  TreatmentImage copyWith({
    String? id,
    String? url,
    String? storagePath,
    PhotoLabel? label,
    DateTime? uploadedAt,
    String? driveBackupPath,
  }) {
    return TreatmentImage(
      id: id ?? this.id,
      url: url ?? this.url,
      storagePath: storagePath ?? this.storagePath,
      label: label ?? this.label,
      uploadedAt: uploadedAt ?? this.uploadedAt,
      driveBackupPath: driveBackupPath ?? this.driveBackupPath,
    );
  }
}

class TreatmentModel {
  final String id;
  final String patientId;
  final TreatmentCategory category;
  final String? toothNumber;
  final DateTime date;
  final String diagnosis;
  final String treatmentNotes;
  final List<String> materialsUsed;
  final String progressNotes;
  final List<TreatmentImage> images;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String userId;

  TreatmentModel({
    required this.id,
    required this.patientId,
    required this.category,
    this.toothNumber,
    required this.date,
    this.diagnosis = '',
    this.treatmentNotes = '',
    this.materialsUsed = const [],
    this.progressNotes = '',
    this.images = const [],
    required this.createdAt,
    required this.updatedAt,
    required this.userId,
  });

  factory TreatmentModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return TreatmentModel(
      id: doc.id,
      patientId: data['patientId'] ?? '',
      category: TreatmentCategory.values.firstWhere(
        (e) => e.name == data['category'],
        orElse: () => TreatmentCategory.fillings,
      ),
      toothNumber: data['toothNumber'],
      date: (data['date'] as Timestamp).toDate(),
      diagnosis: data['diagnosis'] ?? '',
      treatmentNotes: data['treatmentNotes'] ?? '',
      materialsUsed: List<String>.from(data['materialsUsed'] ?? []),
      progressNotes: data['progressNotes'] ?? '',
      images: (data['images'] as List<dynamic>?)
              ?.map((e) => TreatmentImage.fromMap(e as Map<String, dynamic>))
              .toList() ??
          [],
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
      userId: data['userId'] ?? '',
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'patientId': patientId,
      'category': category.name,
      'toothNumber': toothNumber,
      'date': Timestamp.fromDate(date),
      'diagnosis': diagnosis,
      'treatmentNotes': treatmentNotes,
      'materialsUsed': materialsUsed,
      'progressNotes': progressNotes,
      'images': images.map((e) => e.toMap()).toList(),
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'userId': userId,
    };
  }

  TreatmentModel copyWith({
    String? id,
    String? patientId,
    TreatmentCategory? category,
    String? toothNumber,
    DateTime? date,
    String? diagnosis,
    String? treatmentNotes,
    List<String>? materialsUsed,
    String? progressNotes,
    List<TreatmentImage>? images,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? userId,
  }) {
    return TreatmentModel(
      id: id ?? this.id,
      patientId: patientId ?? this.patientId,
      category: category ?? this.category,
      toothNumber: toothNumber ?? this.toothNumber,
      date: date ?? this.date,
      diagnosis: diagnosis ?? this.diagnosis,
      treatmentNotes: treatmentNotes ?? this.treatmentNotes,
      materialsUsed: materialsUsed ?? this.materialsUsed,
      progressNotes: progressNotes ?? this.progressNotes,
      images: images ?? this.images,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      userId: userId ?? this.userId,
    );
  }

  List<TreatmentImage> get beforeImages =>
      images.where((img) => img.label == PhotoLabel.before).toList();

  List<TreatmentImage> get duringImages =>
      images.where((img) => img.label == PhotoLabel.during).toList();

  List<TreatmentImage> get afterImages =>
      images.where((img) => img.label == PhotoLabel.after).toList();
}
