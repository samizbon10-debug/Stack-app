import 'package:cloud_firestore/cloud_firestore.dart';

enum AppointmentStatus { scheduled, completed, cancelled }

class AppointmentModel {
  final String id;
  final String patientId;
  final String patientName;
  final DateTime date;
  final String time;
  final String treatmentType;
  final String notes;
  final AppointmentStatus status;
  final bool reminderSet;
  final int? reminderId;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String userId;

  AppointmentModel({
    required this.id,
    required this.patientId,
    required this.patientName,
    required this.date,
    required this.time,
    required this.treatmentType,
    this.notes = '',
    this.status = AppointmentStatus.scheduled,
    this.reminderSet = false,
    this.reminderId,
    required this.createdAt,
    required this.updatedAt,
    required this.userId,
  });

  factory AppointmentModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return AppointmentModel(
      id: doc.id,
      patientId: data['patientId'] ?? '',
      patientName: data['patientName'] ?? '',
      date: (data['date'] as Timestamp).toDate(),
      time: data['time'] ?? '09:00',
      treatmentType: data['treatmentType'] ?? '',
      notes: data['notes'] ?? '',
      status: AppointmentStatus.values.firstWhere(
        (e) => e.name == data['status'],
        orElse: () => AppointmentStatus.scheduled,
      ),
      reminderSet: data['reminderSet'] ?? false,
      reminderId: data['reminderId'],
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
      userId: data['userId'] ?? '',
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'patientId': patientId,
      'patientName': patientName,
      'date': Timestamp.fromDate(date),
      'time': time,
      'treatmentType': treatmentType,
      'notes': notes,
      'status': status.name,
      'reminderSet': reminderSet,
      'reminderId': reminderId,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'userId': userId,
    };
  }

  AppointmentModel copyWith({
    String? id,
    String? patientId,
    String? patientName,
    DateTime? date,
    String? time,
    String? treatmentType,
    String? notes,
    AppointmentStatus? status,
    bool? reminderSet,
    int? reminderId,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? userId,
  }) {
    return AppointmentModel(
      id: id ?? this.id,
      patientId: patientId ?? this.patientId,
      patientName: patientName ?? this.patientName,
      date: date ?? this.date,
      time: time ?? this.time,
      treatmentType: treatmentType ?? this.treatmentType,
      notes: notes ?? this.notes,
      status: status ?? this.status,
      reminderSet: reminderSet ?? this.reminderSet,
      reminderId: reminderId ?? this.reminderId,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      userId: userId ?? this.userId,
    );
  }

  String get statusDisplay {
    switch (status) {
      case AppointmentStatus.scheduled:
        return 'Scheduled';
      case AppointmentStatus.completed:
        return 'Completed';
      case AppointmentStatus.cancelled:
        return 'Cancelled';
    }
  }

  DateTime get fullDateTime {
    final timeParts = time.split(':');
    return DateTime(
      date.year,
      date.month,
      date.day,
      int.parse(timeParts[0]),
      int.parse(timeParts.length > 1 ? timeParts[1] : '0'),
    );
  }

  bool get isUpcoming => fullDateTime.isAfter(DateTime.now());
}
