import 'package:cloud_firestore/cloud_firestore.dart';

enum ImageLabel { before, during, after, profile, other }

enum ImageCategory { orthodontics, fillings, scalingPolishing, profile }

class ImageModel {
  final String imageId;
  final String patientId;
  final String? treatmentId;
  final String userId;
  final String url;
  final String? thumbnailUrl;
  final ImageLabel label;
  final ImageCategory category;
  final String? description;
  final String? toothNumber;
  final String? driveBackupUrl;
  final bool isBackedUp;
  final DateTime uploadedAt;
  final DateTime? backupAt;

  ImageModel({
    required this.imageId,
    required this.patientId,
    this.treatmentId,
    required this.userId,
    required this.url,
    this.thumbnailUrl,
    required this.label,
    required this.category,
    this.description,
    this.toothNumber,
    this.driveBackupUrl,
    this.isBackedUp = false,
    required this.uploadedAt,
    this.backupAt,
  });

  factory ImageModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ImageModel(
      imageId: doc.id,
      patientId: data['patientId'] ?? '',
      treatmentId: data['treatmentId'],
      userId: data['userId'] ?? '',
      url: data['url'] ?? '',
      thumbnailUrl: data['thumbnailUrl'],
      label: _parseLabel(data['label']),
      category: _parseCategory(data['category']),
      description: data['description'],
      toothNumber: data['toothNumber'],
      driveBackupUrl: data['driveBackupUrl'],
      isBackedUp: data['isBackedUp'] ?? false,
      uploadedAt: data['uploadedAt']?.toDate() ?? DateTime.now(),
      backupAt: data['backupAt']?.toDate(),
    );
  }

  static ImageLabel _parseLabel(String? value) {
    switch (value?.toLowerCase()) {
      case 'before':
        return ImageLabel.before;
      case 'during':
        return ImageLabel.during;
      case 'after':
        return ImageLabel.after;
      case 'profile':
        return ImageLabel.profile;
      default:
        return ImageLabel.other;
    }
  }

  static ImageCategory _parseCategory(String? value) {
    switch (value?.toLowerCase()) {
      case 'orthodontics':
        return ImageCategory.orthodontics;
      case 'fillings':
        return ImageCategory.fillings;
      case 'scaling_polishing':
      case 'scalingpolishing':
        return ImageCategory.scalingPolishing;
      case 'profile':
        return ImageCategory.profile;
      default:
        return ImageCategory.profile;
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'patientId': patientId,
      'treatmentId': treatmentId,
      'userId': userId,
      'url': url,
      'thumbnailUrl': thumbnailUrl,
      'label': _labelToString(label),
      'category': _categoryToString(category),
      'description': description,
      'toothNumber': toothNumber,
      'driveBackupUrl': driveBackupUrl,
      'isBackedUp': isBackedUp,
      'uploadedAt': Timestamp.fromDate(uploadedAt),
      'backupAt': backupAt != null ? Timestamp.fromDate(backupAt!) : null,
    };
  }

  static String _labelToString(ImageLabel label) {
    switch (label) {
      case ImageLabel.before:
        return 'before';
      case ImageLabel.during:
        return 'during';
      case ImageLabel.after:
        return 'after';
      case ImageLabel.profile:
        return 'profile';
      case ImageLabel.other:
        return 'other';
    }
  }

  static String _categoryToString(ImageCategory category) {
    switch (category) {
      case ImageCategory.orthodontics:
        return 'orthodontics';
      case ImageCategory.fillings:
        return 'fillings';
      case ImageCategory.scalingPolishing:
        return 'scaling_polishing';
      case ImageCategory.profile:
        return 'profile';
    }
  }

  ImageModel copyWith({
    String? imageId,
    String? patientId,
    String? treatmentId,
    String? userId,
    String? url,
    String? thumbnailUrl,
    ImageLabel? label,
    ImageCategory? category,
    String? description,
    String? toothNumber,
    String? driveBackupUrl,
    bool? isBackedUp,
    DateTime? uploadedAt,
    DateTime? backupAt,
  }) {
    return ImageModel(
      imageId: imageId ?? this.imageId,
      patientId: patientId ?? this.patientId,
      treatmentId: treatmentId ?? this.treatmentId,
      userId: userId ?? this.userId,
      url: url ?? this.url,
      thumbnailUrl: thumbnailUrl ?? this.thumbnailUrl,
      label: label ?? this.label,
      category: category ?? this.category,
      description: description ?? this.description,
      toothNumber: toothNumber ?? this.toothNumber,
      driveBackupUrl: driveBackupUrl ?? this.driveBackupUrl,
      isBackedUp: isBackedUp ?? this.isBackedUp,
      uploadedAt: uploadedAt ?? this.uploadedAt,
      backupAt: backupAt ?? this.backupAt,
    );
  }
}
